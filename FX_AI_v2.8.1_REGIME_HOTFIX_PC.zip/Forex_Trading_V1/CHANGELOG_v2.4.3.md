# v2.4.3 — Drawdown Recovery Hotfix

- Fixed the high-water drawdown protection deadlock that could leave new entries blocked indefinitely.
- High-water protection now transitions through COOLDOWN -> RECOVERY -> NORMAL behavior.
- After the cooldown, only the high-water profit-giveback watermark is rebased; daily and weekly loss breakers remain hard safety barriers.
- Recovery entries use reduced risk (default 0.25x) instead of immediately returning to full risk.
- Added explicit cooldown status text with scans remaining.
