# FX // AI v2.7.1 — UI responsiveness hotfix

- Moved all LIVE provider downloads off the Tkinter/UI thread.
- Reused one bounded background worker pool instead of creating and blocking on
  a new pool during every market refresh.
- Prevented duplicate downloads for symbols already being refreshed.
- Made market snapshots cache-only so chart and dashboard rendering never wait
  on Yahoo Finance or Binance.
- Reduced needless 140-market rescans from once per second to once per two
  seconds and adjusted visual refresh pacing.
- Added clean cancellation of queued feed work when the app closes.
- Trading remains 100% PAPER-only; Neural Edge remains SHADOW-only.
