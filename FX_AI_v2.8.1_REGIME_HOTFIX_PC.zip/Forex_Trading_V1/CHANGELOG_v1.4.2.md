# Forex Trading V1.4.2 — Manual Chart Lock + GitHub Release Feed

## Command Center
- Removed AUTO chart switching from the UI for now.
- Removed `<<TreeviewSelect>>` as a chart-selection trigger.
- Only an actual left-mouse click on a market row may change the chart.
- Scanner reranking, row reordering, refreshes and programmatic selection cannot replace the manually selected chart.
- Manual selection is persisted as `selected_chart_symbol`.

## GitHub Releases updater
- Added a one-time GitHub Releases channel activation flow.
- Enter `owner/repository` once in Settings and press Activate.
- The release channel is stored locally in `publisher_release_channel.json`.
- After activation, future updates use `Check for Updates` only.
- Updater checks the GitHub Releases API, reads the latest tag/changelog, downloads the ZIP, validates ZIP integrity, preserves user data, backs up program files, installs and restarts.
- The actual GitHub repository must exist and contain published Releases with ZIP assets before an internet update can be tested end-to-end.

## Validation
- Added deterministic source-contract tests for manual-only chart selection.
- Added GUI smoke test that manually selects EURUSD, forces GBPUSD to rank #1, refreshes Command Center, and verifies EURUSD remains selected.
