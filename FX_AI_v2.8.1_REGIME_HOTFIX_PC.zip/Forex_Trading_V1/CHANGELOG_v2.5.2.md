# FX // AI v2.5.2 — Edge Persistence / Payoff Quality

Built from the latest ~24h v2.5.1 evidence:
- loss rate improved dramatically versus v2.5.0, but expectancy was still negative
- TREND was positive while REVERSAL and RANGE were the main regime leaks
- ENERGY was positive while FOREX remained the largest asset-class drag
- winners were still too small relative to accumulated stop-losses

Changes:
- Minimum planned reward/risk is now enforced at execution.
- Default minimum planned RR: 1.65R.
- TREND targets at least 1.80R while giving winners more room before break-even/trailing.
- REVERSAL/RANGE require at least 1.90R payoff and receive much smaller bootstrap/probation risk.
- PROVEN contexts may use 1.55R minimum because they have validated positive evidence.
- Non-trend positions protect gains earlier at +0.60R and begin trailing at +1.15R.
- Governor proof is stricter: positive context needs >= +0.05R expectancy and PF >= 1.10.
- Broad losing asset/regime combinations are removed from production sooner.
- Global negative-expectancy risk scaling is reduced from 0.35x to 0.28x.
- Persistent scanning/research remains active; bad contexts become research-only rather than stopping the engine.
