# Forex Trading V1.4.3 — Chart Root-Cause Fix

## Command Center chart
- Fixed the synthetic feed clock bug that advanced the entire market once for every symbol scanned.
- The synthetic market now advances exactly once per engine scan cycle.
- Added isolated `chart_symbol` state. Scanner ranking and table refreshes do not own this state.
- After initialization, only a real user market click changes `chart_symbol`.
- If the selected market temporarily lacks data, the app waits instead of substituting another market.

## GitHub updater
- GitHub repository activation now verifies that the repository exists and is publicly reachable before saving it.
- Once activated, Check for Updates continues to use GitHub Releases.

## Validation
- Added a regression test proving `snapshot()` does not advance other markets.
- Added chart-state isolation tests.
