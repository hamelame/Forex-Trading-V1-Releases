# Mobile parity contract — v2.8.0

The phone client must expose the same engine state and controls as the PC UI while the engine runs server-side.

Parity targets: Command Center; Market Scanner and locked manual selection; Market Health/regime; AI Decision Feed with reasons; Top 5/10 selector/watchlist; PAPER positions and closed trades; balance/equity/realized/unrealized P&L; risk/exposure; session/feed/safety state; Neural Edge Shadow Lab and validation statistics; settings; Start/Pause/Stop and close-all/new-session controls; updater/version status.

Safety invariants: PAPER_ONLY=true; neural_edge_shadow_only=true; no broker-order endpoint. Phone UI is a client; cloud engine continues independently of iOS foreground state.
