# v2.4.5 — Trade-Ready Shortlist Deadlock Fix

- Fixed a v2.4.4 shortlist hysteresis regression that could leave every selected market on BLOCK/WAIT with 0 trade-ready.
- BUY/SELL candidates now receive execution priority in automatic Top 5/Top 10 selection.
- If the sticky shortlist reaches 0 trade-ready while an executable candidate exists, the selector immediately reselects instead of waiting for the normal refresh interval.
- Non-executable incumbents no longer receive hysteresis protection over fresh executable BUY/SELL candidates.
- Safety gates, risk limits, recovery logic and Execution-Realistic Paper Mode remain intact.
