# FX // AI v2.6.0 — RSI Intelligence Engine

## Core RSI rebuild
- Replaced the old overbought/oversold shortcut with a structure-aware RSI engine.
- Synthetic feed now calculates Wilder-style RSI history, not only one current value.
- Market snapshots carry aligned RSI and price history for structural analysis.
- Added RSI slope and acceleration.
- Added 50-centerline reclaim, loss, above-50 hold and below-50 hold states.
- Added bullish / bearish dynamic RSI operating ranges and range-shift detection.
- Added regular bullish/bearish divergence.
- Added hidden bullish/bearish divergence for continuation context.
- Added bullish/bearish RSI failure swings.
- Overbought/oversold readings are now context, never automatic BUY/SELL rules.

## Regime and Champion AI
- Extreme RSI by itself no longer labels a market REVERSAL.
- REVERSAL requires structural RSI evidence plus weakening/opposing price momentum.
- Added RSIIntel as a fourth internal Champion specialist.
- TREND can use strong high RSI as continuation evidence when price structure agrees.
- Mean reversion no longer uses `(50 - RSI)` as its main direction signal.
- Strong contrary failure swings can veto immediate production entries.

## Entry validation
- TREND: EMA + momentum alignment, with RSI structure not strongly opposing.
- REVERSAL: regular divergence or failure swing required.
- RANGE: RSI must actually turn away from the range edge.
- HIGH VOL: directional impulse + non-opposing RSI structure required.

## RSI pattern self-learning
- Learning DB now stores `rsi_state`, `rsi_pattern`, `rsi_bias`, `rsi_slope`, and `rsi_support`.
- Existing databases migrate automatically with ALTER TABLE additions.
- The learner tracks expectancy/PF/win-rate for RSI patterns by asset class + regime + side.
- A repeatedly losing RSI pattern can be reduced in risk or quarantined to RESEARCH-ONLY.
- Trade Exporter includes the new RSI fields.

## Preserved protections
Execution Intelligence, long/short learning, Expectancy Governor, FastGuard, SymbolGuard,
Edge Allocation, Deep Recovery, catastrophic stop, realistic slippage/carry and liveness
controls remain in place.

PAPER/SYNTHETIC research only.
