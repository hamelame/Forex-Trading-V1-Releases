# Publish and test V2.2.0

1. Extract V2.2.0 to a separate folder.
2. Run `PUBLISH_RELEASE.bat`.
3. Wait for `SUCCESS - GitHub Release v2.2.0 is published.`
4. Open your current V2.1.0 installation.
5. Settings -> CHECK FOR UPDATES.
6. Install V2.2.0.
7. Open Shadow Lab.
8. Test AUTO TOP 5, AUTO TOP 10 and MANUAL.
9. Verify the shortlist and counters update without affecting PAPER-only safety.

This version remains PAPER + SYNTHETIC only.
