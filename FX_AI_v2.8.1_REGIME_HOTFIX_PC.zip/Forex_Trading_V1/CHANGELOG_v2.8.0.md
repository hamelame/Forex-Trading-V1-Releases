# FX // AI v2.8.0 — Evidence-Guided Regime Safety

- Reviewed the supplied 99-trade PAPER export before changing execution logic.
- Added a stricter HIGH VOL quality gate (score + confidence) instead of symbol blacklists.
- Reduced HIGH VOL risk multiplier from 0.60x to configurable 0.40x.
- Added a 2.00R minimum planned reward/risk requirement for HIGH VOL entries.
- Preserved TREND behavior; the sample was positive there and did not justify broad tightening.
- Fixed trading-data export interpretation: historical equity can span PAPER session resets and is now explicitly flagged instead of looking like a huge trading loss.
- PAPER-only execution lock retained. Neural Edge remains SHADOW-only.
- PC v2.7.1 remains untouched; this is a separate v2.8.0 build.
