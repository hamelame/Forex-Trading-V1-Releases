# FX // AI V2.2.2 — Functionality Fix

## Refresh buttons
- The global REFRESH control now performs a real fresh engine scan while AI is running.
- Visible table caches are invalidated so refresh is immediately visible.
- Refresh preserves the selected page/market and does not reset the paper session.
- Trade Log refresh now uses the same reliable refresh path.
- Status bar confirms the page and refresh time.

## Settings actually apply
- Save & Apply now separates ordinary live settings from Paper Trading Capital.
- Paper Trading Capital remains limited to $1,000–$100,000.
- When capital changes, the app asks whether to start a NEW paper session immediately.
- YES resets Balance, Equity, Realized P/L, Unrealized P/L and Open Positions to the selected capital.
- NO keeps the current session and uses the new capital on the next paper session.
- Market-class changes apply to the engine and trigger immediate reselection when needed.

## Top 5 / Top 10 switching
- Changing selection mode or market-class permissions clears stale shortlist state.
- AUTO TOP 5 / AUTO TOP 10 is immediately recalculated instead of waiting on the previous shortlist cooldown.

## Command Center
- Added UNREALIZED P/L as a dedicated live KPI.
- Realized P/L remains closed-trade P/L only.
- Portfolio Heat value/gauge spacing tightened to avoid clipping.

## Market Watch
- Active paper positions now take priority in Market Watch.
- Each active slot shows symbol, BUY/SELL LIVE state and current Open P/L.
- When there are no active trades, Market Watch falls back to the normal watch list.

## Architecture
- Existing 140-instrument Multi-Market AI Trading architecture is preserved.
- Forex, Metals, Energy, Indices and Crypto remain part of the same research terminal.
- This build remains 100% PAPER + SYNTHETIC.
