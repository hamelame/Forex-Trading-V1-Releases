# FX Research Brain v2 — validation notes

The production paper brain deliberately combines several independent FX-style signal families and can abstain.

The included synthetic market is useful for software validation, lifecycle testing, risk controls, persistence and UI behavior. It is not evidence that a strategy will be profitable in real FX markets.

Promotion path:
1. Synthetic paper stability.
2. Historical replay using real FX data with spread/cost assumptions.
3. Walk-forward / out-of-sample validation.
4. Shadow live-data observation without orders.
5. Only after sufficient evidence: separate future live-execution build.

No live execution is present in V2.0.0.
