# FX // AI v2.5.3 — Edge Allocation + Easy Trade Export
- Execution now prioritizes PROVEN positive-expectancy contexts over raw market rank.
- TREND receives priority; unproven REVERSAL/RANGE is deprioritized and limited to one portfolio slot.
- PROVEN threshold is stricter: 20 samples, >= +0.06R expectancy and PF >= 1.12.
- Global expectancy window is 60 trades for steadier adaptive risk.
- EXPORT_TRADING_DATA.bat safely snapshots the live SQLite DB and creates a compact ZIP without the huge decisions table.
- v2.5.2 payoff quality, minimum RR, trailing, Governor, FastGuard, SymbolGuard and liveness protections remain.
