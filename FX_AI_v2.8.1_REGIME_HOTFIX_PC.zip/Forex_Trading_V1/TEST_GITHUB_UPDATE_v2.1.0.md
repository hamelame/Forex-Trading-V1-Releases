# Publish / test V2.1.0 through GitHub

1. Extract the V2.1.0 folder.
2. Run `PUBLISH_RELEASE.bat` from that folder.
3. Wait for `SUCCESS - GitHub Release v2.1.0 is published.`
4. Open your currently installed V2.0.0 app.
5. Go to Settings -> CHECK FOR UPDATES.
6. Accept V2.1.0.
7. After restart, verify the title/footer shows V2.1.0.
8. Open Markets and verify the scanner universe shows 140 instruments.
9. Open Settings and verify AI TRADING / MANUAL and the new market-class controls are visible.

The existing database, positions, history, logs and release-channel configuration are preserved by the updater.
