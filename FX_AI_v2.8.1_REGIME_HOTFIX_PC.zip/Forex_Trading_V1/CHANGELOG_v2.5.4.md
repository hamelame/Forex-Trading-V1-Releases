# FX // AI v2.5.4 — Execution Intelligence + Long/Short Edge

Research basis:
- Market orders can slip and partially fill; limit/post-only style orders trade execution certainty for price control.
- Realistic transaction costs and market impact can materially change strategy profitability.
- Perpetual-futures carry/funding can differ by long/short side and must be treated as a holding cost.
- Paper execution must therefore be part of the decision itself, not merely deducted afterward.

## Execution Intelligence
- Adds PASSIVE_LIMIT, MARKETABLE_LIMIT and MARKET-style paper execution.
- Order style is chosen from signal urgency and estimated liquidity.
- Slippage now increases nonlinearly with position size relative to an asset-class liquidity proxy.
- Spread, ATR, data quality, direction and size all affect expected execution cost.
- Partial/no-fill probabilities vary by order style and liquidity.
- Passive fills use lower maker-like commissions but have materially higher no-fill risk.
- A pre-trade Execution Economics Gate blocks trades whose estimated round-trip costs consume too much R or too much of the planned reward.
- Stop-loss slippage uses the same size/liquidity-aware model and remains capped.

## Long / Short Intelligence
- Self-Learning now tracks performance by asset class + BUY/SELL side.
- If longs or shorts are persistently weak in an asset class, that side receives reduced risk or becomes RESEARCH-ONLY.
- This learns directional asymmetry from actual paper outcomes rather than hard-coding a permanent bullish/bearish bias.

## Directional Setup Validation
- TREND entries must agree with both EMA direction and momentum.
- REVERSAL entries require RSI exhaustion in the correct direction.
- RANGE entries must occur away from equilibrium.
- HIGH VOL entries require directional impulse.
- Failed directional setups remain visible to research/counterfactual learning but do not receive production capital.

## Carry / Funding
- Crypto paper positions accrue a configurable 8-hour funding/carry reserve.
- Other assets accrue fractional-day financing rather than getting free carry for holds shorter than a full day.
- This is conservative synthetic modeling, not a claim to reproduce a live venue's current funding rate.

Existing Expectancy Governor, FastGuard, SymbolGuard, payoff-quality, Deep Recovery,
catastrophic protection, edge allocation and persistent scanning remain enabled.
