# FX // AI V2.2.4 — Command Center Layout + Safe Startup Hotfix

## Command Center
- KPI cards now use a responsive two-row grid instead of one oversized horizontal row.
- Fixes Open Positions / Portfolio Heat / AI Engine clipping on narrower windows.
- Portfolio Heat value keeps reserved space for its gauge.

## Startup safety
- The AI now ALWAYS launches PAUSED.
- Opening the app never begins paper trading automatically.
- The user must explicitly press START AI before new paper trades can open.
- Startup status clearly says AI paused.

## Preserved
- V2.2.3 execution/session-gating fix.
- Trade Log hard refresh.
- Active-position Market Watch.
- 140-instrument Multi-Market architecture.
- PAPER + SYNTHETIC only.
