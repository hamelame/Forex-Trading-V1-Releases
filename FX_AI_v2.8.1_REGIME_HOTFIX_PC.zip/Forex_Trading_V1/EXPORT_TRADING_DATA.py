from __future__ import annotations
import csv, json, sqlite3, zipfile, tempfile
from pathlib import Path
from datetime import datetime, timezone
from collections import defaultdict

ROOT=Path(__file__).resolve().parent
DB=ROOT/"data"/"forex_v1.db"
OUTDIR=ROOT/"exports"

def rows_to_csv(path, rows):
    rows=list(rows)
    if not rows:
        path.write_text("",encoding="utf-8"); return
    cols=rows[0].keys()
    with path.open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=cols); w.writeheader()
        for r in rows:w.writerow(dict(r))

def stats(rows):
    rows=list(rows); pnls=[float(r["pnl"] or 0) for r in rows]; rs=[float(r["r_multiple"] or 0) for r in rows]
    wins=[x for x in pnls if x>0]; losses=[x for x in pnls if x<0]; gp=sum(wins); gl=abs(sum(losses))
    return {"trades":len(rows),"net_pnl":sum(pnls),"wins":len(wins),"losses":len(losses),
      "win_rate_pct":len(wins)/len(rows)*100 if rows else 0,
      "avg_win":sum(wins)/len(wins) if wins else 0,"avg_loss":sum(losses)/len(losses) if losses else 0,
      "profit_factor":gp/gl if gl else None,"avg_r":sum(rs)/len(rs) if rs else 0}

def main():
    if not DB.exists(): raise SystemExit(f"Database not found: {DB}")
    OUTDIR.mkdir(exist_ok=True); stamp=datetime.now().strftime("%Y%m%d-%H%M%S")
    with tempfile.TemporaryDirectory(prefix="fxai_export_") as td:
        td=Path(td); snap=td/"snapshot.db"
        src=sqlite3.connect(f"file:{DB}?mode=ro",uri=True,timeout=30); dst=sqlite3.connect(snap)
        src.backup(dst); dst.close(); src.close()
        con=sqlite3.connect(snap); con.row_factory=sqlite3.Row
        trades=list(con.execute("SELECT * FROM trades ORDER BY closed_at"))
        learn=list(con.execute("""SELECT trade_id,ts,symbol,asset_class,regime,session,side,context_key,
          score,confidence,rsi,atr,rsi_state,rsi_pattern,rsi_bias,rsi_slope,rsi_support,
          pnl,r_multiple,mfe_r,mae_r,bars_open,exit_reason FROM learning_experiences ORDER BY id"""))
        equity=list(con.execute("SELECT ts,balance,equity FROM equity ORDER BY id"))
        counters=list(con.execute("""SELECT ts,symbol,side,regime,session,score,confidence,block_reason,
          horizon_scans,hypothetical_r FROM counterfactuals ORDER BY id DESC LIMIT 10000"""))
        try:
            neural=list(con.execute("SELECT * FROM neural_shadow ORDER BY id"))
        except sqlite3.OperationalError:
            neural=[]
        con.close()
        rows_to_csv(td/"trades.csv",trades); rows_to_csv(td/"learning_experiences.csv",learn)
        rows_to_csv(td/"equity.csv",equity); rows_to_csv(td/"counterfactuals_recent.csv",counters)
        rows_to_csv(td/"neural_shadow.csv",neural)
        summary=stats(trades)
        if equity:
            summary.update(first_balance=float(equity[0]["balance"]),last_balance=float(equity[-1]["balance"]),
                           last_equity=float(equity[-1]["equity"]))
            # Equity history intentionally survives PAPER session resets. A first/last
            # balance mismatch therefore must not be presented as trading P/L.
            balances=[float(r["balance"]) for r in equity]
            reset_jumps=sum(1 for a,b in zip(balances,balances[1:]) if abs(b-a)>max(100.0,abs(a)*0.20))
            summary["equity_history_contains_session_resets"]=bool(reset_jumps)
            summary["detected_session_reset_jumps"]=reset_jumps
            summary["balance_history_note"]=(
                "Equity history spans PAPER sessions; first_balance to last_balance is not cumulative trading P/L."
                if reset_jumps else "No large PAPER-session balance reset detected in equity history."
            )
        summary["exported_utc"]=datetime.now(timezone.utc).isoformat(); summary["database_bytes"]=DB.stat().st_size
        by_regime=defaultdict(list); by_asset=defaultdict(list); by_symbol=defaultdict(list)
        learn_by_trade={r["trade_id"]:r for r in learn}
        for t in trades:
            lr=learn_by_trade.get(t["id"])
            if lr: by_regime[lr["regime"]].append(t); by_asset[lr["asset_class"]].append(t)
            by_symbol[t["symbol"]].append(t)
        summary["by_regime"]={k:stats(v) for k,v in by_regime.items()}
        summary["by_asset"]={k:stats(v) for k,v in by_asset.items()}
        summary["by_symbol"]={k:stats(v) for k,v in by_symbol.items()}
        (td/"summary.json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
        out=OUTDIR/f"TRADING_ANALYSIS_EXPORT_{stamp}.zip"
        with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for name in ["summary.json","trades.csv","learning_experiences.csv","equity.csv","counterfactuals_recent.csv","neural_shadow.csv"]:
                z.write(td/name,name)
        print(f"\nEXPORT READY:\n{out}\nTrades: {summary['trades']} | Net P/L: {summary['net_pnl']:+.2f}")
        print("Send this ZIP in ChatGPT. You do NOT need to send forex_v1.db.")
if __name__=="__main__": main()
