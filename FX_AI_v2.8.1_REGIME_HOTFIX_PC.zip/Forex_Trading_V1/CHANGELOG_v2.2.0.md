# FX // AI V2.2.0 — Top Opportunity Selection Engine

## AI Market Selection Lab
- Shadow Lab is now a real control workspace instead of a status-only page.
- Choose:
  - AUTO TOP 5
  - AUTO TOP 10
  - MANUAL
- Enable/disable market classes:
  - Forex
  - Metals
  - Energy
  - Indices
  - Crypto
- MANUAL mode accepts a user-defined instrument shortlist.
- Shows the full funnel in real time:
  140 scanned -> eligible -> selected -> trade-ready.

## Selection Engine
- The full 140-instrument universe is still analysed by the AI.
- Safety/quality filters create an eligible pool.
- Only the Top 5 / Top 10 shortlist can progress to paper execution.
- Shortlist hysteresis prevents markets from constantly swapping on tiny score changes.
- Configurable shortlist refresh cadence.
- Explicit NO TRADE state when no selected market has sufficient edge.
- MANUAL selection still remains subject to the paper AI/risk safety layer.

## Selection tuning
New controls in Settings:
- Shortlist refresh scans
- Replacement hysteresis
- Minimum market score
- Minimum AI score
- Minimum confidence
- Minimum data quality
- Maximum spread

## Readability
- Larger sidebar.
- Larger navigation text and controls.
- Larger table rows and table text.
- Larger section headings/subtitles.
- Larger Market Intelligence values.
- Increased high-DPI scaling.

## Safety
- Still 100% PAPER + SYNTHETIC.
- No MT5/broker/live execution.
- Existing risk engine, circuit breakers, AI/Manual profiles and GitHub updater remain in place.

## Research goal
V2.2 is designed to be selective rather than force trades. Win rate is measured, not guaranteed; promotion decisions should prioritize after-cost expectancy, profit factor and drawdown alongside win rate.
