# FX // AI V2.1.0 — Multi-Market Universe + AI Trading Control

## 140-instrument Multi-Market Universe
The research scanner expands from 56 Forex pairs to 140 synthetic paper instruments:

- 72 Forex pairs
- 8 Metals
- 8 Energy markets
- 20 Global Indices
- 32 Crypto markets

Markets can be filtered directly in the Markets workspace by FOREX / METALS / ENERGY / INDICES / CRYPTO. Instrument rows show full names and market type.

## One Champion AI module
V2.1 intentionally focuses on one main trading brain: `Multi-Market Research Brain v1`.

The Champion contains internal Trend, Mean-Reversion and Breakout specialists, but separate competing trading profiles are disabled for now. The AI changes specialist weighting according to market class and detected regime.

Forex currency-strength confirmation remains Forex-only; it is not incorrectly applied to Gold, Oil, Indices or Crypto.

## AI TRADING / MANUAL profiles
Settings now includes two control modes:

- **AI TRADING** — protected research profile with adaptive risk and conservative safety caps.
- **MANUAL** — you control the exposed paper-trading thresholds and risk values yourself.

Both profiles remain hard-locked to PAPER / SYNTHETIC. There is no live broker execution in V2.1.

## Much larger Settings system
New controls include:

- AI score, minimum confidence, minimum edge and specialist consensus
- Data quality and spread gates
- Daily / 7-day / high-water drawdown circuit breakers
- Global and per-market-class position limits
- FX currency concentration limit
- Re-entry cooldown and maximum hold
- Break-even and ATR trailing protection
- Forex / Metals / Energy / Indices / Crypto risk multipliers
- Individual AI specialist switches
- Session allow/block controls
- High-volatility pause option
- Market-class enable/disable controls
- Manual-profile risk and entry settings
- Scanner, UI refresh and rerank timing

## Clear AI start / stop
The old `STOP ENGINE` / `START ENGINE` terminology is replaced with:

- `PAUSE AI`
- `START AI`
- `AI TRADING ACTIVE`
- `AI PAUSED`

The currently selected `AI TRADING` or `MANUAL` profile is also shown in the top bar.

## Market Intelligence readability
The right-side intelligence panel now uses larger value text and is renamed `MARKET INTELLIGENCE`. Currency-only exposure has been replaced by multi-market portfolio exposure while FX Strength remains clearly identified as Forex-specific.

## Safer portfolio handling
Risk is adjusted by market class in AI TRADING mode. Crypto and Energy receive lower default risk multipliers than Forex. The risk engine also limits category concentration and keeps the existing FX shared-currency concentration gate.

## Update migration
Updating from V2.0 through the app automatically migrates the old 56-symbol configuration to the new 140-instrument universe while preserving database, trade history, positions, settings and logs.

If the old configuration contains aggressive AI risk values, AI TRADING is returned to the protected paper-research caps. MANUAL values remain separately configurable.

## No black console during normal use
Normal Windows startup uses `pythonw.exe`, and the updater restarts the app without opening a command window. `START_FOREX_APP_DEBUG.bat` remains available for troubleshooting only.

## Research note
This remains a synthetic PAPER research build. The synthetic feed validates software behavior, portfolio logic and AI lifecycle; it is not evidence of real-market profitability. Real historical replay / walk-forward validation remains a future validation stage before any live execution build.
