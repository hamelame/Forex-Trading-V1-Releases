# FX // AI v2.5.1 — Expectancy Governor

Built from the ~20-hour / 1,956-trade v2.5.0 run.

Observed baseline:
- Start $20,000 -> about $15,999.83
- Net -$4,000.17 (~-20%)
- 1,313 Stop Loss exits vs 517 Take Profits
- Rolling strategy expectancy remained negative
- REVERSAL was the largest regime-level loss source
- FOREX was the largest asset-class loss source

## Expectancy Governor
Production contexts now move through:
BOOTSTRAP -> PROBATION -> PROVEN or RESEARCH-ONLY

- Unknown contexts receive reduced risk while gathering evidence.
- REVERSAL starts at only 0.10x governor risk.
- FOREX bootstrap risk is capped at 0.20x.
- A context needs adequate sample size, positive expectancy/PF and positive validation evidence to earn PROVEN/full governor risk.
- Negative context, FastGuard, SymbolGuard or broad asset/regime evidence can move a setup to RESEARCH-ONLY.
- Opportunity Recovery cannot override a Governor RESEARCH-ONLY verdict.

## Broad regime guard
The learner now maintains rolling asset-class + regime statistics.
A regime that is repeatedly negative across many symbols can be removed from production trading instead of continuing thousands of similar trades.

## Global expectancy risk control
The most recent PAPER trades control an additional portfolio-wide risk multiplier:
- insufficient evidence: 0.50x
- negative expectancy/PF: 0.35x
- severely negative run: 0.18x
- near-neutral probation: 0.60x
- healthy positive evidence: 1.00x

This reduces capital burn while research continues.

## Existing protections retained
FastGuard, SymbolGuard, adaptive symbol loss cooldown, global entry pacing,
Deep Recovery, catastrophic stop, execution realism, FX risk math and all
liveness watchdogs remain enabled.
