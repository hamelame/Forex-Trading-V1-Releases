# FX // AI v2.8.1 — Regime Hotfix

- Fixed Command Center / execution error: `cannot access local variable 'regime' where it is not associated with a value`.
- Root cause: `_open()` created a local variable named `regime`, shadowing the imported `regime()` classifier used by the fallback lookup.
- `_open()` now consistently uses the already-resolved `rg` value.
- No strategy thresholds, PAPER-only execution rules, or Neural Edge SHADOW-only authority were changed by this hotfix.
