# Forex Trading V2.0.0 — FX Research Brain v2 (PAPER ONLY)

## FX Research Brain v2
- New research-first Champion brain for synthetic/paper Forex testing.
- Independent specialists:
  - Trend / momentum continuation
  - Mean reversion / range trading
  - Volatility / breakout
- Regime-dependent specialist weights.
- Cross-pair currency-strength confirmation.
- Specialist agreement/consensus gate.
- Explicit WAIT state when edge or agreement is weak.
- Stronger thresholds in high-volatility and thin-liquidity states.
- Spread, data-quality and session safety blocks.

## Adaptive paper risk
- Base paper risk reduced to 0.40% per approved trade.
- Portfolio risk cap reduced to 1.60%.
- Dynamic risk multiplier reduces trade risk when confidence/regime quality is weaker.
- Daily loss circuit breaker reduced to 2.0%.
- Consecutive-loss breaker reduced to 3 losses.
- Longer same-symbol re-entry cooldown.

## Trade management
- Break-even protection after configurable R gain.
- ATR-based trailing protection after configurable R gain.
- Existing Stop Loss / Take Profit / AI Reversal / Max Hold exits remain deterministic.
- Stops are only tightened; research logic never widens initial risk.

## Hard PAPER-only lock
- This build always starts in PAPER mode with the synthetic feed.
- MT5 / real broker execution is intentionally disabled.
- Editing config cannot make this build send live orders.

## Config migration
- Existing installations updated through GitHub keep their database/settings/history.
- Missing V2 research controls are added automatically after update.
- Aggressive legacy paper-risk settings are capped to the V2 research safety limits.

## Startup
- Normal Windows startup uses pythonw.exe so users do not see a black CMD window.
- START_FOREX_APP_DEBUG.bat remains available only for troubleshooting.

## Important
- This is a research candidate, not a claim of guaranteed profitability.
- Carry/macro signals are not faked; they remain disabled until real rate/forward/macro data is connected.
