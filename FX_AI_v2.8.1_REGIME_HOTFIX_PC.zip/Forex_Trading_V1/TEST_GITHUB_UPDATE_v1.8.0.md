# Test the in-app GitHub update

Use the existing installed/extracted V1.7.0 as the OLD app.
Use this V1.8.0 folder only to publish the NEW release.

1. Extract V1.8.0 to a separate folder.
2. In the V1.8.0 folder, run `PUBLISH_RELEASE.bat`.
3. Wait for: `SUCCESS - GitHub Release v1.8.0 is published.`
4. Do NOT start V1.8.0 for the update test.
5. Open your old V1.7.0 app.
6. Go to Settings -> CHECK FOR UPDATES.
7. It should detect v1.8.0 from `hamelame/Forex-Trading-V1-Releases`.
8. Confirm the update.
9. The app should download the ZIP, preserve user data/settings/database/open positions/logs, install program files, and restart.
10. After restart, verify the footer/Settings shows v1.8.0.

If the publisher says authentication is required, run `gh auth login` once.
