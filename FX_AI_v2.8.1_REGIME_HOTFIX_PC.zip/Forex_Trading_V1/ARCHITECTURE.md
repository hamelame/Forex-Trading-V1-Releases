# Forex Trading V1 Architecture

## Independent modules
1. Market Adapter — Synthetic now; MT5 adapter scaffold.
2. Feature Layer — EMA trend, RSI, ATR proxy, momentum, session context.
3. AI Decision Layer — Champion + independent Challengers.
4. Risk & Safety Engine — sizing, portfolio risk, spread gate, daily-loss and consecutive-loss breakers.
5. Execution Layer — paper only in V1.
6. Persistence — SQLite decisions, closed trades, equity and experiments.
7. UI — Command Center, Markets, Positions, Decision Feed, Performance, Shadow, Data Quality, Settings.

## Interfaces reserved for future versions
- Economic Calendar / News Risk Engine
- Multi-timeframe feature stack
- Correlation/beta-style FX exposure groups (USD/EUR/JPY factor risk)
- Walk-forward replay and ablation
- AI Autopsy + hypothesis generation
- Champion promotion gates
- OOD / drift detector
- Backup/Restore
- Telegram
- Broker-neutral execution API
- Live Safety Wizard + kill switches
- Optional common AI Trading Suite shell

## Promotion philosophy
Trade → Observe → Autopsy → Hypothesis → Shadow Test → Replay/Validation → Promotion.
No Challenger should self-promote directly to production.
