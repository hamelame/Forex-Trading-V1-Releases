# Publisher Internet Update Channel

The application-side internet updater is implemented.

To make a released build capable of discovering future versions automatically, a permanent public release endpoint must be assigned before distribution. Set either:

- `DEFAULT_GITHUB_REPO = "owner/repository"` in `forex_app/release_channel.py`, with future ZIP files published as GitHub Release assets; or
- `DEFAULT_MANIFEST_URL = "https://.../release.json"` in `forex_app/release_channel.py`.

Once either constant is set, end users do not enter anything. They only use **Check for Updates**.

The updater:
1. checks the publisher channel,
2. shows version/changelog,
3. downloads the ZIP,
4. verifies ZIP integrity (and SHA-256 when the manifest supplies one),
5. preserves `config.json`, `data/`, `logs/`, and `backups/`,
6. backs up program files,
7. installs the new program files,
8. restarts the app.

This repository/manifest must exist on the public internet; the ChatGPT sandbox attachment URL is not a permanent release server.
