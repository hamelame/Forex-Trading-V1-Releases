@echo off
cd /d "%~dp0"
title FX AI - Publish GitHub Release
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\publish_release.ps1"
if errorlevel 1 (
  echo.
  echo Release publishing did not complete.
  pause
)
