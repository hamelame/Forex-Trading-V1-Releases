# FX // AI v2.4.7 — Persistent Trading / Opportunity Recovery

## Decision-layer liveness fix
- Adds a second liveness layer above RiskEngine and execution.
- If the AI has portfolio capacity but produces no executable BUY/SELL for a sustained period, it enters bounded Opportunity Recovery.
- Opportunity Recovery re-evaluates the same market universe with only modest PAPER-only threshold relaxation.
- Hard BLOCK rules, spread limits, data-quality rules, exposure gates and emergency safety are never bypassed.
- Opportunity Recovery trades use reduced 0.35x strategy risk before the normal RiskEngine multiplier is applied.
- A successful new position immediately clears decision/execution starvation counters.

## Existing execution watchdog preserved
- BUY/SELL candidates that are blocked downstream still trigger the execution-starvation watchdog.
- Stale selector/recovery states are rechecked without resetting learning history.

## Version synchronization
- Window title, sidebar, footer, Settings/Update Center, What's New and updater now use package `__version__` as the single version source.

## Counterfactual display
- Command Center now shows `500 / 500 ACTIVE MEMORY` when the rolling replay memory is full.
- Subtitle clarifies that the buffer is continuously updated.

## AI Decision Feed readability
- Decision cards, instrument names, metadata, confidence gauge and action controls are slightly larger.
- Layout and visual style are otherwise unchanged.
