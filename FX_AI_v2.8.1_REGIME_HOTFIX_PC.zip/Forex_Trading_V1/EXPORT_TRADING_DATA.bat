@echo off
cd /d "%~dp0"
python EXPORT_TRADING_DATA.py
echo.
pause
