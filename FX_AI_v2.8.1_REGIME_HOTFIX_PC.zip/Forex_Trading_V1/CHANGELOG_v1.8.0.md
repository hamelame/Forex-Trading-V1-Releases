# Forex Trading V1.8.0 — HD Readability + Stable Feed + Update Test

## Command Center
- Significantly larger chart area with more readable candles and price scale.
- Top AI Opportunities is intentionally smaller so the chart remains the main focus.
- Opportunity list remains scrollable.
- More detailed instrument identity is shown directly in the market rows:
  symbol + full currency names + market category.

## AI Decision Feed
- Fixed the black flashing/flicker during live updates.
- Decision cards now use a persistent pool and update values in-place instead of destroying/rebuilding the whole feed.
- Instrument name, market category, action, AI score, confidence, regime and explanation are clearer.
- Fewer cards are shown at once for faster, calmer rendering.

## Settings
- Trading & Risk Controls now have proper vertical scrolling.
- Fixed the clipped UI Rerank Interval control.
- Added clear help text explaining every setting.

## GitHub updater
- Release channel remains permanently configured to:
  hamelame/Forex-Trading-V1-Releases
- Publisher script handles first/new releases without the old release-not-found crash.
- Publisher uses the current changelog as GitHub Release notes.
- The application updater still preserves settings, database, open positions, trade history and logs.

## Existing trading functionality
- FX Council, 56-instrument scanner, paper trading, deterministic exits, persistent positions/balance, risk gates and performance tracking are preserved.
