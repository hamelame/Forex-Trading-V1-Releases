# FX // AI v2.4.6 — Execution Liveness / Never-Stale Recovery

## Root cause fixed
- Daily Loss (2%) and Weekly Loss (4%) were still permanent entry gates.
- On a $1,000 paper account this could freeze all new trades after roughly $20 / $40 of loss even though the AI Brain continued generating BUY/SELL decisions.

## New adaptive lifecycle
- Daily/weekly soft protection now uses:
  NORMAL -> COOLDOWN -> RECOVERY -> NORMAL
- Cooldown advances once per active AI scan.
- After cooldown the soft day/week anchors are rebased to current closed balance.
- Recovery entries use 0.20x risk.
- A profitable recovery trade returns the soft-loss state to NORMAL.

## Emergency safety retained
- Session start balance is never rebased.
- A 10% session loss is an independent EMERGENCY hard stop.
- High-water emergency protection remains separate.
- User STOP and PAPER-only execution protections are unchanged.

## Execution liveness watchdog
- Tracks scans where executable BUY/SELL candidates exist but no new position can open.
- After 90 starvation scans it rechecks stale recoverable states and forces selector turnover.
- The watchdog never bypasses EMERGENCY safety or user-disabled trading.

## Existing systems preserved
- Multi-Market Research Brain v2
- Self-Learning Engine
- Counterfactual learning
- Execution-Realistic Paper Mode
- Underlying/exposure diversification
- High-water drawdown recovery
- Trade-ready shortlist deadlock fix
