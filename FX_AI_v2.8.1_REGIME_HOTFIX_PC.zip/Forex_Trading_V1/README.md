# FX // AI v2.7.0

Default mode is **LIVE market data + PAPER execution**. Live market data is informational input only; the application does not submit broker orders. If live candles are unavailable or stale, the engine does not synthesize replacement prices and does not open a new position on that instrument.

Neural Edge Brain v1 runs in **SHADOW** mode. It records predictions for later validation but has zero execution authority in v2.7.0.

# Forex Trading V1.2 — Modern UI v1.1.0

Standalone AI-assisted Forex research and paper-trading application.

## Core design
- Forex-native: pips, lots, spread, sessions, ATR-based stops, margin-aware sizing.
- Modes: Research, Paper, Shadow, Live Locked.
- AI Brain with explainable factor scores (not hidden chain-of-thought).
- Champion + Challenger shadow brains.
- Independent Risk & Safety Engine.
- Market/Data Quality monitoring.
- SQLite persistence for decisions, trades, equity and experiments.
- Replay-ready architecture.
- Broker adapters: Synthetic demo feed included; MetaTrader 5 adapter scaffold included.
- Designed to remain standalone, but interfaces are clean enough for a later optional merge.

## Safety defaults
Live execution is intentionally locked in V1. Paper trading is the default.
No strategy is represented as profitable. Validate with realistic spreads/slippage and out-of-sample testing before any live use.

## Start on Windows
1. Extract the ZIP.
2. Double-click `START_FOREX_APP.bat`.

Or:
```bash
python main.py
```

## Optional MT5 support
Install MetaTrader 5 terminal and:
```bash
pip install MetaTrader5
```
Then change `broker` in `config.json` to `mt5`. V1 reads MT5 market data but live order execution remains locked.

## Main tabs
- Command Center
- Markets
- Open Positions
- AI Decision Feed
- Performance Lab
- Shadow Lab
- Data Quality
- Settings


## v1.1.0 UI update
- New modern sidebar navigation.
- Redesigned Command Center with KPI cards and AI Snapshot.
- Cleaner dark trading layout and higher-density tables.
- BUY / SELL / WAIT / BLOCK status coloring.
- Modern Performance Lab KPI cards.
- Improved Settings and Data Quality presentation.
- Trading engine and paper-safety architecture intentionally kept unchanged.


## V1.2 update
- Modernized FX terminal layout and faster 1-second scan loop.
- Start/Stop Engine and manual refresh controls.
- 33-instrument FX universe including majors, crosses, USDNOK/EURNOK and SEK pairs.
- Market Scanner ranking and first Forex-specific regime layer.
- Currency exposure / portfolio heat visibility.
- Editable in-app risk and trading settings with Save & Apply.
- Refresh Trade Log control.
- Updater foundation with user data kept separate from program code.


## V1.3.0 updater setup
The updater client is fully implemented, but it needs a permanent internet release location.

Recommended:
1. Create a GitHub repository for releases.
2. In Settings → Internet Updates, enter `owner/repository`.
3. Publish each future build as a GitHub Release with a ZIP asset.
4. The app will use the GitHub Releases API to find, download and install the newest version.

Alternative:
Host `release_manifest_template.json` as a public static JSON file, fill in the version, ZIP URL, SHA-256 and changelog, then paste that manifest URL into Settings.

User data is preserved across program updates.
