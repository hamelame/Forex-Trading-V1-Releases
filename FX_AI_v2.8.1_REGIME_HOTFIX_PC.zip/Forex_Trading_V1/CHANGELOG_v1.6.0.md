# Forex Trading V1.6.0 — Smooth Terminal + Persistent FX Paper Trading

## Modern terminal UI
- Refined darker premium visual system across the app.
- Candlestick-style selected-market chart with price scale and current-price marker.
- Markets page now has search and category filters.
- Open Positions now has summary cards plus deterministic lifecycle columns.
- Performance Lab now includes a live equity curve.
- Command Center retains full wrapped AI analysis without an off-screen reason column.
- Fixed-width live status area prevents toolbar controls from shifting when messages change length.

## No-jump live updates
- Engine scanning and UI rendering now run on separate cadences.
- Only the visible workspace is rendered.
- Market ranking order is stabilized and only reranked periodically instead of every quote tick.
- Decision Feed card rebuilding is throttled.
- Scroll, selection and manually locked chart state remain preserved.
- Selected AI Analysis has a fixed height to avoid vertical layout reflow.

## Forex AI / paper trading
- FX Council v1 remains the production paper brain.
- Trend/momentum, reversal/range and volatility/breakout specialists remain regime-weighted.
- Cross-pair currency-strength confirmation remains active.
- Added deterministic trade lifecycle:
  - Stop Loss
  - Take Profit
  - FX Council Reversal
  - Max Hold Exit
- Removed random time-proxy exits.
- Added per-symbol re-entry cooldown.
- Added editable AI/execution controls in Settings.
- Currency-concentration and total-risk gates remain independent.

## Persistent research sessions
- Paper balance/equity now restore from the database after restart.
- Open paper positions persist across restart.
- Daily risk baseline restores from the current day's first recorded balance.
- This makes multi-day paper testing materially more useful.

## GitHub updates
- Publisher repository remains `hamelame/Forex-Trading-V1-Releases`.
- Added `PUBLISH_RELEASE.bat` plus a PowerShell publisher helper.
- The publisher installs GitHub CLI if necessary, performs one-time browser authentication, packages the build, and creates/updates the GitHub Release.
- End-user application updates continue through Settings -> Check for Updates.

## Scope
- Still PAPER / SYNTHETIC by default.
- Live order execution remains locked.
