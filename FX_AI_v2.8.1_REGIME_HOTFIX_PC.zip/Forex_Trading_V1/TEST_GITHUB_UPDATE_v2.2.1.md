# Publish and test V2.2.1

1. Extract V2.2.1 to its own folder.
2. Run `PUBLISH_RELEASE.bat`.
3. Wait for `SUCCESS - GitHub Release v2.2.1 is published.`
4. Open V2.2.0.
5. Settings -> CHECK FOR UPDATES.
6. Install V2.2.1.
7. Confirm Settings shows the Update Center at the top-right.
8. Set Paper Trading Capital to a value between $1,000 and $100,000 and Save & Apply.
9. Pause AI, then Start AI.
10. Verify Balance/Equity reset to the selected capital, Realized P/L is $0.00 and Open Positions starts at 0.
11. Open Shadow Lab and test AUTO TOP 5 / AUTO TOP 10 / MANUAL plus market-class toggles.

V2.2.1 remains PAPER + SYNTHETIC only.
