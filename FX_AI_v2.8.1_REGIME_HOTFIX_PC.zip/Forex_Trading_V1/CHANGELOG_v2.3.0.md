# FX // AI v2.3.0 — AI Terminal Redesign

## Major UI foundation
- Fixed the shared KPI rendering bug that caused value areas to appear blank across Command Center, Shadow Lab, Trade Log, Performance Lab and Data Quality.
- Synchronized the canonical application version so the window title, sidebar, update center and updater all report v2.3.0.
- Refined the dark terminal layout, semantic status colors and readable live-state presentation.

## What's New
- Added a dedicated What's New page.
- It opens automatically the first time each newly installed version starts.
- The seen-version state is stored separately in data/ui_state.json so it survives future program updates.
- What's New remains available in the sidebar after the first launch.

## AI Decision Feed 2.0
- Rebuilt decision cards around the visual concept approved during design.
- BUY / SELL / WAIT / BLOCK live KPI cards.
- Key Factors chips for Trend, Mean Reversion, Breakout, Consensus, RSI, ATR, Spread and Session.
- Confidence gauge and STRONG / MODERATE / WEAK edge-quality verdict.
- Larger typography, clearer AI verdict and action-colored card borders.
- Decision feed continues to expose concise model factors and explanations rather than hidden chain-of-thought.

## Command Center
- Balance, Equity, Realized P/L, Unrealized P/L, Open Positions, Portfolio Heat and AI Engine values now render reliably.
- Realized and Unrealized P/L use green for profit, red for loss and neutral for zero.
- Added permanent AI HEARTBEAT showing engine state, scan count, scanned/eligible/selected/trade-ready counts, open positions and latest engine event.
- Protective mode remains visible while the engine continues market analysis.

## Markets
- Added Scanned / Eligible / Selected / Trade-Ready KPI cards.
- Added stronger live scanner summary, search and market-class filtering.
- Improved row spacing, alternating dark rows and action-aware color treatment.

## Shadow Lab
- Fixed Scanned / Eligible / Selected / Trade-Ready values.
- Retains separate Eligible Market Candidates and AI Selected views.
- Shadow Lab remains the single source of truth for allowed market classes.
- Existing strict duplicate-underlying diversification prevents multiple quote-currency versions of the same metal from occupying the automatic shortlist.

## Data Quality
- Rebuilt as a readable health dashboard.
- Feed Health, Healthy Markets, Average Spread and Last Update KPIs.
- HEALTHY / WATCH / CRITICAL classification.
- Market-class and health-status filters.
- Execution-cost labels GOOD / ELEVATED / EXPENSIVE.
- Clear summary of how many markets need caution.

## AI Trade Journal
- Trade Log upgraded into an AI Trade Journal layout.
- Six live KPIs: trades, net P/L, win rate, wins, losses and profit factor.
- Stronger hard-refresh path with direct database commit/read and visible timestamp confirmation.
- ALL / WINS / LOSSES / BUY / SELL filters.
- Added cumulative realized P/L chart and average win/loss summary.

## Performance Lab 2.0
- Replaced the old minimal line graph with a richer equity chart.
- Session-start baseline, high/low markers, current result and filled equity area.
- Added Max Drawdown KPI alongside trades, P/L, win rate, profit factor and expectancy.
- Added average win/loss and session-result summary.

## Refresh UX
- Global refresh now gives visible ✓ REFRESHED feedback.
- Trade Log has its own hard database refresh.
- Shadow Lab retains a dedicated REFRESH MARKET rescan/reselection.
- Manual refresh does not open new entries while AI is paused.

## Safety / architecture
- PAPER + SYNTHETIC only.
- Existing 140-instrument Multi-Market universe preserved.
- Existing runtime paper-capital/risk-baseline fix preserved.
- Existing Pause AI -> Close All / Keep Positions / Cancel behavior preserved.
