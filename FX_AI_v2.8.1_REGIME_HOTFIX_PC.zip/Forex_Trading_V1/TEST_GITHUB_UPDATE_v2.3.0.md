# FX // AI v2.3.0 — Release / Update Test

1. Extract this package to a clean folder.
2. Run the app once and confirm WHAT'S NEW opens automatically.
3. Click CONTINUE TO COMMAND CENTER.
4. Confirm Command Center KPI values are visible.
5. Start AI and confirm AI HEARTBEAT updates scan / eligible / selected / trade-ready / positions.
6. Open AI Decision Feed and confirm factor chips + confidence gauge render.
7. Open Markets and confirm scanner KPI values and filters.
8. Open Shadow Lab and confirm SCANNED / ELIGIBLE / SELECTED / TRADE-READY contain values.
9. Open Data Quality and test CLASS + STATUS filters.
10. Open Trade Log and click REFRESH TRADE LOG; confirm the visible refresh timestamp changes.
11. Open Performance Lab and confirm the new equity chart + Max Drawdown.
12. Run PUBLISH_RELEASE.bat. It reads version 2.3.0 from config.json.
13. From an older installed version, Settings -> CHECK FOR UPDATES should discover v2.3.0.

PAPER + SYNTHETIC ONLY.
