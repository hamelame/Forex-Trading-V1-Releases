# FX // AI V2.2.1 — UI Polish + Paper Session Stability

## Paper session reset
- Every application launch begins a fresh visible PAPER session.
- Starting AI after a pause begins a new paper session.
- Balance and Equity reset to the selected Paper Trading Capital.
- Realized P/L resets to $0.00 for the new session.
- Open paper positions reset to zero.
- Current-session Performance Lab and equity sparklines reset visually.
- Historical closed trades remain stored for future AI research.

## Paper Trading Capital
- New Settings control for Paper Trading Capital.
- Allowed range: $1,000 to $100,000 USD.
- The selected capital becomes the starting Balance/Equity for every new paper session.

## UI readability
- Slightly increased overall UI scaling.
- Wider sidebar and larger navigation controls.
- Larger Settings names, explanations and input values.
- Normal UI text that was white is now warm yellow.
- Market/instrument identity remains neutral, while BUY/profit stays green and SELL/loss stays red.

## Command Center
- Portfolio Heat gauge moved farther right and reduced slightly to prevent overlap with the percentage value.
- Current-session Balance / Equity / Realized P/L now reflect the fresh paper session correctly.

## Shadow Lab
- Selection mode now uses modern segmented controls:
  - AUTO TOP 5
  - AUTO TOP 10
  - MANUAL
- Market-class selectors now use modern pill/toggle controls.
- Manual-symbol input received a cleaner container.
- Existing 140-market Selection Engine and Multi-Market AI architecture are preserved.

## Settings
- Update Center moved to the top-right of Settings so CHECK FOR UPDATES remains visible.
- Market-class controls and AI specialist/safety controls use modern toggles.
- Multi-Market AI Trading remains the main architecture for Forex, Metals, Energy, Indices and Crypto.

## Safety
- Still 100% PAPER + SYNTHETIC.
- No live broker / MT5 execution.
- GitHub update channel remains unchanged.
