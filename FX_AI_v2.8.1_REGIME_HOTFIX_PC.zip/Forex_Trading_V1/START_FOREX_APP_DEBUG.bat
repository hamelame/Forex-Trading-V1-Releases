@echo off
cd /d "%~dp0"
title FX AI - Debug Console
python main.py
if errorlevel 1 (
  echo.
  echo App exited with an error.
  pause
)
