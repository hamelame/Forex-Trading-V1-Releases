# Release workflow

Repository: `hamelame/Forex-Trading-V1-Releases`

For the publisher:
1. Extract the new build.
2. Run `PUBLISH_RELEASE.bat`.
3. The first run may install GitHub CLI and open a browser for one-time GitHub login.
4. The script packages the application and publishes the current config version as the latest GitHub Release.

For installed applications:
1. Open Settings.
2. Click `CHECK FOR UPDATES`.
3. The updater checks GitHub Releases, downloads the newer ZIP, preserves config/data/logs/backups, installs program files, and restarts.

ChatGPT itself does not have authenticated write access to the GitHub account, so the publisher script performs the upload from the owner's Windows PC.
