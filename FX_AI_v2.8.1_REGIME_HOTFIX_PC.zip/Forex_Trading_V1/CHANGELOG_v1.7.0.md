# Forex Trading V1.7.0 — Reference UI Rebuild

## Command Center master-reference rebuild
- Rebuilt the dashboard around the supplied FX // AI master reference.
- New compact terminal shell, denser sidebar, reference-style header and bottom status strip.
- Added **Realized P/L** directly to Command Center.
- Added portfolio heat ring and AI engine visual state.
- Added sidebar Engine Running sparkline and Risk Mode card.
- Added reference-style FX Intelligence rows with status icons and system-health banner.
- Added persistent Market Watch strip with live price, percentage move and mini sparklines.
- Retained manually locked chart behavior and stable live-update architecture.

## Visual system
- Dark navy/black terminal palette with cyan/green intelligence accents.
- Smaller, denser tables and cards matching the reference proportions more closely.
- Global shell applies to Markets, Positions, Decision Feed, Performance, Shadow, Data Quality and Settings.

## Trading / persistence
- FX Council, deterministic paper exits, persistent positions, persistent equity, risk engine and 56-market scanner are preserved from v1.6.0.

## GitHub publisher
- Bundles the corrected publisher that handles an empty repository/first release without failing on `release not found`.
