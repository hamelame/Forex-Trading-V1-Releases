# FX // AI v2.4.9 — Deep Recovery + SymbolGuard

## Why the overnight run stopped
- The latest database ended around $899.71 from a $1,000 paper-session start.
- That is a session loss slightly above 10%.
- v2.4.8 intentionally treated 10% session loss as an EMERGENCY hard stop, so the AI continued scanning but correctly refused every new order.
- This looked like another deadlock even though the safety system was the actual cause.

## New deep-recovery lifecycle
- 10% session loss is no longer a permanent stop.
- It now enters:
  NORMAL / RECOVERY -> DEEP COOLDOWN -> DEEP RECOVERY
- Deep Recovery resumes paper entries at 0.10x risk.
- Deep Recovery remains active until session loss improves below 7.5%.
- Daily/weekly and 6% high-water protections continue to operate as adaptive cooldown/recovery layers.
- Only a catastrophic 20% session loss or 20% high-water drawdown remains a permanent EMERGENCY hard stop.

## SymbolGuard learning
- Self-Learning now tracks recent performance by symbol + direction in addition to broad asset/regime/session context.
- Robust R statistics clip historic outliers so old simulator bugs cannot poison learning forever.
- Repeated weak symbol/direction combinations receive stronger bounded score/confidence penalties.
- A sufficiently large and clearly poor sample is temporarily suppressed to WAIT instead of being selected repeatedly.
- New positive evidence can naturally rehabilitate the symbol/direction later.

## Existing fixes preserved
- Quote-currency-aware FX pip values.
- Safe minimum-lot rejection.
- Bounded stop-loss execution.
- Opportunity Recovery and execution liveness watchdogs.
- One shared app version source.
