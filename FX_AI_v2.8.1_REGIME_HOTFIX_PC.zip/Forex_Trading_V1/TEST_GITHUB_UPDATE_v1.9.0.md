# Publish and test V1.9.0

1. Extract this V1.9.0 build to its own folder.
2. Run `PUBLISH_RELEASE.bat` from the V1.9.0 folder.
3. Wait for: `SUCCESS - GitHub Release v1.9.0 is published.`
4. Open your currently installed V1.8.0 app.
5. Go to Settings -> CHECK FOR UPDATES.
6. Confirm that V1.9.0 is offered.
7. Click Yes to download/install.
8. After restart verify the title/footer/settings reports v1.9.0.

The updater preserves config, database, open positions, trade history, logs, backups and release-channel configuration.
