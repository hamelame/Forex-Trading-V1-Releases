# Forex Trading V1.4.0 — Premium UI Overhaul

## Major visual update
- Rebuilt the app around a darker premium FX // AI terminal style.
- Stronger typography hierarchy, cleaner panels, modern action buttons and more breathing room.
- Kept the design original while moving closer to the premium trading-terminal reference direction.

## Command Center
- Chart no longer jumps between markets every scan.
- Default chart behavior is LOCKED.
- Click a row in Top AI Opportunities or Markets to select that market and lock the chart.
- Optional AUTO mode uses a hold period and score advantage before switching.
- Clearer chart header with symbol, instrument name, category, regime, AI score, market score and spread.

## AI Decision Feed 2.0
- Replaced the old dense table with modern scrollable decision cards.
- Separate instrument identity, action badge, score, confidence, regime, parsed factor chips and AI reason.
- Stable scroll position during refresh.
- Summary cards for latest cycle and BUY / SELL / WAIT / BLOCK counts.

## Trade Log
- New dedicated Trade Log page.
- Manual REFRESH TRADE LOG button.
- Instrument, side, lots, entry, exit, realized P/L, R, exit reason, close time and brain.
- Summary cards for total trades, net P/L, wins and losses.

## Data Quality 2.0
- Summary cards for feed health, healthy-market count, average spread and freshness.
- Neutral readable rows instead of coloring the entire table green.
- Human-readable instrument names and clearer status labels.

## Stability
- Mouse-wheel scrolling preserved.
- Tree tables update in-place where possible and preserve scroll/selection.
- Trading/AI core intentionally kept close to V1.3.0 while the UI is modernized.
