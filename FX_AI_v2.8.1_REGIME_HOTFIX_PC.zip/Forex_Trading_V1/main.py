import json, tkinter as tk
import sys
from pathlib import Path
from forex_app import __version__
from forex_app.database import Database
from forex_app.market import SyntheticFeed, MT5Feed
from forex_app.live_market import LiveMarketFeed
from forex_app.engine import TradingEngine
from forex_app.ui import App
from forex_app.instruments import DEFAULT_UNIVERSE

CONFIG_PATH=Path("config.json")

def load_config():
    with CONFIG_PATH.open("r",encoding="utf-8") as f:
        cfg=json.load(f)

    changed=False
    defaults={
        "paper_only_build":True,
        "market_data_mode":"LIVE",
        "live_data_refresh_seconds":20.0,
        "live_data_stale_seconds":180.0,
        "live_data_delayed_stale_seconds":1200.0,
        "live_data_timeout_seconds":8.0,
        "live_data_workers":20,
        "scan_interval_seconds":2.0,
        "neural_edge_enabled":True,
        "neural_edge_shadow_only":True,
        "neural_edge_learning_rate":0.025,
        "min_signal_score":63,
        "risk_per_trade_pct":0.4,
        "max_total_risk_pct":1.6,
        "daily_loss_limit_pct":2.0,
        "max_consecutive_losses":3,
        "min_risk_multiplier":0.35,
        "break_even_at_r":0.75,
        "trail_start_r":1.25,
        "trail_atr_mult":1.0,
        "entry_cooldown_scans":18,
        "opposite_exit_score":76,
        "trading_profile":"AI TRADING",
        "enabled_asset_classes":["FOREX","METALS","ENERGY","INDICES","CRYPTO"],
        "min_consensus_pct":66.0,
        "min_confidence":56.0,
        "min_edge":20.0,
        "weekly_loss_limit_pct":4.0,
        "max_drawdown_pct":6.0,
        "emergency_drawdown_pct":10.0,
        "max_category_positions":2,
        "min_data_quality":75.0,
        "category_risk_forex":1.0,
        "category_risk_metals":0.8,
        "category_risk_energy":0.7,
        "category_risk_indices":0.85,
        "category_risk_crypto":0.55,
        "allow_rollover_session":False,
        "use_currency_strength":True,
        "use_trend_specialist":True,
        "use_mean_reversion_specialist":True,
        "use_breakout_specialist":True,
        "use_rsi_intelligence":True,
        "pause_on_high_volatility":False,
        "allow_asia_session":True,
        "allow_london_session":True,
        "allow_new_york_session":True,
        "allow_overlap_session":True,
        "manual_risk_per_trade_pct":0.4,
        "manual_max_total_risk_pct":1.6,
        "manual_min_signal_score":63,
        "selection_mode":"AUTO TOP 10",
        "selection_refresh_scans":12,
        "selection_hysteresis_points":3.0,
        "selection_min_market_score":58.0,
        "selection_min_ai_score":63.0,
        "selection_min_confidence":56.0,
        "selection_min_data_quality":75.0,
        "selection_max_spread":2.5,
        "manual_selected_symbols":["EURUSD","GBPUSD","USDJPY","XAUUSD","US100","BTCUSD"],
        "max_currency_exposure_positions":2,
        "ui_refresh_ms":900,
        "paper_trading_capital":20000.0,
        "self_learning_enabled":True,
        "counterfactual_learning_enabled":True,
        "learning_min_samples":24,
        "learning_promotion_samples":40,
        "learning_min_expectancy_r":0.05,
        "learning_min_profit_factor":1.10,
        "learning_min_win_rate":40.0,
        "counterfactual_horizon_scans":12,
        "loss_recovery_cooldown_scans":18,
        "loss_recovery_risk_multiplier":0.40,
        "limit_recovery_cooldown_scans":45,
        "limit_recovery_risk_multiplier":0.20,
        "emergency_session_loss_pct":10.0,
        "execution_starvation_watchdog_scans":90,
        "opportunity_recovery_enabled":True,
        "opportunity_recovery_after_scans":45,
        "opportunity_recovery_risk_multiplier":0.35,
        "counterfactual_memory_capacity":500,
        "paper_min_lot":0.01,
        "paper_lot_step":0.01,
        "paper_max_lot":5.0,
        "min_lot_risk_tolerance":1.10,
        "paper_stop_slippage_base_pips":0.12,
        "paper_stop_slippage_spread_factor":0.15,
        "paper_stop_slippage_atr_factor":0.006,
        "max_execution_cost_r":0.20,
        "weak_regime_max_execution_cost_r":0.14,
        "proven_max_execution_cost_r":0.24,
        "max_execution_cost_share_of_reward":0.12,
        "paper_maker_commission_per_lot_side_usd":1.75,
        "paper_passive_limit_extra_no_fill_pct":9.0,
        "paper_marketable_limit_extra_no_fill_pct":1.2,
        "paper_expected_exit_slippage_factor":0.80,
        "paper_slippage_cap_spread_mult":1.4,
        "paper_slippage_cap_atr_mult":0.08,
        "paper_high_atr_reference":30.0,
        "paper_liquidity_ref_lots_forex":1.5,
        "paper_liquidity_ref_lots_metals":0.55,
        "paper_liquidity_ref_lots_energy":0.45,
        "paper_liquidity_ref_lots_indices":0.80,
        "paper_liquidity_ref_lots_crypto":0.30,
        "paper_crypto_funding_interval_hours":8.0,
        "paper_crypto_funding_abs_rate_per_interval":0.00010,
        "learning_side_window":50,
        "governor_side_min_samples":20,
        "governor_side_block_expectancy_r":-0.12,
        "governor_side_block_pf":0.82,
        "governor_side_negative_risk_mult":0.25,
        "trend_direction_min_momentum":0.10,
        "high_vol_direction_min_momentum":0.22,
        "directional_setup_gate_enabled":True,
        "execution_economics_gate_enabled":True,
        "rsi_conflict_score_penalty":8.0,
        "trend_min_rsi_structure_support":-15.0,
        "high_vol_min_rsi_structure_support":-8.0,
        "reversal_max_opposing_momentum":0.32,
        "range_rsi_buy_zone":42.0,
        "range_rsi_sell_zone":58.0,
        "rsi_pattern_learning_enabled":True,
        "learning_rsi_pattern_window":60,
        "rsi_pattern_min_samples":14,
        "rsi_pattern_block_expectancy_r":-0.18,
        "rsi_pattern_block_pf":0.72,
        "rsi_pattern_negative_risk_mult":0.30,
        "rsi_pattern_proven_expectancy_r":0.08,
        "rsi_pattern_proven_pf":1.12,
        "deep_session_loss_pct":10.0,
        "deep_recovery_cooldown_scans":180,
        "deep_recovery_risk_multiplier":0.10,
        "deep_recovery_exit_loss_pct":7.5,
        "catastrophic_session_loss_pct":20.0,
        "catastrophic_drawdown_pct":20.0,
        "learning_symbol_recent_window":12,
        "learning_symbol_min_samples":6,
        "learning_symbol_penalty_pf":0.90,
        "learning_symbol_penalty_scale":12.0,
        "learning_symbol_penalty_max":12.0,
        "learning_symbol_block_samples":10,
        "learning_symbol_block_expectancy_r":-0.30,
        "learning_symbol_block_pf":0.65,
        "expectancy_governor_enabled":True,
        "governor_bootstrap_samples":8,
        "governor_proven_samples":16,
        "governor_min_expectancy_r":0.03,
        "governor_min_pf":1.05,
        "governor_research_only_expectancy_r":-0.12,
        "governor_research_only_pf":0.78,
        "governor_bootstrap_risk_mult":0.25,
        "governor_probation_risk_mult":0.40,
        "governor_reversal_bootstrap_risk_mult":0.10,
        "governor_forex_bootstrap_risk_mult":0.20,
        "governor_regime_window":60,
        "governor_regime_min_samples":30,
        "governor_regime_block_expectancy_r":-0.10,
        "governor_regime_block_pf":0.85,
        "governor_fast_veto_expectancy_r":-0.45,
        "governor_fast_veto_pf":0.60,
        "governor_symbol_veto_expectancy_r":-0.25,
        "governor_symbol_veto_pf":0.70,
        "governor_global_window":40,
        "governor_global_min_samples":16,
        "governor_global_bootstrap_risk_mult":0.50,
        "governor_global_severe_expectancy_r":-0.20,
        "governor_global_severe_pf":0.70,
        "governor_global_severe_risk_mult":0.18,
        "governor_global_negative_risk_mult":0.35,
        "governor_global_probation_risk_mult":0.60,
        "governor_global_full_expectancy_r":0.05,
        "selection_max_shared_currency":2,
        "selection_max_index_region":2,
        "selection_max_crypto_beta":3,
        "max_shared_exposure_positions":1,
        "max_index_region_positions":1,
        "max_crypto_beta_positions":1,
        "min_after_cost_edge":8.0,
        "edge_spread_penalty":1.6,
        "opposite_exit_confidence":68.0,
        "opposite_exit_confirmations":3,
        "opposite_exit_min_bars":8,
        "opposite_exit_max_profit_r":0.35,
        "break_even_at_r":0.60,
        "trail_start_r":1.00,
        "trail_atr_mult":0.90,
        "learning_validation_min_pf":1.0,
        "learning_drift_window":10,
        "learning_drift_threshold_r":0.30,
        "learning_drift_floor_r":-0.15,
    }
    for key,val in defaults.items():
        if key not in cfg:
            cfg[key]=val; changed=True

    # V2.2 upgrades older 56-symbol installs to the full 140-instrument universe.
    if len(cfg.get("symbols",[])) < 120:
        cfg["symbols"]=list(DEFAULT_UNIVERSE); changed=True

    # V2.2 is intentionally a safe PAPER research build.
    if cfg.get("mode")!="PAPER":
        cfg["mode"]="PAPER"; changed=True
    if cfg.get("broker")!="synthetic":
        cfg["broker"]="synthetic"; changed=True
    if not cfg.get("paper_only_build",False):
        cfg["paper_only_build"]=True; changed=True

    # AI TRADING uses protected research limits. MANUAL remains user-controlled but PAPER only.
    if cfg.get("trading_profile","AI TRADING")=="AI TRADING":
        if float(cfg.get("risk_per_trade_pct",0.4))>0.4:
            cfg["risk_per_trade_pct"]=0.4; changed=True
        if float(cfg.get("max_total_risk_pct",1.6))>1.6:
            cfg["max_total_risk_pct"]=1.6; changed=True
        if float(cfg.get("daily_loss_limit_pct",2.0))>2.0:
            cfg["daily_loss_limit_pct"]=2.0; changed=True
        if int(cfg.get("max_consecutive_losses",3))>3:
            cfg["max_consecutive_losses"]=3; changed=True

    if cfg.get("version") != __version__:
        cfg["version"]=__version__; changed=True

    if changed:
        tmp=CONFIG_PATH.with_suffix(".json.tmp")
        tmp.write_text(json.dumps(cfg,indent=2),encoding="utf-8")
        tmp.replace(CONFIG_PATH)
    return cfg


def enable_windows_hdpi():
    """Enable per-monitor DPI awareness on Windows before Tk creates a window."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass

def main():
    enable_windows_hdpi()
    cfg=load_config()
    # v2.7.1 remains hard PAPER-ONLY. Market data may be LIVE, but execution is simulated.
    cfg["mode"]="PAPER"
    cfg["paper_only_build"]=True
    db=Database()
    if str(cfg.get("market_data_mode","LIVE")).upper()=="LIVE":
        cfg["broker"]="synthetic"  # execution backend remains PAPER-only
        feed=LiveMarketFeed(cfg["symbols"],cfg)
    else:
        cfg["broker"]="synthetic"
        feed=SyntheticFeed(cfg["symbols"])
    engine=TradingEngine(cfg,feed,db)
    root=tk.Tk()
    app=App(root,engine,cfg)
    root.protocol("WM_DELETE_WINDOW",app.close)
    root.mainloop()

if __name__=="__main__":
    main()
