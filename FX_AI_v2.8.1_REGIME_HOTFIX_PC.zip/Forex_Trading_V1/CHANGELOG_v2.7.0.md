# FX // AI v2.7.0 — LIVE DATA + NEURAL EDGE SHADOW

## Core changes
- Added `LiveMarketFeed`: real public 1-minute candles instead of synthetic stepping when `market_data_mode=LIVE`.
- Crypto prefers Binance public 1m klines; supported FX/metals/energy/indices use Yahoo public chart data.
- No synthetic fallback in LIVE mode. Missing/stale feeds are marked unavailable and cannot open new positions.
- Added concurrent universe refresh, feed provider metadata, candle age and explicit LIVE/STALE/NO DATA state.
- Indicators (RSI, EMA20/50, ATR proxy, momentum and regime input) now derive from real candle history in LIVE mode.

## Neural Edge Brain v1
- New small online neural network operating strictly in SHADOW mode.
- Predicts win probability and expected R before eligible BUY/SELL trades.
- Prediction cannot authorize, block, size, open, close or otherwise change Champion execution in v2.7.0.
- Learns only after closed PAPER trades; deterministic 20% holdout examples are validation-only.
- Persists model state to `data/neural_edge_v1.json`.
- Stores pre-trade prediction, feature vector, feed metadata and realized result in `neural_shadow`.
- Trading analysis exporter now includes `neural_shadow.csv`.

## Safety
- Execution remains hard PAPER-only. `broker=synthetic` is retained as the execution safety backend flag even when market data is LIVE.
- Existing v2.6 RSI Intelligence, Self-Learning, Expectancy Governor, risk limits and execution realism remain intact.
