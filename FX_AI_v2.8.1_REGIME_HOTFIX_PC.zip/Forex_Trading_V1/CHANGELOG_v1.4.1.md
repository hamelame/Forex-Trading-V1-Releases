# Forex Trading V1.4.1 — Responsiveness & Critical Fixes

## Chart lock
- LOCKED is now a hard lock.
- A manually selected market remains selected even when scanner rankings change.
- Live refresh is not allowed to overwrite a valid manual chart selection.
- Selected chart symbol is persisted in config.
- Market/Command Center selection is synchronized without event-loop bouncing.

## Readability
- Larger base text across the application.
- Larger Settings labels and input fields.
- Larger table rows and data text.
- Stronger headings and improved readability on 1080p displays.

## Responsiveness
- The AI engine continues scanning in the background.
- Only the currently visible page is rendered on each scan.
- Hidden Decision Feed cards, Data Quality tables, Trade Log, Markets, etc. are no longer rebuilt every cycle.
- Page switches schedule an immediate visible-page refresh.
- Existing smooth wheel scrolling and scroll-position preservation remain enabled.

## Internet updater
- Normal users are no longer asked to enter a GitHub repository or manifest URL.
- The app now uses a publisher-managed release-channel layer.
- Check for Updates remains one-click and supports changelog, ZIP verification, download, install, preserved user data, backup and restart.
- A permanent public release endpoint is still required before the publisher channel can be activated.

## Safety / persistence
- Config writes use an atomic temporary-file replacement to reduce the chance of config corruption during interruption.
