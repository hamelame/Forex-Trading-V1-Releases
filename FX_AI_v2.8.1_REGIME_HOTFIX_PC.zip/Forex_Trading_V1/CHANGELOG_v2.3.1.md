# FX // AI v2.3.1 — Session Reset + Trade Log Hotfix

- Trade Log now defaults to THIS SESSION instead of mixing old historical trades into a fresh paper session.
- ALL HISTORY remains available for research.
- Trade Log hard refresh reloads the selected scope and reports the exact refresh time.
- AI Decision Feed is now session-scoped on a fresh app/session so old decisions do not make the new run look stale.
- Paper session reset now resets balance, equity, scan counter, open positions, selector state and all risk baselines.
- A fresh equity baseline is written immediately at session start/reset.
- Command Center P/L is now split into:
  - REALIZED PROFIT = winning closed trades only.
  - REALIZED LOSS = losing closed trades only.
  - NET REALIZED P/L = wins minus losses.
  - UNREALIZED P/L = open positions only.
  - TOTAL SESSION P/L = net realized + unrealized.
- Command Center KPI layout is now a responsive 5 x 2 grid.
