# FX // AI v2.4.0 — Trading Brain & Self-Learning Foundation

## Multi-Market Research Brain v2
- Mean-reversion signals now require short-term momentum confirmation to reduce falling-knife / rising-rocket entries.
- Regime specialist weighting was recalibrated across TREND, RANGE, REVERSAL, MIXED and HIGH VOL.
- Added an after-spread edge hurdle so weak/high-cost signals remain WAIT.
- Regime-specific stop/target profiles were tightened for RANGE/REVERSAL and kept wider for TREND/HIGH VOL.
- AI Brain Reversal exits require repeated confirmation and a minimum hold period, reducing premature exits from small profitable positions.

## Self-Learning Engine v1
- Every closed PAPER trade stores a structured experience:
  asset class, regime, session, side, AI score, confidence, spread, RSI, ATR,
  Trend/Mean-Reversion/Breakout votes, consensus, P/L, R, MFE, MAE, bars held and exit reason.
- Learning contexts are separated by asset class + regime + side + session.
- Small samples are shrinkage-weighted toward neutral instead of trusted immediately.
- Positive adjustments require PROMOTED evidence; the learner cannot convert WAIT/BLOCK into a trade.
- Negative Challenger evidence may reduce weak-context confidence before promotion.

## Champion / Challenger promotion gate
- RESEARCH: insufficient samples.
- CHALLENGER: minimum sample requirement reached.
- PROMOTED: requires sufficient samples + positive expectancy + minimum profit factor + minimum win rate + positive chronological holdout.
- DRIFT: recent performance materially deteriorated versus older context evidence.
- Chronological validation is used so a context cannot be promoted purely from in-sample aggregate performance.

## Concept Drift
- Recent context expectancy is compared with older evidence.
- Drifted contexts lose trust and receive a bounded score/confidence penalty.
- Drift status is visible in the Command Center Self Learning heartbeat.

## Counterfactual Learning
- BUY/SELL opportunities rejected by the Risk Engine are stored temporarily.
- After a configurable horizon the learner measures the hypothetical R result.
- This provides research evidence about whether safety filters are blocking good or bad opportunities.
- Counterfactual evidence does not automatically bypass Risk Engine rules.

## Adaptive loss recovery
- Three consecutive losses no longer permanently freeze the AI.
- Loss streak -> COOLDOWN for a configurable number of scans.
- After cooldown -> RECOVERY mode at reduced risk.
- A profitable closed trade returns the Risk Engine to NORMAL.
- Daily loss, weekly loss and high-water drawdown remain hard safety barriers.

## Exposure / diversification
- Strict underlying identity blocks duplicate exposure through another quote currency.
- XAUUSD / XAUEUR / XAUGBP = one Gold underlying.
- XAGUSD / XAGEUR / XAGGBP = one Silver underlying.
- Top 5/Top 10 also limits repeated FX currencies, index regions and broad crypto beta.
- Risk Engine repeats the same checks at execution, so a duplicate cannot slip through after selection.

## Live visibility
- Command Center heartbeat now includes Self Learning experiences, Challengers, Promoted contexts, drift alerts and counterfactual replays.
- Risk Engine displays NORMAL / COOLDOWN / RECOVERY with scans remaining and recovery risk multiplier.

## Safety
- PAPER + SYNTHETIC ONLY.
- Self-learning adjustments are intentionally bounded.
- No learned rule can bypass hard drawdown/spread/data-quality/portfolio safety constraints.
