# Self-Learning Architecture v2.4.0

Trade -> Structured Experience -> Context Statistics -> Challenger -> Chronological Validation -> Promotion or Drift

Context:
    Asset Class + Market Regime + Direction + Session

Recorded outcome fields:
    AI Score / Confidence
    Trend / Mean Reversion / Breakout
    Consensus
    Spread / RSI / ATR
    R multiple / P&L
    MFE / MAE
    Bars held / exit reason

Learning rules:
1. Never learn aggressively from a handful of trades.
2. Never promote a WAIT/BLOCK directly into an order.
3. Positive score boosts require a promoted context.
4. Negative evidence can reduce confidence sooner to stop repeating weak setups.
5. Promotion must survive chronological holdout evidence.
6. Concept drift removes trust when recent results deteriorate.
7. Counterfactual blocked trades are research evidence only.
8. Hard safety limits always remain outside the learner.

This is intentionally an evidence-gated learning foundation, not an autonomous
model that rewrites itself after every trade.
