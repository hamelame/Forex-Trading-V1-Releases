# FX // AI v2.4.8 — Risk Math / Exotic FX Safety Fix

## Root cause
- FX pip value was hard-coded to $10 for every pair.
- Exotic quote currencies such as HUF, TRY, ZAR, NOK, SEK, PLN and CZK therefore had incorrect USD risk/P&L conversion.
- Position sizing also forced every computed size up to 0.01 lots. On a small paper account, 0.01 lots could already exceed the approved risk budget by many multiples.
- Stop-loss P/L used the latest synthetic scan price, so a scan gap beyond the stop could exaggerate a planned ~1R stop into a very large R loss.

## Fixes
- FX pip value is now quote-currency aware and converted into USD.
- HUF and JPY use dedicated 0.01 pip conventions in the synthetic feed.
- Lot sizing floors to the broker lot step instead of rounding upward.
- If minimum 0.01 lot exceeds the approved risk budget, the trade is rejected with `MIN LOT TOO RISKY` instead of being oversized.
- Position `risk_amount` now reflects the actual rounded stop risk.
- Stop-loss execution uses the stop level plus bounded realistic adverse slippage instead of an arbitrary far-away scan price.
- Take-profit execution uses the configured target price conservatively.
- `_close()` recomputes P/L from the actual exit price instead of trusting stale unrealized P/L.

## Safety goal
- A normal stop-loss should remain near the planned ~1R risk, including modest execution costs/slippage.
- Exotic FX can be skipped when the account is too small to trade the minimum lot safely.
