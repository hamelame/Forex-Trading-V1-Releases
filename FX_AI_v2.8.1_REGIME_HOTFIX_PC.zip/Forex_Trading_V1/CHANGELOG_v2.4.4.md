# FX // AI v2.4.4 — High-Water Recovery Deadlock Fix

- Replaced candidate-driven high-water recovery with a scan-driven state machine.
- High-water recovery now advances on every active AI scan even when there is no executable candidate.
- Lifecycle: NORMAL -> COOLDOWN -> RECOVERY -> NORMAL.
- At cooldown completion the profit-giveback high-water anchor is rebased to the current closed balance.
- RECOVERY resumes entries at the existing 0.25x drawdown-recovery risk multiplier.
- A profitable closed recovery trade returns the drawdown lifecycle to NORMAL.
- A new 6% giveback after recovery can start a fresh cooldown instead of reusing a stale latch.
- Added an independent 10% emergency high-water drawdown hard stop.
- Existing daily/weekly safety breakers remain hard barriers.
- Trading Brain, Self-Learning, Execution-Realistic Paper Mode and exposure diversification are otherwise unchanged.
