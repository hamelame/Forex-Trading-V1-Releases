# Forex Trading V1.3.0 — HD Terminal & Internet Updater

## UI
- Darker FX // AI premium visual system.
- Custom canvas buttons instead of classic Tk button styling for primary actions.
- New Command Center market-focus chart area and Top AI Opportunities layout.
- Human-readable instrument names and categories across markets, decisions, positions and quality views.
- Improved typography, spacing, hierarchy and dark scrollbars.
- Mouse-wheel scrolling is smoother.
- Live table refresh preserves scroll position instead of jumping.

## Updater
- Supports GitHub Releases (`owner/repository`) or a static JSON manifest URL.
- Shows latest version/changelog.
- Downloads ZIP updates over HTTPS.
- Optional SHA-256 verification for manifest-based releases.
- Tests ZIP integrity before installation.
- One-shot installer preserves config.json, data/, logs/ and backups/.
- Program backup is created before overlaying an update.
- Restarts the app after installation.
- App version is migrated separately so preserving config does not leave a stale version number.

## Scope
Trading/AI logic is intentionally kept close to V1.2.0 in this release.
