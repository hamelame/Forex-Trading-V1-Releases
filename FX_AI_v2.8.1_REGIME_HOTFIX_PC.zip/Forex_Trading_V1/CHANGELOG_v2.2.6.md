# FX // AI V2.2.6 — Runtime Capital + Full UI/Control Consolidation

## Critical Paper Capital fix
- Fixed a hidden risk-state bug when Paper Trading Capital is changed while the app is already open.
- The old High-Water Balance is now reset together with Balance, Equity, daily loss baseline and weekly loss baseline.
- Example fixed: changing $20,000 -> $10,000 no longer looks like a false 50% drawdown.
- New paper sessions clear stale re-entry/selector state and immediately rebuild the market shortlist.
- Changing capital preserves whether AI was ACTIVE or PAUSED.
- If AI was active and a new paper session is accepted, normal trading can resume immediately.
- If AI was paused, changing capital never auto-starts the AI.

## Refresh
- Global REFRESH updates market state on every supported page, even while AI is paused.
- REFRESH never opens a new trade by itself while paused.
- Trade Log performs a direct database refresh.
- Shadow Lab includes REFRESH MARKET for immediate 140-market rescan/reselection.

## Shadow Lab
- ELIGIBLE MARKET CANDIDATES shows what currently passes the selector filters.
- AI SELECTED shows the Top 5 / Top 10 markets actually allowed to reach execution.
- AI DECISION EXPLAINER shows action, regime, AI score, confidence, market score, spread, session and concise decision factors.

## Pause AI
- With open positions:
  - YES = CLOSE ALL POSITIONS and pause.
  - NO = KEEP POSITIONS and pause new entries.
  - CANCEL = keep AI running.
- Kept positions remain monitored by stop/target/AI-exit logic.

## Command Center / Market Intelligence
- Responsive KPI layout.
- Realized and Unrealized P/L use correct + / - sign formatting.
- Near-zero values show $0.00, never -$0.00.
- Market Watch prioritizes active positions and hides empty placeholder cards.
- AI status line is larger and explains important blocks/waits/open/close states.
- Market Intelligence panel is wider with improved wrapping.
- System Status box is larger and explains NORMAL vs PROTECTIVE state.

## Performance Lab
- KPI cards use a responsive two-row layout so EXPECTANCY is no longer clipped on the right.
- P/L and expectancy use the same centralized sign formatting.

## Settings / UI
- Dark dropdown/combobox background with yellow text.
- Existing semantic colors remain: green = positive/buy/healthy, red = negative/sell/risk, yellow = primary UI copy.

## Architecture
- 140-instrument Multi-Market AI architecture preserved.
- Forex, Metals, Energy, Indices and Crypto remain in the same research terminal.
- PAPER + SYNTHETIC only.
