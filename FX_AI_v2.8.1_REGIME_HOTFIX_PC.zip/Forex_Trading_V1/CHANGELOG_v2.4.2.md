# v2.4.2 — Execution Reality + Command Center Sync Cleanup

- Added Execution-Realistic Paper Mode with adverse slippage, configurable latency, bid/ask execution, commissions, overnight financing estimates, partial fills and no-fill rejection.
- Removed duplicate top Command Center REALIZED WIN, REALIZED LOSS and UNREALIZED P/L cards. Detailed P/L remains in AI Heartbeat; top row now focuses on Balance, Equity, Total Session P/L, Open Positions, Portfolio Heat and AI Engine.
- Global AI STATUS text is permanently green to make engine activity visually obvious even when the event reports a losing close or a blocked entry.
- Existing strict underlying/shared-exposure gates remain active so equivalent instruments quoted in different currencies do not create duplicate exposure.
- Version bumped to 2.4.2.
