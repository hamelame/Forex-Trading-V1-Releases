$ErrorActionPreference = "Stop"
Set-Location (Split-Path -Parent $PSScriptRoot)

$config = Get-Content ".\config.json" -Raw | ConvertFrom-Json
$version = [string]$config.version
$repo = "hamelame/Forex-Trading-V1-Releases"
$tag = "v$version"
$asset = Join-Path $env:TEMP "Forex_Trading_V1_v$version.zip"
$change = ".\CHANGELOG_v$version.md"

Write-Host ""
Write-Host "FX // AI Release Publisher" -ForegroundColor Cyan
Write-Host "Repository: $repo"
Write-Host "Version:    $tag"
Write-Host ""

if (-not (Get-Command gh -ErrorAction SilentlyContinue)) {
    Write-Host "GitHub CLI is not installed. Installing with winget..." -ForegroundColor Yellow
    winget install --id GitHub.cli -e --accept-source-agreements --accept-package-agreements
    if ($LASTEXITCODE -ne 0) { throw "GitHub CLI installation failed." }
    $env:Path += ";$env:ProgramFiles\GitHub CLI"
}

$auth = (& gh auth status 2>&1 | Out-String)
if ($LASTEXITCODE -ne 0) {
    Write-Host "One-time GitHub login required." -ForegroundColor Yellow
    & gh auth login -w
    if ($LASTEXITCODE -ne 0) { throw "GitHub login failed." }
}

if (Test-Path $asset) { Remove-Item $asset -Force }
$tempRoot = Join-Path $env:TEMP "fxai_release_$version"
if (Test-Path $tempRoot) { Remove-Item $tempRoot -Recurse -Force }
$packageRoot = Join-Path $tempRoot "Forex_Trading_V1"
New-Item -ItemType Directory -Path $packageRoot -Force | Out-Null

$exclude = @("data","logs","backups","__pycache__","publisher_release_channel.json")
Get-ChildItem "." -Force | ForEach-Object {
    if ($exclude -contains $_.Name) { return }
    Copy-Item $_.FullName $packageRoot -Recurse -Force
}

Compress-Archive -Path $packageRoot -DestinationPath $asset -CompressionLevel Optimal
Remove-Item $tempRoot -Recurse -Force
Write-Host "Package ready: $asset" -ForegroundColor Cyan

$tags = (& gh release list --repo $repo --limit 100 --json tagName --jq '.[].tagName' 2>&1 | Out-String)
if ($LASTEXITCODE -ne 0) { throw "Could not read GitHub Releases:`n$tags" }
$tagExists = ($tags -split "`r?`n") -contains $tag

if ($tagExists) {
    Write-Host "Release $tag already exists. Replacing ZIP asset..." -ForegroundColor Yellow
    & gh release upload $tag $asset --repo $repo --clobber
    if ($LASTEXITCODE -ne 0) { throw "Could not upload release asset." }
} else {
    Write-Host "Creating GitHub Release $tag..." -ForegroundColor Green
    if (Test-Path $change) {
        & gh release create $tag $asset --repo $repo --title "Forex Trading $tag" --notes-file $change --latest
    } else {
        & gh release create $tag $asset --repo $repo --title "Forex Trading $tag" --notes "FX // AI update $tag" --latest
    }
    if ($LASTEXITCODE -ne 0) { throw "Could not create GitHub Release." }
}

Write-Host ""
Write-Host "SUCCESS - GitHub Release $tag is published." -ForegroundColor Green
Write-Host "Older installed versions can now find it through CHECK FOR UPDATES."
Write-Host ""
Pause
