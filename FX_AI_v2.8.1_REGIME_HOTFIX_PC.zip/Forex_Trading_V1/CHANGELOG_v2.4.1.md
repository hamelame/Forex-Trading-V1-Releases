# FX // AI v2.4.1 — Command Center HD Hotfix

## Command Center P/L cleanup
- REALIZED PROFIT renamed to REALIZED WIN.
- REALIZED LOSS remains the dedicated losing-trades box.
- Removed the redundant NET REALIZED P/L top card.
- Unrealized P/L and Total Session P/L remain as separate live/session metrics, not extra realized-profit cards.

## AI Heartbeat HD redesign
- Replaced the dense four-line green text block with a structured terminal panel.
- Larger, sharper labels and values.
- Dedicated live cells for:
  Scan, Eligible, Selected, Trade-Ready, Open Positions,
  Realized Win, Realized Loss, Net Realized, Unrealized, Total Session,
  Self Learning, AI Challengers, Risk Engine, Counterfactuals and Blocked Trades.
- Added a dedicated Last Engine Event row.
- Semantic green/red/amber coloring is retained for P/L and risk state.

## STOP control
- Active-engine button now reads `STOPP!` instead of `PAUSE AI`.
- Existing safety behavior is preserved:
  Close All Positions / Keep Positions / Cancel when open paper positions exist.

## Trading Brain
- Multi-Market Research Brain v2 and Self-Learning Engine v1 are unchanged from v2.4.0.
- This release is intentionally an interface hotfix only.
