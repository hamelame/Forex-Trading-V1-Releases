# Forex Trading V1.5.0 — FX Council & Premium Command Center

## Forex AI Council v1
- New Forex-specific Council replaces the old single generic Champion decision path.
- Specialist votes:
  - Trend / momentum continuation
  - Range / mean reversion
  - Volatility / breakout
- Regime-dependent specialist weights.
- Cross-pair currency-strength confirmation calculated from the full active FX universe.
- Session, spread and data-quality gates remain explicit.
- Adaptive stop / reward-to-risk targets by regime.
- New currency-concentration gate prevents stacking too many positions that share the same currencies.
- Carry/macro is intentionally not simulated until real rate/macro data is connected.

## Market universe
- Expanded synthetic/research universe from 33 to 56 FX instruments.
- Added more Nordic, Asian and emerging-market FX pairs including CNH, HKD, ZAR, MXN, PLN, CZK, HUF and TRY crosses.
- Instrument metadata now identifies Forex Major / Cross / Nordic / Asia / Emerging categories.
- Real broker mode should still use broker-supported symbols rather than assuming every broker offers the whole research universe.

## Command Center / UI
- Upgraded live chart with terminal-style grid, price scale, live current-price marker and subdued area fill.
- Top AI Opportunities is compact and no longer depends on a long off-screen Reason column.
- Horizontal scrolling is removed from the Command Center opportunity table.
- New Selected AI Analysis panel wraps and displays the complete Forex Council explanation.
- FX Intelligence now includes cross-pair Currency Strength.
- Existing manual chart lock remains isolated from scanner ranking.

## Performance
- Decision logging is batched into one SQLite transaction per scan instead of one commit per instrument.
- Engine scan is now three-stage: collect snapshots, calculate currency strength, then make Council decisions.
- Only visible pages continue to render live UI updates.

## Internet updater
- Default publisher channel is now `hamelame/Forex-Trading-V1-Releases`.
- Empty GitHub repositories are treated as “no releases published yet” instead of a generic 404 error.
- `publisher_release_channel.json` is preserved during program updates.

## Paper-only
- This remains a paper/research build.
- No live order execution is enabled.
