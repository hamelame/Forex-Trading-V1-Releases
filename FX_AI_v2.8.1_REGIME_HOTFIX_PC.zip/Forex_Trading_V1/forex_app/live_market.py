"""v2.7.1 live public market-data layer.

PAPER execution only. This module never sends orders.
Primary public feed: Yahoo Finance chart endpoint for FX, metals, energy and indices.
Crypto uses Binance public klines where possible, then Yahoo as fallback.
No synthetic price fallback is used in LIVE mode: stale/missing data stays unavailable.
"""
from __future__ import annotations
import json, math, time, urllib.parse, urllib.request
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from threading import Lock
from .instruments import instrument_spec, instrument_meta
from .market import session_name
from .models import MarketSnapshot

YAHOO_MAP={
    "XAUUSD":"GC=F","XAGUSD":"SI=F","XPTUSD":"PL=F","XPDUSD":"PA=F",
    "WTIUSD":"CL=F","BRENTUSD":"BZ=F","NATGASUSD":"NG=F","GASOILUSD":"HO=F","HEATOILUSD":"HO=F","RBOBUSD":"RB=F",
    "US500":"^GSPC","US100":"^NDX","US30":"^DJI","US2000":"^RUT","UK100":"^FTSE","DE40":"^GDAXI","FR40":"^FCHI",
    "EU50":"^STOXX50E","ES35":"^IBEX","IT40":"FTSEMIB.MI","CH20":"^SSMI","NL25":"^AEX","JP225":"^N225","HK50":"^HSI",
    "AUS200":"^AXJO","IN50":"^NSEI","KR200":"^KS200","CA60":"^GSPTSE",
}

def _yahoo_symbol(symbol):
    s=symbol.upper(); meta=instrument_meta(s)
    if meta["asset_class"]=="FOREX": return f"{s}=X"
    if meta["asset_class"]=="CRYPTO" and s.endswith("USD"): return f"{s[:-3]}-USD"
    return YAHOO_MAP.get(s)

def _binance_symbol(symbol):
    s=symbol.upper(); meta=instrument_meta(s)
    if meta["asset_class"]=="CRYPTO" and s.endswith("USD"):
        return f"{s[:-3]}USDT"
    return None

class LiveMarketFeed:
    def __init__(self,symbols,cfg=None):
        self.requires_fresh_live_data=True
        self.symbols=list(symbols); self.cfg=cfg or {}
        self.history={s:deque(maxlen=420) for s in self.symbols}
        self.candle_times={s:deque(maxlen=420) for s in self.symbols}
        self._last_fetch={}; self._last_error={}; self._provider={}
        self.refresh_seconds=max(5.0,float(self.cfg.get("live_data_refresh_seconds",20.0)))
        self.stale_seconds=max(30.0,float(self.cfg.get("live_data_stale_seconds",180.0)))
        self.delayed_stale_seconds=max(self.stale_seconds,float(self.cfg.get("live_data_delayed_stale_seconds",1200.0)))
        self.timeout=max(2.0,float(self.cfg.get("live_data_timeout_seconds",8.0)))
        self.user_agent="Mozilla/5.0 FX-AI-Paper/2.7"
        # Network I/O must never run on Tk's UI thread. Keep one bounded pool for
        # the lifetime of the feed and only publish completed candle batches.
        workers=max(4,min(int(self.cfg.get("live_data_workers",20)),32,max(4,len(self.symbols))))
        self._executor=ThreadPoolExecutor(max_workers=workers,thread_name_prefix="fx-live")
        self._inflight=set()
        self._inflight_lock=Lock()

    def _get_json(self,url):
        req=urllib.request.Request(url,headers={"User-Agent":self.user_agent,"Accept":"application/json"})
        with urllib.request.urlopen(req,timeout=self.timeout) as r:
            return json.loads(r.read().decode("utf-8"))

    def _fetch_binance(self,symbol):
        bs=_binance_symbol(symbol)
        if not bs: return None
        q=urllib.parse.urlencode({"symbol":bs,"interval":"1m","limit":300})
        data=self._get_json("https://api.binance.com/api/v3/klines?"+q)
        if not isinstance(data,list) or len(data)<30: return None
        vals=[]; times=[]
        for row in data:
            vals.append(float(row[4])); times.append(float(row[0])/1000.0)
        return vals,times,"BINANCE PUBLIC 1M"

    def _fetch_yahoo(self,symbol):
        ys=_yahoo_symbol(symbol)
        if not ys: return None
        enc=urllib.parse.quote(ys,safe="")
        url=f"https://query1.finance.yahoo.com/v8/finance/chart/{enc}?range=1d&interval=1m&includePrePost=true"
        data=self._get_json(url)
        result=((data.get("chart") or {}).get("result") or [None])[0]
        if not result: return None
        ts=result.get("timestamp") or []; quote=(((result.get("indicators") or {}).get("quote") or [{}])[0])
        closes=quote.get("close") or []
        pairs=[(float(t),float(v)) for t,v in zip(ts,closes) if v is not None and math.isfinite(float(v))]
        if len(pairs)<30: return None
        return [p[1] for p in pairs[-300:]],[p[0] for p in pairs[-300:]],"YAHOO PUBLIC 1M"

    def _refresh_symbol(self,symbol,force=False):
        now=time.time()
        if not force and now-self._last_fetch.get(symbol,0)<self.refresh_seconds and self.history[symbol]: return
        self._last_fetch[symbol]=now
        try:
            result=None
            if instrument_meta(symbol)["asset_class"]=="CRYPTO":
                try: result=self._fetch_binance(symbol)
                except Exception as exc: self._last_error[symbol]=f"Binance: {exc}"
            if result is None: result=self._fetch_yahoo(symbol)
            if result is None: raise RuntimeError("No supported live provider mapping")
            vals,times,provider=result
            # Publish complete immutable-in-practice buffers atomically. The UI
            # may be reading the previous deque while this worker finishes.
            self.history[symbol]=deque(vals,maxlen=420)
            self.candle_times[symbol]=deque(times,maxlen=420)
            self._provider[symbol]=provider; self._last_error.pop(symbol,None)
        except Exception as exc:
            self._last_error[symbol]=str(exc)

    def advance(self):
        """Queue due downloads and return immediately.

        Older builds waited for every HTTP future here. Because ``advance`` is
        called from Tk's timer callback, one slow provider froze the entire app.
        """
        now=time.time()
        with self._inflight_lock:
            due=[s for s in self.symbols
                 if s not in self._inflight and now-self._last_fetch.get(s,0)>=self.refresh_seconds]
            for symbol in due:
                # Reserve before submit so fast UI scans cannot queue duplicates.
                self._inflight.add(symbol)
                self._last_fetch[symbol]=now
                future=self._executor.submit(self._refresh_symbol,symbol,True)
                future.add_done_callback(lambda _f,s=symbol:self._download_finished(s))

    def _download_finished(self,symbol):
        with self._inflight_lock:
            self._inflight.discard(symbol)

    @staticmethod
    def _ema(vals,n):
        a=2/(n+1); e=vals[0]
        for v in vals[1:]: e=a*v+(1-a)*e
        return e

    @staticmethod
    def _rsi_series(vals,n=14):
        vals=list(vals)
        if len(vals)<n+1:return [50.0]*len(vals)
        diffs=[vals[i]-vals[i-1] for i in range(1,len(vals))]
        avg_gain=sum(max(x,0) for x in diffs[:n])/n; avg_loss=sum(max(-x,0) for x in diffs[:n])/n
        out=[50.0]*n
        def calc(g,l):
            if l<=1e-12:return 100.0 if g>0 else 50.0
            rs=g/l; return 100-(100/(1+rs))
        out.append(calc(avg_gain,avg_loss))
        for d in diffs[n:]:
            avg_gain=(avg_gain*(n-1)+max(d,0))/n; avg_loss=(avg_loss*(n-1)+max(-d,0))/n; out.append(calc(avg_gain,avg_loss))
        if len(out)<len(vals): out=[50.0]*(len(vals)-len(out))+out
        return out[-len(vals):]

    def snapshot(self,symbol):
        # Deliberately never fetch here: snapshot is consumed by the UI/engine
        # timer and therefore must be a fast, local cache read.
        vals=list(self.history[symbol]); times=list(self.candle_times[symbol])
        if len(vals)<30 or not times: raise RuntimeError(self._last_error.get(symbol,"No live candles yet"))
        age=max(0.0,time.time()-times[-1])
        asset=instrument_meta(symbol)["asset_class"]
        freshness_limit=self.stale_seconds if asset in ("FOREX","CRYPTO") else self.delayed_stale_seconds
        status="LIVE" if age<=freshness_limit else "STALE"
        if status!="LIVE": raise RuntimeError(f"STALE DATA ({age:.0f}s old)")
        spec=instrument_spec(symbol); step=max(float(spec["tick_size"]),1e-12); mid=vals[-1]
        # Public candle feeds do not expose reliable bid/ask across every asset class.
        # Use a conservative modelled paper spread while keeping the underlying price real.
        spread=max(0.2,float(spec.get("spread_base",0.9)))
        bid=mid-spread*step/2; ask=mid+spread*step/2
        ema_fast=self._ema(vals[-70:],20); ema_slow=self._ema(vals[-120:],50)
        hist=vals[-100:]; rsis=self._rsi_series(hist,14); rsi=rsis[-1]
        look=min(14,len(vals)-1); diffs=[abs(vals[-i]-vals[-i-1])/step for i in range(1,look+1)]
        atr=max(2.0,(sum(diffs)/max(len(diffs),1))*2.5)
        momentum=(vals[-1]-vals[-min(8,len(vals))])/(step*8)
        quality=max(75.0,min(100.0,100.0-age/max(freshness_limit,1.0)*15.0))
        ts=datetime.fromtimestamp(times[-1],timezone.utc).isoformat()
        return MarketSnapshot(symbol,bid,ask,spread,rsi,ema_fast,ema_slow,atr,momentum,session_name(),ts,quality,
                              tuple(rsis),tuple(hist),"LIVE",self._provider.get(symbol,"PUBLIC"),age)

    def feed_status(self,symbol):
        if not self.history.get(symbol): return {"status":"NO DATA","provider":self._provider.get(symbol,""),"error":self._last_error.get(symbol,"")}
        age=time.time()-(self.candle_times[symbol][-1] if self.candle_times[symbol] else 0)
        asset=instrument_meta(symbol)["asset_class"]
        limit=self.stale_seconds if asset in ("FOREX","CRYPTO") else self.delayed_stale_seconds
        return {"status":"LIVE" if age<=limit else "STALE","provider":self._provider.get(symbol,""),"age_seconds":age,"error":self._last_error.get(symbol,"")}

    def close(self):
        """Stop accepting downloads without making window shutdown wait for them."""
        self._executor.shutdown(wait=False,cancel_futures=True)
