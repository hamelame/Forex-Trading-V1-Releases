import uuid, random
from datetime import datetime, timezone, timedelta
from .models import Position, ClosedTrade
from .market import pip_size
from .multi_market_brain import MultiMarketResearchBrain, build_currency_strength
from .risk import RiskEngine
from .execution import ExecutionRealism
from .opportunity_selector import OpportunitySelector
from .intelligence import regime, market_rank, exposure_summary
from .self_learning import SelfLearningEngine
from .rsi_intelligence import analyze_snapshot
from .neural_edge import NeuralEdgeBrain

class TradingEngine:
    def __init__(self,cfg,feed,db):
        self.cfg=cfg; self.feed=feed; self.db=db
        # Every application launch begins a fresh visible PAPER session.
        # Historical closed trades stay in the database for future AI research.
        self.session_started_at=datetime.now(timezone.utc).isoformat()
        self.balance=float(cfg.get("paper_trading_capital",cfg.get("starting_balance",20000.0)))
        self.equity=self.balance
        self.positions=[]
        self.db.clear_open_positions()
        self.snapshots={}; self.decisions={}
        self.risk=RiskEngine(cfg)
        self.selector=OpportunitySelector(cfg)
        self.learning=SelfLearningEngine(cfg,db)
        self.execution=ExecutionRealism(cfg)
        self.neural=NeuralEdgeBrain(cfg)
        self.neural_predictions={}
        self.entry_context={}
        self.position_excursions={}
        self.reversal_votes={}
        self.execution_starvation_scans=0
        self.decision_starvation_scans=0
        self.opportunity_recovery_active=False
        self.last_open_scan=0
        self.last_gate_reasons={}
        self.symbol_loss_streaks={}
        self.symbol_loss_cooldown_until={}
        self.last_any_entry_scan=-10**9
        # Fresh paper session gets fresh circuit-breaker baselines.
        self.risk.reset_session(self.balance)
        self.champion=MultiMarketResearchBrain("Multi-Market Research Brain v2",cfg["min_signal_score"],cfg)
        # V2.1 intentionally runs one Champion AI module only.
        self.challengers=[]
        self.shadow_stats={}
        self.last_status="AI paused · press START AI"
        self.enabled=False; self.rankings={}; self.regimes={}; self.scan_count=0
        self.last_exit_scan={}
        self.db.equity(self.session_started_at,self.balance,self.equity)

    def reset_paper_session(self, capital=None):
        cap=float(capital if capital is not None else self.cfg.get("paper_trading_capital",self.cfg.get("starting_balance",20000.0)))
        cap=max(1000.0,min(100000.0,cap))
        self.cfg["paper_trading_capital"]=cap
        self.cfg["starting_balance"]=cap
        self.session_started_at=datetime.now(timezone.utc).isoformat()
        self.balance=cap
        self.equity=cap
        self.positions=[]
        self.db.clear_open_positions()
        self.risk.reset_session(cap)
        self.entry_context={}
        self.position_excursions={}
        self.reversal_votes={}
        self.execution_starvation_scans=0
        self.decision_starvation_scans=0
        self.opportunity_recovery_active=False
        self.last_open_scan=0
        self.last_gate_reasons={}
        self.learning.pending_counterfactuals={}
        self.last_exit_scan={}
        self.scan_count=0
        self.selector.force_reselect()
        self.db.equity(self.session_started_at,self.balance,self.equity)
        self.last_status=f"New paper session · ${cap:,.0f} · balance/P&L/risk state reset"

    def apply_paper_capital(self, capital, start_new_session=False):
        cap=max(1000.0,min(100000.0,float(capital)))
        self.cfg["paper_trading_capital"]=cap
        self.cfg["starting_balance"]=cap
        self.risk.cfg=self.cfg
        if not start_new_session:
            self.last_status=f"Paper capital ${cap:,.0f} saved for next session"
            return False

        was_enabled=self.enabled
        self.reset_paper_session(cap)
        self.enabled=was_enabled
        # Rebuild market/selector state immediately. This never opens entries;
        # an active AI will execute normally on the next scan.
        self.refresh_market_state(force_reselect=True)
        self.enabled=was_enabled
        self.last_status=(
            f"New paper session ready · ${cap:,.0f} · "
            f"{'AI active' if was_enabled else 'AI paused'}"
        )
        return True

    def set_enabled(self, value, reset_on_start=True):
        value=bool(value)
        if value and not self.enabled and reset_on_start:
            self.reset_paper_session()
        self.enabled=value
        self.last_status="AI started · new paper session" if self.enabled else "AI paused"

    def apply_config(self, cfg, force_reselect=False):
        self.cfg=cfg
        self.risk.cfg=cfg
        self.champion.apply_config(cfg)
        self.selector.apply_config(cfg)
        self.learning.apply_config(cfg)
        self.execution.apply_config(cfg)
        self.neural.apply_config(cfg)
        if force_reselect:
            self.selector.force_reselect()
        self.last_status="Settings applied"

    def top_markets(self, n=None):
        n=n or self.cfg.get("market_scan_top_n",12)
        selected=list(getattr(getattr(self,"selector",None),"shortlist",[]) or [])
        if selected:
            return selected[:n]
        return sorted(self.rankings,key=self.rankings.get,reverse=True)[:n]

    def exposure_summary(self): return exposure_summary(self.positions)

    def unrealized_pnl(self):
        return sum(float(p.unrealized) for p in self.positions)


    def selection_summary(self):
        st=getattr(self.selector,"stats",{})
        return {
            "mode":self.cfg.get("selection_mode","AUTO TOP 10"),
            "shortlist":list(getattr(self.selector,"shortlist",[])),
            "eligible":list(getattr(self.selector,"eligible",[])),
            "scanned":int(st.get("scanned",0)),
            "eligible_count":int(st.get("eligible",0)),
            "selected_count":int(st.get("selected",0)),
            "trade_ready":int(st.get("trade_ready",0)),
        }


    def strength_summary(self):
        s=getattr(self,"currency_strength",{}) or {}
        if not s:return "Collecting cross-pair data"
        ordered=sorted(s.items(),key=lambda x:x[1],reverse=True)
        strong=" · ".join(f"{c} {v:+.0f}" for c,v in ordered[:2])
        weak=" · ".join(f"{c} {v:+.0f}" for c,v in ordered[-2:])
        return f"Strong: {strong}  |  Weak: {weak}"

    def _risk_multiplier(self,d,s):
        if self.cfg.get("trading_profile","AI TRADING")=="MANUAL":
            return 1.0
        r=self.regimes.get(s.symbol,regime(s))
        mult=1.0
        if d.confidence<65: mult*=0.55
        elif d.confidence<75: mult*=0.75
        elif d.confidence<82: mult*=0.90
        if r=="HIGH VOL": mult*=float(self.cfg.get("high_vol_risk_multiplier",0.40))
        elif r=="MIXED": mult*=0.80
        if s.session=="Asia": mult*=0.85
        elif s.session=="Rollover / Thin": mult*=0.45
        if s.spread_pips>1.4: mult*=0.75
        from .instruments import instrument_meta
        asset=instrument_meta(s.symbol)["asset_class"]
        if asset=="CRYPTO": mult*=0.72
        elif asset=="ENERGY": mult*=0.82
        elif asset=="METALS": mult*=0.90
        if "OPPORTUNITY RECOVERY" in str(getattr(d,"reason","")):
            mult*=float(self.cfg.get("opportunity_recovery_risk_multiplier",0.35))

        # Expectancy Governor controls how much production risk this exact
        # context has earned. Unknown contexts bootstrap small; proven contexts
        # can earn full risk; negative contexts never reach _open().
        gov_mult=self.learning.governor_risk_multiplier(
            s.symbol,r,d.action,s.session
        )
        mult*=gov_mult

        # RSI-pattern evidence is learned separately. A pattern can earn reduced
        # risk or be quarantined without hard-coding that it always works.
        rsi_a=analyze_snapshot(s)
        rsi_gov=self.learning.rsi_pattern_governor(
            s.symbol,r,d.action,rsi_a.tags
        )
        mult*=float(rsi_gov.get("risk_mult",1.0))

        # Rolling global expectancy is a second capital-preservation layer. It
        # reduces size during a broadly losing run without stopping research.
        global_mult=float(self.learning.global_risk_multiplier())
        mult*=global_mult
        return max(float(self.cfg.get("min_risk_multiplier",0.05)),min(1.0,mult))

    def _research_decision(self,s,liveness_relax=0.0):
        d=self.champion.decide(s,self.currency_strength,liveness_relax=liveness_relax)
        rg=regime(s)
        d=self.learning.adjust_decision(d,s,rg)
        return d,rg

    def learning_summary(self):
        out=self.learning.summary()
        state,remaining=self.risk.recovery_state(self.scan_count)
        out["risk_state"]=state
        out["recovery_scans_remaining"]=remaining
        out["recovery_risk_multiplier"]=self.risk.recovery_risk_multiplier()
        out["drawdown_mode"]=getattr(self.risk,"drawdown_mode","NORMAL")
        out["drawdown_pct"]=float(getattr(self.risk,"last_drawdown_pct",0.0))
        out["loss_limit_mode"]=getattr(self.risk,"limit_mode","NORMAL")
        out["day_loss_pct"]=float(getattr(self.risk,"last_day_loss_pct",0.0))
        out["week_loss_pct"]=float(getattr(self.risk,"last_week_loss_pct",0.0))
        out["execution_starvation_scans"]=int(getattr(self,"execution_starvation_scans",0))
        out["decision_starvation_scans"]=int(getattr(self,"decision_starvation_scans",0))
        out["opportunity_recovery_active"]=bool(getattr(self,"opportunity_recovery_active",False))
        out["neural_edge"]=self.neural.summary()
        return out

    def refresh_market_state(self, force_reselect=False):
        """Refresh quotes, AI decisions, rankings and selector without opening trades."""
        self.scan_count+=1
        advance=getattr(self.feed,"advance",None)
        if callable(advance):
            advance()

        fresh={}
        for symbol in self.cfg["symbols"]:
            try:
                fresh[symbol]=self.feed.snapshot(symbol)
            except Exception as exc:
                self.last_status=f"{symbol}: data refresh error: {exc}"
        if not fresh:
            return

        self.snapshots.update(fresh)
        self.currency_strength=build_currency_strength(fresh)
        batch=[]
        for symbol,s in fresh.items():
            try:
                d,rg=self._research_decision(s)
                if d.action in ("BUY","SELL") and self.cfg.get("neural_edge_enabled",True):
                    self.neural_predictions[symbol]=self.neural.predict(s,d,rg)
                self.decisions[symbol]=d
                self.regimes[symbol]=rg
                self.rankings[symbol]=market_rank(s,d)
                batch.append(d)
            except Exception as exc:
                self.last_status=f"{symbol}: decision refresh error: {exc}"

        self.db.decisions_batch(batch)
        if force_reselect:
            self.selector.force_reselect()
        self.selector.select(self.scan_count,fresh,self.decisions,self.rankings,self.regimes)
        self._mark_and_close()
        self.last_status=(
            f"Market refreshed · {self.selector.stats['eligible']} eligible · "
            f"{self.selector.stats['selected']} selected"
        )

    def scan(self):
        if not self.enabled:
            # PAUSED means no new entries, but quotes/positions still update.
            self.refresh_market_state(force_reselect=False)
            return
        self.scan_count+=1
        # Advance all recoverable risk lifecycles once per active engine scan,
        # independent of whether this scan produces an executable BUY/SELL candidate.
        self.risk.sanitize_recovery_state(self.scan_count)
        limit_mode=self.risk.update_loss_limit_state(self.balance,self.scan_count)
        dd_mode=self.risk.update_drawdown_state(self.balance,self.scan_count)
        if dd_mode=="COOLDOWN":
            _,remaining=self.risk.recovery_state(self.scan_count)
            self.last_status=(
                f"Drawdown protection cooldown · {self.risk.last_drawdown_pct:.2f}% · "
                f"{remaining} scans remaining"
            )
        elif dd_mode=="RECOVERY":
            self.last_status=(
                f"Drawdown recovery active · "
                f"{self.risk.recovery_risk_multiplier():.2f}x entry risk"
            )
        elif dd_mode=="EMERGENCY":
            self.last_status=(
                f"Emergency drawdown hard stop · {self.risk.last_drawdown_pct:.2f}%"
            )
        elif limit_mode=="DEEP_COOLDOWN":
            _,remaining=self.risk.recovery_state(self.scan_count)
            self.last_status=(
                f"DEEP RECOVERY COOLDOWN · {remaining} scans remaining · "
                f"{self.risk.limit_trigger_reason}"
            )
        elif limit_mode=="DEEP_RECOVERY":
            self.last_status=(
                f"DEEP RECOVERY ACTIVE · "
                f"{self.risk.recovery_risk_multiplier():.2f}x entry risk"
            )
        elif limit_mode=="COOLDOWN":
            _,remaining=self.risk.recovery_state(self.scan_count)
            self.last_status=(
                f"Daily/weekly protection cooldown · {remaining} scans remaining · "
                f"{self.risk.limit_trigger_reason}"
            )
        elif limit_mode=="RECOVERY":
            self.last_status=(
                f"Daily/weekly recovery active · "
                f"{self.risk.recovery_risk_multiplier():.2f}x entry risk"
            )
        elif limit_mode=="EMERGENCY":
            self.last_status=(
                f"Emergency session-loss hard stop · {self.risk.limit_trigger_reason}"
            )

        advance=getattr(self.feed,"advance",None)
        if callable(advance):
            advance()

        # Phase 1: snapshot the whole enabled multi-market universe first.
        fresh={}
        for symbol in self.cfg["symbols"]:
            try:
                fresh[symbol]=self.feed.snapshot(symbol)
            except Exception as e:
                self.last_status=f"{symbol}: data error: {e}"
        if not fresh:
            return
        self.snapshots.update(fresh)
        self.learning.resolve_counterfactuals(self.snapshots,self.scan_count)

        # Phase 2: calculate cross-sectional currency strength before decisions.
        self.currency_strength=build_currency_strength(fresh)

        # Phase 3: one Multi-Market Champion AI + independent shadow research specialists.
        batch=[]
        pending_entries=[]
        for symbol,s in fresh.items():
            try:
                d,rg=self._research_decision(s)
                if d.action in ("BUY","SELL") and self.cfg.get("neural_edge_enabled",True):
                    self.neural_predictions[symbol]=self.neural.predict(s,d,rg)
                self.decisions[symbol]=d
                self.regimes[symbol]=rg
                self.rankings[symbol]=market_rank(s,d)
                batch.append(d)

                if d.action in ("BUY","SELL"):
                    pending_entries.append((self.rankings[symbol],d,s))
            except Exception as e:
                self.last_status=f"{symbol}: decision error: {e}"

        governor_waits=sum(
            1 for d in self.decisions.values()
            if d.action=="WAIT" and "GOVERNOR RESEARCH-ONLY" in str(d.reason)
        )
        if not pending_entries and governor_waits:
            self.last_status=(
                f"EXPECTANCY GOVERNOR · {governor_waits} research-only context(s) · "
                f"scanning for proven/probation edge"
            )

        # Decision-layer liveness guard.
        # If the portfolio has capacity but the Champion has produced no executable
        # BUY/SELL for a sustained period, run one bounded PAPER-only re-evaluation.
        # Hard BLOCK conditions and RiskEngine protections are never relaxed.
        capacity=len(self.positions)<int(self.cfg.get("max_open_positions",5))
        rstate,_=self.risk.recovery_state(self.scan_count)
        if capacity and not pending_entries and rstate not in ("COOLDOWN","EMERGENCY"):
            self.decision_starvation_scans+=1
        else:
            self.decision_starvation_scans=0
            self.opportunity_recovery_active=False

        recovery_after=max(3,int(self.cfg.get("opportunity_recovery_after_scans",45)))
        if (capacity and not pending_entries
                and self.decision_starvation_scans>=recovery_after
                and rstate not in ("COOLDOWN","EMERGENCY")
                and self.cfg.get("opportunity_recovery_enabled",True)):
            recovery_batch=[]
            recovery_entries=[]
            for symbol,s in fresh.items():
                try:
                    d,rg=self._research_decision(s,liveness_relax=1.0)
                    self.decisions[symbol]=d
                    self.regimes[symbol]=rg
                    self.rankings[symbol]=market_rank(s,d)
                    recovery_batch.append(d)
                    if d.action in ("BUY","SELL"):
                        recovery_entries.append((self.rankings[symbol],d,s))
                except Exception as exc:
                    self.last_status=f"{symbol}: opportunity recovery error: {exc}"
            if recovery_batch:
                batch=recovery_batch
            if recovery_entries:
                pending_entries=recovery_entries
                self.opportunity_recovery_active=True
                self.selector.force_reselect()
                self.last_status=(
                    f"OPPORTUNITY RECOVERY · {self.decision_starvation_scans} scans without entry · "
                    f"{len(recovery_entries)} bounded recovery candidate(s)"
                )

        # One DB transaction per scan instead of one commit per instrument.
        self.db.decisions_batch(batch)

        # Selection Engine: all markets are analysed, but only Top 5 / Top 10
        # (or the user's MANUAL shortlist) may reach execution.
        shortlist=self.selector.select(self.scan_count,fresh,self.decisions,self.rankings,self.regimes)
        allowed=set(shortlist)
        pending_entries=[x for x in pending_entries if x[1].symbol in allowed]

        if not pending_entries:
            st=self.selector.stats
            self.last_status=(
                f"NO TRADE · {st['scanned']} scanned · {st['eligible']} eligible · "
                f"{st['selected']} selected · {st['trade_ready']} trade-ready"
            )

        # Selected opportunities get risk-gated first.
        opened_before=len(self.positions)
        executable_candidates=len(pending_entries)
        gate_reasons={}

        def execution_priority(item):
            raw_rank,d,s=item
            regime=self.regimes.get(s.symbol,"MIXED")
            gov=self.learning.expectancy_governor(s.symbol,regime,d.action,s.session)
            st=self.learning.stats_for(s.symbol,regime,d.action,s.session)
            quality=float(raw_rank)
            quality += {"PROVEN":18.0,"PROBATION":5.0,"BOOTSTRAP":0.0}.get(gov.get("state","BOOTSTRAP"),0.0)
            if regime=="TREND": quality += float(self.cfg.get("execution_trend_priority_bonus",8.0))
            elif regime in ("REVERSAL","RANGE"): quality -= float(self.cfg.get("execution_weak_regime_penalty",8.0))
            if st and st.get("samples",0)>=8:
                quality += max(-10.0,min(10.0,float(st.get("expectancy_r",0))*20.0))
                quality += max(-6.0,min(6.0,(float(st.get("pf",1.0))-1.0)*8.0))
            return quality

        pending_entries=sorted(pending_entries,key=execution_priority,reverse=True)
        for _,d,s in pending_entries:
            loss_until=int(self.symbol_loss_cooldown_until.get(s.symbol,0))
            if self.scan_count<loss_until:
                why=f"Adaptive loss cooldown · {loss_until-self.scan_count} scans remaining."
                gate_reasons[why]=gate_reasons.get(why,0)+1
                self.last_status=f"{s.symbol}: {why}"
                continue
            min_gap=max(0,int(self.cfg.get("global_entry_pacing_scans",2)))
            if self.scan_count-int(getattr(self,"last_any_entry_scan",-10**9))<min_gap:
                why="Global entry pacing active."
                gate_reasons[why]=gate_reasons.get(why,0)+1
                continue
            last_exit=self.last_exit_scan.get(s.symbol,-10**9)
            if self.scan_count-last_exit<int(self.cfg.get("entry_cooldown_scans",12)):
                why="Re-entry cooldown active."
                gate_reasons[why]=gate_reasons.get(why,0)+1
                self.last_status=f"{s.symbol}: {why}"
                continue
            regime=self.regimes.get(s.symbol,"MIXED")
            gov=self.learning.expectancy_governor(s.symbol,regime,d.action,s.session)
            weak_open=sum(1 for p in self.positions if self.regimes.get(p.symbol,"MIXED") in ("REVERSAL","RANGE"))
            if regime in ("REVERSAL","RANGE") and gov.get("state")!="PROVEN":
                weak_cap=int(self.cfg.get("max_unproven_weak_regime_positions",1))
                if weak_open>=weak_cap:
                    why="Edge allocation gate · weak unproven regime capacity full."
                    gate_reasons[why]=gate_reasons.get(why,0)+1
                    self.learning.observe_blocked(d,s,regime,why,self.scan_count)
                    continue

            ok,why=self.risk.gate(self.balance,self.positions,d,s,self.scan_count)
            if ok:
                before=len(self.positions)
                self._open(d,s)
                if len(self.positions)>before:
                    self.last_open_scan=self.scan_count
                    self.last_any_entry_scan=self.scan_count
                    self.execution_starvation_scans=0
                    self.decision_starvation_scans=0
                    self.opportunity_recovery_active=False
            else:
                gate_reasons[why]=gate_reasons.get(why,0)+1
                self.learning.observe_blocked(d,s,self.regimes.get(s.symbol,"MIXED"),why,self.scan_count)
                self.last_status=f"{s.symbol}: {why}"

        opened_now=len(self.positions)>opened_before
        if executable_candidates>0 and not opened_now and len(self.positions)<int(self.cfg.get("max_open_positions",5)):
            self.execution_starvation_scans+=1
        else:
            self.execution_starvation_scans=0
        self.last_gate_reasons=gate_reasons

        # Liveness watchdog: recoverable states may never silently deadlock.
        # It never bypasses EMERGENCY or explicit user-disabled trading.
        watchdog=int(self.cfg.get("execution_starvation_watchdog_scans",90))
        if self.execution_starvation_scans>=watchdog:
            rstate,_=self.risk.recovery_state(self.scan_count)
            if rstate!="EMERGENCY":
                self.risk.sanitize_recovery_state(self.scan_count)
                # Force selector turnover as well, in case a stale shortlist and
                # a stale recovery state happen at the same time.
                self.selector.force_reselect()
                top_reason=max(gate_reasons,key=gate_reasons.get) if gate_reasons else "no gate reason"
                self.last_status=(
                    f"EXECUTION WATCHDOG · {self.execution_starvation_scans} scans without a new position · "
                    f"rechecking recoverable gates · top reason: {top_reason}"
                )
                # Do not reset the counter to zero; keep visibility until an
                # actual position is opened or no executable candidate exists.

        self._mark_and_close()
        self.db.equity(datetime.now(timezone.utc).isoformat(),self.balance,self.equity)

    def _directional_setup_gate(self,d,s):
        """Production validator using RSI structure + price structure.

        RSI extremes alone are never enough. TREND uses RSI as continuation/context;
        REVERSAL requires structural confirmation; RANGE requires a turn from an
        extreme rather than merely being at an extreme.
        """
        if not self.cfg.get("directional_setup_gate_enabled",True):
            return True,"Directional setup gate disabled."

        rg=self.regimes.get(s.symbol,regime(s))
        side=d.action
        ema_up=s.ema_fast>s.ema_slow
        mom=float(s.momentum)
        a=analyze_snapshot(s)
        support=a.supports(side,rg)

        if rg=="TREND":
            min_mom=float(self.cfg.get("trend_direction_min_momentum",0.10))
            price_aligned=(side=="BUY" and ema_up and mom>=min_mom) or (
                side=="SELL" and (not ema_up) and mom<=-min_mom
            )
            if not price_aligned:
                return False,"RSI/price gate · TREND signal not aligned with EMA + momentum."
            # RSI need not be oversold/overbought; it must simply not strongly oppose.
            if support<float(self.cfg.get("trend_min_rsi_structure_support",-15.0)):
                return False,f"RSI/price gate · TREND has opposing RSI structure ({support:+.0f})."

        elif rg=="REVERSAL":
            structural=(
                (side=="BUY" and (a.failure_swing=="BULLISH" or a.regular_divergence=="BULLISH"))
                or
                (side=="SELL" and (a.failure_swing=="BEARISH" or a.regular_divergence=="BEARISH"))
            )
            if not structural:
                return False,"RSI/price gate · REVERSAL needs divergence or RSI failure-swing confirmation."
            # Avoid reversing directly into strong still-expanding momentum.
            if side=="BUY" and mom<-float(self.cfg.get("reversal_max_opposing_momentum",0.32)):
                return False,"RSI/price gate · bullish reversal still has excessive bearish momentum."
            if side=="SELL" and mom>float(self.cfg.get("reversal_max_opposing_momentum",0.32)):
                return False,"RSI/price gate · bearish reversal still has excessive bullish momentum."

        elif rg=="RANGE":
            if side=="BUY":
                ok=(a.value<=float(self.cfg.get("range_rsi_buy_zone",42.0)) and a.slope>0)
            else:
                ok=(a.value>=float(self.cfg.get("range_rsi_sell_zone",58.0)) and a.slope<0)
            if not ok:
                return False,"RSI/price gate · RANGE requires RSI turn away from an edge, not a raw extreme."

        elif rg=="HIGH VOL":
            min_mom=float(self.cfg.get("high_vol_direction_min_momentum",0.22))
            if side=="BUY" and mom<min_mom:
                return False,"RSI/price gate · HIGH VOL long lacks positive impulse."
            if side=="SELL" and mom>-min_mom:
                return False,"RSI/price gate · HIGH VOL short lacks negative impulse."
            if support<float(self.cfg.get("high_vol_min_rsi_structure_support",-8.0)):
                return False,"RSI/price gate · HIGH VOL RSI structure opposes impulse."

        # A fresh failure swing directly against the proposed side is a universal veto.
        if side=="BUY" and a.failure_swing=="BEARISH":
            return False,"RSI/price gate · bearish RSI failure swing vetoes long."
        if side=="SELL" and a.failure_swing=="BULLISH":
            return False,"RSI/price gate · bullish RSI failure swing vetoes short."

        return True,f"RSI/price structure confirmed · {a.summary()}"

    def _open(self,d,s):
        if getattr(self.feed,"requires_fresh_live_data",False) and str(getattr(s,"feed_status","UNKNOWN")).upper()!="LIVE":
            self.last_status=f"{s.symbol}: blocked — live feed not fresh ({getattr(s,'feed_status','NO DATA')})"
            return
        rg=self.regimes.get(s.symbol,regime(s))
        # v2.8.0: the latest 99-trade PAPER review showed HIGH VOL materially
        # weaker than TREND. Use a conservative regime-specific quality gate
        # instead of overfitting individual symbols from a small sample.
        if rg=="HIGH VOL":
            min_conf=float(self.cfg.get("high_vol_min_confidence",68.0))
            min_score=float(self.cfg.get("high_vol_min_signal_score",70.0))
            if float(d.confidence)<min_conf or float(d.score)<min_score:
                reason=(f"HIGH VOL quality gate · score {float(d.score):.0f}/{min_score:.0f} · "
                        f"confidence {float(d.confidence):.0f}/{min_conf:.0f}")
                self.learning.observe_blocked(d,s,rg,reason,self.scan_count)
                self.last_status=f"{s.symbol}: {reason}"
                return

        direction_ok,direction_reason=self._directional_setup_gate(d,s)
        if not direction_ok:
            self.learning.observe_blocked(d,s,self.regimes.get(s.symbol,"MIXED"),direction_reason,self.scan_count)
            self.last_status=f"{s.symbol}: {direction_reason}"
            return

        rsi_a=analyze_snapshot(s)
        rsi_gov=self.learning.rsi_pattern_governor(
            s.symbol,self.regimes.get(s.symbol,"MIXED"),d.action,rsi_a.tags
        )
        if not rsi_gov.get("allow",True):
            reason=f"RSI pattern governor · RESEARCH-ONLY · {rsi_gov.get('reason','negative RSI-pattern expectancy')}"
            self.learning.observe_blocked(d,s,self.regimes.get(s.symbol,"MIXED"),reason,self.scan_count)
            self.last_status=f"{s.symbol}: {reason}"
            return

        risk_mult=self._risk_multiplier(d,s)
        lots,risk_amt=self.risk.size(self.balance,s.symbol,s.mid,d.stop_pips,risk_mult)
        pip=pip_size(s.symbol)
        if lots<=0:
            reason=(
                f"MIN LOT TOO RISKY — {s.symbol} minimum tradable size would exceed "
                f"approved risk ${risk_amt:.2f}"
            )
            self.learning.observe_blocked(d,s,self.regimes.get(s.symbol,"MIXED"),reason,self.scan_count)
            self.last_status=f"{s.symbol}: {reason}"
            return
        rg=self.regimes.get(s.symbol,"MIXED")
        gov=self.learning.expectancy_governor(s.symbol,rg,d.action,s.session)
        urgency=max(0.0,min(1.0,(float(d.score)+float(d.confidence)-120.0)/70.0))
        if gov.get("state")=="PROVEN":
            urgency=min(1.0,urgency+.12)
        elif gov.get("state")=="BOOTSTRAP":
            urgency=max(0.0,urgency-.12)

        est=self.execution.estimate(d.action,s,lots,self.scan_count,urgency)
        pv=self.risk.pip_value_per_lot(s.symbol,s.mid)
        expected_cost_usd=est.expected_round_trip_pips*pv*lots+est.expected_commission_usd
        expected_cost_r=expected_cost_usd/max(risk_amt,1e-9)

        max_cost_r=float(self.cfg.get("max_execution_cost_r",0.20))
        if rg in ("REVERSAL","RANGE"):
            max_cost_r=min(max_cost_r,float(self.cfg.get("weak_regime_max_execution_cost_r",0.14)))
        if gov.get("state")=="PROVEN":
            max_cost_r=max(max_cost_r,float(self.cfg.get("proven_max_execution_cost_r",0.24)))

        # Cost must also be small relative to the planned reward. This prevents
        # high-turnover "edge" that is mostly consumed by spread/slippage/fees.
        planned_reward_r=max(float(d.target_pips)/max(float(d.stop_pips),1e-9),1.0)
        max_cost_share=float(self.cfg.get("max_execution_cost_share_of_reward",0.12))
        if self.cfg.get("execution_economics_gate_enabled",True) and (
                expected_cost_r>max_cost_r or expected_cost_r>planned_reward_r*max_cost_share):
            reason=(
                f"Execution economics gate · est cost {expected_cost_r:.2f}R · "
                f"{est.order_style} · liquidity {est.liquidity_score:.2f}"
            )
            self.learning.observe_blocked(d,s,rg,reason,self.scan_count)
            self.last_status=f"{s.symbol}: {reason}"
            return

        fill=self.execution.fill(d.action,s,lots,self.scan_count,urgency,est.order_style)
        if not fill.filled:
            self.learning.observe_blocked(d,s,self.regimes.get(s.symbol,"MIXED"),fill.reason,self.scan_count)
            self.last_status=f"{s.symbol}: {fill.reason}"
            return
        if fill.requested_lots>0 and fill.lots<fill.requested_lots:
            risk_amt*=fill.lots/fill.requested_lots
        lots=fill.lots
        entry=fill.price

        # Payoff-quality gate: the previous long run still had too many small
        # winners versus full stop-outs. Preserve the signal's stop, but require
        # a minimum planned reward/risk before committing production capital.
        # Keep one regime variable throughout _open.  In v2.8.0 a later local
        # variable named `regime` shadowed the imported regime() function, which
        # caused UnboundLocalError at the first fallback lookup.
        rg=self.regimes.get(s.symbol,"MIXED")
        gov=self.learning.expectancy_governor(s.symbol,rg,d.action,s.session)
        min_rr=float(self.cfg.get("minimum_planned_rr",1.65))
        if rg=="TREND":
            min_rr=max(min_rr,float(self.cfg.get("trend_minimum_planned_rr",1.80)))
        elif rg=="HIGH VOL":
            min_rr=max(min_rr,float(self.cfg.get("high_vol_min_planned_rr",2.00)))
        elif rg in ("REVERSAL","RANGE"):
            min_rr=max(min_rr,float(self.cfg.get("weak_regime_minimum_planned_rr",1.90)))
        if gov.get("state")=="PROVEN":
            min_rr=float(self.cfg.get("proven_minimum_planned_rr",1.55))
        target_pips=max(float(d.target_pips),float(d.stop_pips)*min_rr)

        if d.action=="BUY":
            stop=entry-d.stop_pips*pip; target=entry+target_pips*pip
        else:
            stop=entry+d.stop_pips*pip; target=entry-target_pips*pip
        p=Position(str(uuid.uuid4())[:8],s.symbol,d.action,lots,entry,stop,target,risk_amt,d.timestamp,d.brain,0.0,0,d.score)
        self.positions.append(p)
        # Neural Edge v1 is shadow-only: record its exact pre-trade opinion but never alter execution.
        npred=self.neural.predict(s,d,rg) if self.cfg.get("neural_edge_enabled",True) else None
        if npred:self.neural_predictions[s.symbol]=npred
        if npred and self.cfg.get("neural_edge_enabled",True):
            import json as _json
            self.db.neural_shadow_prediction({
                "trade_id":p.id,"ts":datetime.now(timezone.utc).isoformat(),"symbol":s.symbol,"side":d.action,
                "regime":self.regimes.get(s.symbol,"MIXED"),"provider":getattr(s,"feed_provider",""),
                "feed_status":getattr(s,"feed_status","UNKNOWN"),"data_age_seconds":getattr(s,"data_age_seconds",0.0),
                "win_probability":npred.get("win_probability"),"expected_r":npred.get("expected_r"),
                "model_confidence":npred.get("confidence"),"model_samples":npred.get("samples"),
                "features_json":_json.dumps(npred.get("features",[]))})
        self.entry_context[p.id]={
            "regime":self.regimes.get(s.symbol,"MIXED"),"session":s.session,
            "score":d.score,"confidence":d.confidence,"spread":s.spread_pips,
            "rsi":s.rsi,"atr":s.atr_pips,
            "rsi_state":analyze_snapshot(s).operating_range,
            "rsi_pattern":"|".join(analyze_snapshot(s).tags),
            "rsi_bias":analyze_snapshot(s).bias,
            "rsi_slope":analyze_snapshot(s).slope,
            "rsi_support":analyze_snapshot(s).supports(d.action,rg),
            "trend":self.learning._parse_factor(d.reason,"trend"),
            "meanrev":self.learning._parse_factor(d.reason,"meanrev"),
            "breakout":self.learning._parse_factor(d.reason,"breakout"),
            "consensus":self.learning._parse_factor(d.reason,"consensus"),
            "execution_entry_commission":fill.entry_commission,
            "execution_exit_commission":fill.exit_commission_estimate,
            "execution_slippage_pips":fill.slippage_pips,
            "execution_latency_ms":fill.latency_ms,
            "execution_partial":fill.partial,
            "execution_order_style":fill.order_style,
            "execution_estimated_cost_r":expected_cost_r,
            "execution_liquidity_score":est.liquidity_score,
            "execution_size_impact":est.size_impact,
            "planned_rr":target_pips/max(float(d.stop_pips),1e-9),
            "governor_state":gov.get("state","UNKNOWN"),
            "neural_features":list(npred.get("features",[])) if npred else [],
            "neural_win_probability":float(npred.get("win_probability",0.5)) if npred else None,
            "neural_expected_r":float(npred.get("expected_r",0.0)) if npred else None,
        }
        self.position_excursions[p.id]={"mfe_r":0.0,"mae_r":0.0}
        self.reversal_votes[p.id]=0
        self.db.save_positions(self.positions)
        recovery_state,_=self.risk.recovery_state(self.scan_count)
        self.last_status=(
            f"Paper {d.action} opened: {s.symbol} {lots:.2f} lots · risk {risk_mult*self.risk.recovery_risk_multiplier():.2f}x"
            + (f" · {fill.order_style} · cost~{expected_cost_r:.2f}R · fill {fill.slippage_pips:.2f}p/{fill.latency_ms}ms" if self.execution.enabled() else "")
            + (f" · {recovery_state}" if recovery_state!="NORMAL" else "")
        )

    def _mark_and_close(self):
        unreal=0.0
        max_hold=int(self.cfg.get("max_hold_bars",180))
        opposite_score=float(self.cfg.get("opposite_exit_score",72))

        for p in list(self.positions):
            s=self.snapshots.get(p.symbol)
            if not s: continue
            p.bars_open+=1

            px=s.bid if p.side=="BUY" else s.ask
            pip=pip_size(p.symbol)
            move=(px-p.entry)/pip if p.side=="BUY" else (p.entry-px)/pip
            pv=self.risk.pip_value_per_lot(p.symbol,px)
            gross_unrealized=move*pv*p.lots
            ctx=self.entry_context.get(p.id,{})
            estimated_cost=float(ctx.get("execution_entry_commission",0.0))+float(ctx.get("execution_exit_commission",0.0))
            p.unrealized=gross_unrealized-estimated_cost
            unreal+=p.unrealized

            # PAPER research protection: move to break-even and trail only in profit.
            r_open=p.unrealized/max(p.risk_amount,1e-9)
            exc=self.position_excursions.setdefault(p.id,{"mfe_r":0.0,"mae_r":0.0})
            exc["mfe_r"]=max(float(exc.get("mfe_r",0.0)),r_open)
            exc["mae_r"]=min(float(exc.get("mae_r",0.0)),r_open)
            be_trigger=float(self.cfg.get("break_even_at_r",0.60))
            if self.regimes.get(p.symbol)=="TREND":
                be_trigger=float(self.cfg.get("trend_break_even_at_r",0.75))
            if r_open>=be_trigger:
                pad=pip*0.10
                if p.side=="BUY" and p.stop<p.entry:
                    p.stop=p.entry+pad
                elif p.side=="SELL" and p.stop>p.entry:
                    p.stop=p.entry-pad

            trail_trigger=float(self.cfg.get("trail_start_r",1.15))
            if self.regimes.get(p.symbol)=="TREND":
                trail_trigger=float(self.cfg.get("trend_trail_start_r",1.35))
            if r_open>=trail_trigger:
                trail=max(4.0,s.atr_pips*float(self.cfg.get("trail_atr_mult",1.0)))*pip
                if p.side=="BUY":
                    p.stop=max(p.stop,px-trail)
                else:
                    p.stop=min(p.stop,px+trail)

            hit_stop=(p.side=="BUY" and px<=p.stop) or (p.side=="SELL" and px>=p.stop)
            hit_target=(p.side=="BUY" and px>=p.target) or (p.side=="SELL" and px<=p.target)
            timed=p.bars_open>=max_hold

            opposite=False
            d=self.decisions.get(p.symbol)
            is_opp=bool(
                d and d.score>=opposite_score
                and d.confidence>=float(self.cfg.get("opposite_exit_confidence",68))
                and ((p.side=="BUY" and d.action=="SELL") or (p.side=="SELL" and d.action=="BUY"))
            )
            if is_opp:
                self.reversal_votes[p.id]=self.reversal_votes.get(p.id,0)+1
            else:
                self.reversal_votes[p.id]=0

            votes_needed=int(self.cfg.get("opposite_exit_confirmations",3))
            min_bars=int(self.cfg.get("opposite_exit_min_bars",8))
            # Strong reversals cut a losing trade after confirmation, but do not
            # repeatedly scalp tiny winners that should be allowed to reach TP/trail.
            opposite=(
                self.reversal_votes.get(p.id,0)>=votes_needed
                and p.bars_open>=min_bars
                and (r_open<=float(self.cfg.get("opposite_exit_max_profit_r",0.35)))
            )

            if hit_stop or hit_target or opposite or timed:
                close_px=px
                if hit_stop:
                    reason="Stop Loss"
                    # A stop may slip adversely, but a synthetic scan gap must not
                    # turn a planned ~1R stop into tens of R. Model bounded stop
                    # slippage from spread/ATR instead of closing at an arbitrary
                    # far-away scan price.
                    slip_pips=self.execution.stop_slippage_pips(p,s)
                    close_px=p.stop-slip_pips*pip if p.side=="BUY" else p.stop+slip_pips*pip
                elif hit_target:
                    reason="Take Profit"
                    # Conservative limit fill: take the target, not the full
                    # favorable synthetic jump beyond it.
                    close_px=p.target
                elif opposite:
                    reason="AI Brain Reversal"
                else:
                    reason="Max Hold Exit"
                self._close(p,close_px,reason)

        self.equity=self.balance+sum(p.unrealized for p in self.positions)
        if self.positions:
            self.db.save_positions(self.positions)

    def _close(self,p,px,reason):
        closed_at=datetime.now(timezone.utc).isoformat()
        pip=pip_size(p.symbol)
        move=(px-p.entry)/pip if p.side=="BUY" else (p.entry-px)/pip
        pv=self.risk.pip_value_per_lot(p.symbol,px)
        gross_pnl=move*pv*p.lots
        ctx=self.entry_context.get(p.id,{})
        execution_cost=(
            float(ctx.get("execution_entry_commission",0.0))
            + float(ctx.get("execution_exit_commission",0.0))
        )
        swap_cost=self.execution.swap_cost(p,closed_at)
        pnl=gross_pnl-execution_cost-swap_cost
        p.unrealized=pnl
        self.balance+=pnl
        r=pnl/max(p.risk_amount,1e-9)

        if pnl<0 and reason=="Stop Loss":
            streak=int(self.symbol_loss_streaks.get(p.symbol,0))+1
            self.symbol_loss_streaks[p.symbol]=streak
            if streak>=int(self.cfg.get("symbol_loss_streak_trigger",2)):
                base=int(self.cfg.get("symbol_loss_cooldown_scans",36))
                extra=int(self.cfg.get("symbol_loss_cooldown_extra_scans",18))*max(0,streak-2)
                self.symbol_loss_cooldown_until[p.symbol]=self.scan_count+base+extra
        elif pnl>0:
            self.symbol_loss_streaks[p.symbol]=0
            self.symbol_loss_cooldown_until.pop(p.symbol,None)

        t=ClosedTrade(p.id,p.symbol,p.side,p.lots,p.entry,px,pnl,r,p.opened_at,
                      closed_at,reason,p.brain)
        self.db.trade(t)
        self.positions.remove(p)
        self.last_exit_scan[p.symbol]=self.scan_count
        self.db.save_positions(self.positions)
        exc=self.position_excursions.pop(p.id,{"mfe_r":0.0,"mae_r":0.0})
        ctx=self.entry_context.pop(p.id,{})
        self.reversal_votes.pop(p.id,None)
        self.learning.record_trade(
            p,ctx,pnl,r,reason,p.bars_open,
            exc.get("mfe_r",0.0),exc.get("mae_r",0.0)
        )
        neural_features=ctx.get("neural_features")
        if neural_features and self.cfg.get("neural_edge_enabled",True):
            result=self.neural.observe(neural_features,r,p.id)
            self.db.neural_shadow_outcome(p.id,r,pnl,result.get("holdout",False))
        self.risk.on_trade_closed(pnl,self.scan_count)
        risk_state,remaining=self.risk.recovery_state(self.scan_count)
        suffix=""
        if risk_state=="COOLDOWN":
            suffix=f" · recovery cooldown {remaining} scans"
        elif risk_state=="RECOVERY":
            suffix=f" · recovery mode {self.risk.recovery_risk_multiplier():.2f}x risk"
        self.last_status=f"Closed {p.symbol}: {pnl:+.2f} USD ({r:+.2f}R){suffix}"

    def close_all_positions(self, reason="Manual Close All"):
        """Close every open PAPER position at the latest executable quote."""
        if not self.positions:
            self.last_status="No open positions to close."
            return 0
        # Get a fresh market snapshot without allowing new entries.
        self.refresh_market_state(force_reselect=False)
        closed=0
        for p in list(self.positions):
            s=self.snapshots.get(p.symbol)
            if not s:
                continue
            px=s.bid if p.side=="BUY" else s.ask
            pip=pip_size(p.symbol)
            move=(px-p.entry)/pip if p.side=="BUY" else (p.entry-px)/pip
            pv=self.risk.pip_value_per_lot(p.symbol,px)
            ctx=self.entry_context.get(p.id,{})
            estimated_cost=float(ctx.get("execution_entry_commission",0.0))+float(ctx.get("execution_exit_commission",0.0))
            p.unrealized=move*pv*p.lots-estimated_cost
            self._close(p,px,reason)
            closed+=1
        self.equity=self.balance+sum(p.unrealized for p in self.positions)
        self.db.equity(datetime.now(timezone.utc).isoformat(),self.balance,self.equity)
        self.last_status=f"Closed all positions · {closed} paper trades"
        return closed

    def performance(self, all_history=False):
        rows=self.db.trades() if all_history else self.db.trades_since(self.session_started_at)
        if not rows: return {"trades":0,"pnl":0,"win_rate":0,"pf":0,"expectancy":0}
        pnls=[r["pnl"] for r in rows]
        wins=[x for x in pnls if x>0]; losses=[x for x in pnls if x<0]
        gp=sum(wins); gl=abs(sum(losses))
        return {"trades":len(rows),"pnl":sum(pnls),"win_rate":len(wins)/len(rows)*100,
                "pf":gp/gl if gl else (999 if gp else 0),"expectancy":sum(pnls)/len(pnls)}
