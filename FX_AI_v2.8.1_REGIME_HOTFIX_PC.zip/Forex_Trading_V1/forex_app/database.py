import sqlite3, json
from pathlib import Path

class Database:
    def __init__(self, path="data/forex_v1.db"):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._init()

    def _init(self):
        c = self.conn.cursor()
        c.execute("""CREATE TABLE IF NOT EXISTS decisions(
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, symbol TEXT, brain TEXT,
            action TEXT, score REAL, confidence REAL, reason TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS trades(
            id TEXT PRIMARY KEY, symbol TEXT, side TEXT, lots REAL, entry REAL, exit REAL,
            pnl REAL, r_multiple REAL, opened_at TEXT, closed_at TEXT, reason TEXT, brain TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS equity(
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, balance REAL, equity REAL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS experiments(
            id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, name TEXT, status TEXT, notes TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS open_positions(
            id TEXT PRIMARY KEY, symbol TEXT, side TEXT, lots REAL, entry REAL, stop REAL, target REAL,
            risk_amount REAL, opened_at TEXT, brain TEXT, unrealized REAL, bars_open INTEGER, entry_score REAL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS learning_experiences(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            trade_id TEXT, ts TEXT, symbol TEXT, asset_class TEXT, regime TEXT, session TEXT, side TEXT,
            context_key TEXT, score REAL, confidence REAL, spread REAL, rsi REAL, atr REAL,
            trend REAL, meanrev REAL, breakout REAL, consensus REAL,
            pnl REAL, r_multiple REAL, mfe_r REAL, mae_r REAL, bars_open INTEGER, exit_reason TEXT)""")
        c.execute("""CREATE TABLE IF NOT EXISTS counterfactuals(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT, symbol TEXT, side TEXT, regime TEXT, session TEXT, score REAL, confidence REAL,
            block_reason TEXT, horizon_scans INTEGER, hypothetical_r REAL)""")
        c.execute("""CREATE TABLE IF NOT EXISTS neural_shadow(
            id INTEGER PRIMARY KEY AUTOINCREMENT, trade_id TEXT, ts TEXT, symbol TEXT, side TEXT, regime TEXT,
            provider TEXT, feed_status TEXT, data_age_seconds REAL, win_probability REAL, expected_r REAL,
            model_confidence REAL, model_samples INTEGER, features_json TEXT, outcome_r REAL, outcome_pnl REAL,
            validation_holdout INTEGER DEFAULT 0)""")

        # v2.6.0 migration: preserve old databases while adding RSI Intelligence features.
        existing={r[1] for r in c.execute("PRAGMA table_info(learning_experiences)").fetchall()}
        for name,kind in (
            ("rsi_state","TEXT"),("rsi_pattern","TEXT"),("rsi_bias","TEXT"),
            ("rsi_slope","REAL"),("rsi_support","REAL")
        ):
            if name not in existing:
                c.execute(f"ALTER TABLE learning_experiences ADD COLUMN {name} {kind}")
        self.conn.commit()

    def decision(self, d):
        self.conn.execute("INSERT INTO decisions(ts,symbol,brain,action,score,confidence,reason) VALUES(?,?,?,?,?,?,?)",
                          (d.timestamp,d.symbol,d.brain,d.action,d.score,d.confidence,d.reason))
        self.conn.commit()

    def decisions_batch(self, decisions):
        rows=[(d.timestamp,d.symbol,d.brain,d.action,d.score,d.confidence,d.reason) for d in decisions]
        if not rows:return
        self.conn.executemany(
            "INSERT INTO decisions(ts,symbol,brain,action,score,confidence,reason) VALUES(?,?,?,?,?,?,?)",
            rows
        )
        self.conn.commit()

    def trade(self, t):
        self.conn.execute("""INSERT OR REPLACE INTO trades
            (id,symbol,side,lots,entry,exit,pnl,r_multiple,opened_at,closed_at,reason,brain)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
            (t.id,t.symbol,t.side,t.lots,t.entry,t.exit,t.pnl,t.r_multiple,t.opened_at,t.closed_at,t.reason,t.brain))
        self.conn.commit()

    def equity(self, ts, balance, equity):
        self.conn.execute("INSERT INTO equity(ts,balance,equity) VALUES(?,?,?)",(ts,balance,equity))
        self.conn.commit()

    def latest_equity(self):
        return self.conn.execute("SELECT * FROM equity ORDER BY id DESC LIMIT 1").fetchone()

    def day_start_balance(self, iso_date):
        row=self.conn.execute(
            "SELECT balance FROM equity WHERE substr(ts,1,10)=? ORDER BY id ASC LIMIT 1",
            (iso_date,)
        ).fetchone()
        return float(row["balance"]) if row else None

    def period_start_balance(self, since_iso):
        row=self.conn.execute(
            "SELECT balance FROM equity WHERE ts>=? ORDER BY id ASC LIMIT 1",
            (since_iso,)
        ).fetchone()
        return float(row["balance"]) if row else None

    def save_positions(self, positions):
        self.conn.execute("DELETE FROM open_positions")
        rows=[(
            p.id,p.symbol,p.side,p.lots,p.entry,p.stop,p.target,p.risk_amount,p.opened_at,p.brain,
            p.unrealized,getattr(p,"bars_open",0),getattr(p,"entry_score",0.0)
        ) for p in positions]
        if rows:
            self.conn.executemany("""INSERT INTO open_positions
                (id,symbol,side,lots,entry,stop,target,risk_amount,opened_at,brain,unrealized,bars_open,entry_score)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",rows)
        self.conn.commit()

    def load_positions(self):
        return self.conn.execute("SELECT * FROM open_positions ORDER BY opened_at").fetchall()

    def equity_history(self, n=300):
        return self.conn.execute("SELECT * FROM equity ORDER BY id DESC LIMIT ?",(n,)).fetchall()[::-1]

    def equity_history_since(self, since_iso, n=300):
        return self.conn.execute(
            "SELECT * FROM equity WHERE ts>=? ORDER BY id DESC LIMIT ?",
            (since_iso,n)
        ).fetchall()[::-1]

    def recent_decisions(self, n=100):
        return self.conn.execute("SELECT * FROM decisions ORDER BY id DESC LIMIT ?",(n,)).fetchall()

    def recent_decisions_since(self, since_iso, n=100):
        return self.conn.execute(
            "SELECT * FROM decisions WHERE ts>=? ORDER BY id DESC LIMIT ?",
            (since_iso,n)
        ).fetchall()

    def trades(self):
        return self.conn.execute("SELECT * FROM trades ORDER BY closed_at DESC").fetchall()

    def trades_since(self, since_iso):
        return self.conn.execute(
            "SELECT * FROM trades WHERE closed_at>=? ORDER BY closed_at DESC",
            (since_iso,)
        ).fetchall()

    def clear_open_positions(self):
        self.conn.execute("DELETE FROM open_positions")
        self.conn.commit()

    def learning_experience(self,row):
        cols=("trade_id","ts","symbol","asset_class","regime","session","side","context_key",
              "score","confidence","spread","rsi","atr","trend","meanrev","breakout","consensus",
              "rsi_state","rsi_pattern","rsi_bias","rsi_slope","rsi_support",
              "pnl","r_multiple","mfe_r","mae_r","bars_open","exit_reason")
        vals=[row.get(c) for c in cols]
        self.conn.execute(
            f"INSERT INTO learning_experiences({','.join(cols)}) VALUES({','.join('?' for _ in cols)})",
            vals
        )
        self.conn.commit()

    def learning_experiences(self,n=5000):
        return self.conn.execute(
            "SELECT * FROM learning_experiences ORDER BY id DESC LIMIT ?",(n,)
        ).fetchall()

    def counterfactual(self,row):
        cols=("ts","symbol","side","regime","session","score","confidence","block_reason","horizon_scans","hypothetical_r")
        vals=[row.get(c) for c in cols]
        self.conn.execute(
            f"INSERT INTO counterfactuals({','.join(cols)}) VALUES({','.join('?' for _ in cols)})",
            vals
        )
        self.conn.commit()

    def counterfactuals(self,n=1000):
        return self.conn.execute(
            "SELECT * FROM counterfactuals ORDER BY id DESC LIMIT ?",(n,)
        ).fetchall()
    def neural_shadow_prediction(self,row):
        cols=("trade_id","ts","symbol","side","regime","provider","feed_status","data_age_seconds",
              "win_probability","expected_r","model_confidence","model_samples","features_json")
        vals=[row.get(c) for c in cols]
        self.conn.execute(f"INSERT INTO neural_shadow({','.join(cols)}) VALUES({','.join('?' for _ in cols)})",vals)
        self.conn.commit()

    def neural_shadow_outcome(self,trade_id,outcome_r,outcome_pnl,validation_holdout=False):
        self.conn.execute("UPDATE neural_shadow SET outcome_r=?, outcome_pnl=?, validation_holdout=? WHERE trade_id=?",
                          (float(outcome_r),float(outcome_pnl),1 if validation_holdout else 0,trade_id))
        self.conn.commit()

    def neural_shadow_rows(self,n=10000):
        return self.conn.execute("SELECT * FROM neural_shadow ORDER BY id DESC LIMIT ?",(n,)).fetchall()

