from dataclasses import replace
from collections import defaultdict
from datetime import datetime, timezone
import math, re

from .instruments import instrument_meta

def clamp(v,a,b):
    return max(a,min(b,v))

class SelfLearningEngine:
    """Evidence-gated PAPER learning layer.

    The learner never rewrites the Champion model after a few trades.
    It records detailed outcomes, builds regime/context statistics, evaluates
    blocked trades counterfactually, and only applies small bounded adjustments
    after a context passes a minimum-sample promotion gate.
    """
    def __init__(self,cfg,db):
        self.cfg=cfg
        self.db=db
        self.pending_counterfactuals={}
        self._cache={}
        self._symbol_cache={}
        self._fast_context_cache={}
        self._regime_cache={}
        self._side_cache={}
        self._rsi_pattern_cache={}
        self._cache_trade_count=-1
        self.promoted_contexts=set()
        self.last_note="Learning Lab collecting evidence"

    def apply_config(self,cfg):
        self.cfg=cfg
        self._cache={}
        self._symbol_cache={}
        self._rsi_pattern_cache={}
        self._cache_trade_count=-1

    def context_key(self,symbol,regime,side,session):
        meta=instrument_meta(symbol)
        # Keep learning broad enough to gather evidence, but regime-aware.
        return f"{meta['asset_class']}|{regime}|{side}|{session}"

    def _parse_factor(self,reason,name):
        pats={
            "trend":r"Trend\s*([+-]?\d+(?:\.\d+)?)",
            "meanrev":r"MeanRev\s*([+-]?\d+(?:\.\d+)?)",
            "breakout":r"Breakout\s*([+-]?\d+(?:\.\d+)?)",
            "consensus":r"consensus\s*(\d+(?:\.\d+)?)%",
        }
        m=re.search(pats[name],reason or "",re.I)
        return float(m.group(1)) if m else 0.0

    def record_trade(self,position,decision_context,pnl,r_multiple,exit_reason,bars_open,mfe_r,mae_r):
        ctx=decision_context or {}
        symbol=position.symbol
        regime=ctx.get("regime","MIXED")
        session=ctx.get("session","Unknown")
        side=position.side
        key=self.context_key(symbol,regime,side,session)
        self.db.learning_experience({
            "trade_id":position.id,
            "ts":datetime.now(timezone.utc).isoformat(),
            "symbol":symbol,
            "asset_class":instrument_meta(symbol)["asset_class"],
            "regime":regime,
            "session":session,
            "side":side,
            "context_key":key,
            "score":float(ctx.get("score",position.entry_score or 0)),
            "confidence":float(ctx.get("confidence",0)),
            "spread":float(ctx.get("spread",0)),
            "rsi":float(ctx.get("rsi",0)),
            "atr":float(ctx.get("atr",0)),
            "trend":float(ctx.get("trend",0)),
            "meanrev":float(ctx.get("meanrev",0)),
            "breakout":float(ctx.get("breakout",0)),
            "consensus":float(ctx.get("consensus",0)),
            "rsi_state":str(ctx.get("rsi_state","UNKNOWN")),
            "rsi_pattern":str(ctx.get("rsi_pattern","")),
            "rsi_bias":str(ctx.get("rsi_bias","NEUTRAL")),
            "rsi_slope":float(ctx.get("rsi_slope",0)),
            "rsi_support":float(ctx.get("rsi_support",0)),
            "pnl":float(pnl),
            "r_multiple":float(r_multiple),
            "mfe_r":float(mfe_r),
            "mae_r":float(mae_r),
            "bars_open":int(bars_open),
            "exit_reason":str(exit_reason),
        })
        self._cache_trade_count=-1

    def _rebuild_cache(self):
        rows=list(self.db.learning_experiences())
        if len(rows)==self._cache_trade_count:
            return
        groups=defaultdict(list)
        symbol_groups=defaultdict(list)
        fast_groups=defaultdict(list)
        regime_groups=defaultdict(list)
        side_groups=defaultdict(list)
        rsi_pattern_groups=defaultdict(list)
        for r in rows:
            groups[r["context_key"]].append(r)
            symbol_groups[f"{r['symbol']}|{r['side']}"].append(r)
            fast_groups[f"{r['symbol']}|{r['side']}|{r['regime']}"].append(r)
            regime_groups[f"{r['asset_class']}|{r['regime']}"].append(r)
            side_groups[f"{r['asset_class']}|{r['side']}"].append(r)
            pattern_text=(r["rsi_pattern"] or "") if "rsi_pattern" in r.keys() else ""
            for tag in [x for x in pattern_text.split("|") if x]:
                rsi_pattern_groups[f"{r['asset_class']}|{r['regime']}|{r['side']}|{tag}"].append(r)
        cache={}
        symbol_cache={}
        fast_context_cache={}
        regime_cache={}
        side_cache={}
        rsi_pattern_cache={}
        promoted=set()
        min_samples=int(self.cfg.get("learning_min_samples",24))
        promotion_samples=int(self.cfg.get("learning_promotion_samples",40))
        for key,items in groups.items():
            # DB returns newest first. Validation must respect time ordering.
            items=list(reversed(items))
            rs=[float(x["r_multiple"]) for x in items]
            wins=[r for r in rs if r>0]
            losses=[r for r in rs if r<0]
            gp=sum(wins); gl=abs(sum(losses))
            pf=gp/gl if gl>1e-12 else (9.99 if gp>0 else 0.0)
            expectancy=sum(rs)/len(rs)
            win_rate=len(wins)/len(rs)*100 if rs else 0

            # Chronological holdout / walk-forward-style sanity gate: promotion
            # requires the later sample to remain positive, not only the full sample.
            split=max(1,int(len(rs)*.65))
            validation=rs[split:] if len(rs)-split>=3 else []
            validation_expectancy=sum(validation)/len(validation) if validation else 0.0
            vw=[x for x in validation if x>0]; vl=[x for x in validation if x<0]
            vgp=sum(vw); vgl=abs(sum(vl))
            validation_pf=vgp/vgl if vgl>1e-12 else (9.99 if vgp>0 else 0.0)

            # Concept drift monitor compares a recent window with older evidence.
            drift=False; drift_delta=0.0
            drift_window=max(6,int(self.cfg.get("learning_drift_window",10)))
            if len(rs)>=drift_window*2:
                old_rs=rs[:-drift_window]; recent_rs=rs[-drift_window:]
                old_e=sum(old_rs)/len(old_rs); recent_e=sum(recent_rs)/len(recent_rs)
                drift_delta=recent_e-old_e
                drift=(drift_delta<=-abs(float(self.cfg.get("learning_drift_threshold_r",0.30)))
                       or recent_e<float(self.cfg.get("learning_drift_floor_r",-0.15)))

            # Shrink noisy small samples toward neutral.
            shrink=len(rs)/(len(rs)+min_samples)
            shrunk_expectancy=expectancy*shrink
            stability=max(0.0,1.0-min(1.0,(max(rs)-min(rs))/6.0)) if len(rs)>=2 else 0.0
            status="RESEARCH"
            if len(rs)>=min_samples:
                status="CHALLENGER"
            if drift and len(rs)>=min_samples:
                status="DRIFT"
            if (not drift and len(rs)>=promotion_samples
                    and expectancy>float(self.cfg.get("learning_min_expectancy_r",0.05))
                    and pf>=float(self.cfg.get("learning_min_profit_factor",1.10))
                    and win_rate>=float(self.cfg.get("learning_min_win_rate",40.0))
                    and validation and validation_expectancy>0
                    and validation_pf>=float(self.cfg.get("learning_validation_min_pf",1.0))):
                status="PROMOTED"
                promoted.add(key)
            cache[key]={
                "samples":len(rs),"expectancy_r":expectancy,"shrunk_expectancy_r":shrunk_expectancy,
                "pf":pf,"win_rate":win_rate,"stability":stability,"status":status,
                "validation_expectancy_r":validation_expectancy,"validation_pf":validation_pf,
                "drift":drift,"drift_delta_r":drift_delta,
            }
        # Symbol+side guard: learn persistent instrument-specific weakness
        # without allowing old execution anomalies to dominate. R is clipped for
        # robust statistics because previous simulator bugs could create huge R.
        sym_window=max(6,int(self.cfg.get("learning_symbol_recent_window",12)))
        for key,items in symbol_groups.items():
            items=list(reversed(items))
            rs=[clamp(float(x["r_multiple"]),-2.5,2.5) for x in items]
            recent=rs[-sym_window:]
            wins=[x for x in recent if x>0]
            losses=[x for x in recent if x<0]
            gp=sum(wins); gl=abs(sum(losses))
            pf=gp/gl if gl>1e-12 else (9.99 if gp>0 else 0.0)
            expectancy=sum(recent)/len(recent) if recent else 0.0
            win_rate=len(wins)/len(recent)*100 if recent else 0.0
            symbol_cache[key]={
                "samples":len(rs),
                "recent_samples":len(recent),
                "expectancy_r":expectancy,
                "pf":pf,
                "win_rate":win_rate,
            }

        fast_window=max(4,int(self.cfg.get("learning_fast_context_window",8)))
        for key,items in fast_groups.items():
            rs=[clamp(float(x["r_multiple"]),-2.0,2.0) for x in list(reversed(items))][-fast_window:]
            wins=[x for x in rs if x>0]; losses=[x for x in rs if x<0]
            gp=sum(wins); gl=abs(sum(losses))
            fast_context_cache[key]={
                "samples":len(rs),
                "expectancy_r":sum(rs)/len(rs) if rs else 0.0,
                "pf":gp/gl if gl>1e-12 else (9.99 if gp>0 else 0.0),
                "loss_rate":len(losses)/len(rs) if rs else 0.0,
            }
        regime_window=max(20,int(self.cfg.get("governor_regime_window",60)))
        for key,items in regime_groups.items():
            ordered=list(reversed(items))
            rs=[clamp(float(x["r_multiple"]),-2.0,2.0) for x in ordered][-regime_window:]
            wins=[x for x in rs if x>0]; losses=[x for x in rs if x<0]
            gp=sum(wins); gl=abs(sum(losses))
            recent_half=rs[-max(6,len(rs)//2):] if rs else []
            regime_cache[key]={
                "samples":len(rs),
                "expectancy_r":sum(rs)/len(rs) if rs else 0.0,
                "pf":gp/gl if gl>1e-12 else (9.99 if gp>0 else 0.0),
                "win_rate":len(wins)/len(rs)*100 if rs else 0.0,
                "recent_expectancy_r":sum(recent_half)/len(recent_half) if recent_half else 0.0,
            }

        side_window=max(16,int(self.cfg.get("learning_side_window",50)))
        for key,items in side_groups.items():
            rs=[clamp(float(x["r_multiple"]),-2.0,2.0) for x in list(reversed(items))][-side_window:]
            wins=[x for x in rs if x>0]; losses=[x for x in rs if x<0]
            gp=sum(wins); gl=abs(sum(losses))
            side_cache[key]={
                "samples":len(rs),
                "expectancy_r":sum(rs)/len(rs) if rs else 0.0,
                "pf":gp/gl if gl>1e-12 else (9.99 if gp>0 else 0.0),
                "win_rate":len(wins)/len(rs)*100 if rs else 0.0,
            }

        pattern_window=max(12,int(self.cfg.get("learning_rsi_pattern_window",60)))
        for key,items in rsi_pattern_groups.items():
            rs=[clamp(float(x["r_multiple"]),-2.0,2.0) for x in list(reversed(items))][-pattern_window:]
            wins=[x for x in rs if x>0]; losses=[x for x in rs if x<0]
            gp=sum(wins); gl=abs(sum(losses))
            rsi_pattern_cache[key]={
                "samples":len(rs),
                "expectancy_r":sum(rs)/len(rs) if rs else 0.0,
                "pf":gp/gl if gl>1e-12 else (9.99 if gp>0 else 0.0),
                "win_rate":len(wins)/len(rs)*100 if rs else 0.0,
            }

        self._cache=cache
        self._symbol_cache=symbol_cache
        self._fast_context_cache=fast_context_cache
        self._regime_cache=regime_cache
        self._side_cache=side_cache
        self._rsi_pattern_cache=rsi_pattern_cache
        self.promoted_contexts=promoted
        self._cache_trade_count=len(rows)

    def stats_for(self,symbol,regime,side,session):
        self._rebuild_cache()
        return self._cache.get(self.context_key(symbol,regime,side,session))

    def symbol_stats_for(self,symbol,side):
        self._rebuild_cache()
        return self._symbol_cache.get(f"{symbol}|{side}")

    def fast_context_stats(self,symbol,side,regime):
        self._rebuild_cache()
        return self._fast_context_cache.get(f"{symbol}|{side}|{regime}")

    def regime_stats_for(self,asset_class,regime):
        self._rebuild_cache()
        return self._regime_cache.get(f"{asset_class}|{regime}")

    def side_stats_for(self,asset_class,side):
        self._rebuild_cache()
        return self._side_cache.get(f"{asset_class}|{side}")

    def rsi_pattern_stats(self,asset_class,regime,side,tags):
        self._rebuild_cache()
        out=[]
        for tag in tags or ():
            st=self._rsi_pattern_cache.get(f"{asset_class}|{regime}|{side}|{tag}")
            if st: out.append((tag,st))
        return out

    def expectancy_governor(self,symbol,regime,side,session):
        """Return production eligibility + risk scale from observed PAPER evidence.

        The governor never creates a BUY/SELL. It can only reduce risk or move an
        already executable Champion signal to RESEARCH-ONLY.
        """
        if not self.cfg.get("expectancy_governor_enabled",True):
            return {"state":"DISABLED","risk_mult":1.0,"allow":True,"reason":"Governor disabled"}

        meta=instrument_meta(symbol)
        asset=meta["asset_class"]
        st=self.stats_for(symbol,regime,side,session)
        sym=self.symbol_stats_for(symbol,side)
        fast=self.fast_context_stats(symbol,side,regime)
        broad=self.regime_stats_for(asset,regime)
        side_stats=self.side_stats_for(asset,side)

        bootstrap=int(self.cfg.get("governor_bootstrap_samples",8))
        proof_samples=int(self.cfg.get("governor_proven_samples",16))
        min_e=float(self.cfg.get("governor_min_expectancy_r",0.03))
        min_pf=float(self.cfg.get("governor_min_pf",1.05))
        research_e=float(self.cfg.get("governor_research_only_expectancy_r",-0.12))
        research_pf=float(self.cfg.get("governor_research_only_pf",0.78))

        # Default uncertainty gets reduced capital. REVERSAL starts even more
        # conservatively because the long-run overnight sample was strongly negative.
        risk=float(self.cfg.get("governor_bootstrap_risk_mult",0.25))
        if regime=="REVERSAL":
            risk=min(risk,float(self.cfg.get("governor_reversal_bootstrap_risk_mult",0.08)))
        elif regime=="RANGE":
            risk=min(risk,float(self.cfg.get("governor_range_bootstrap_risk_mult",0.10)))
        elif regime=="TREND":
            risk=min(1.0,max(risk,float(self.cfg.get("governor_trend_bootstrap_risk_mult",0.30))))
        if asset=="FOREX":
            risk=min(risk,float(self.cfg.get("governor_forex_bootstrap_risk_mult",0.20)))

        state="BOOTSTRAP"; allow=True
        reasons=[]

        # Broad asset/regime evidence prevents thousands of trades in a regime
        # that is already losing across many symbols.
        if broad and broad["samples"]>=int(self.cfg.get("governor_regime_min_samples",30)):
            be=float(broad["expectancy_r"]); bpf=float(broad["pf"])
            reasons.append(f"{asset}/{regime} n={broad['samples']} E={be:+.2f}R PF={bpf:.2f}")
            if (be<=float(self.cfg.get("governor_regime_block_expectancy_r",-0.10))
                    and bpf<=float(self.cfg.get("governor_regime_block_pf",0.85))):
                state="RESEARCH-ONLY"; allow=False; risk=0.0

        if st:
            reasons.append(f"context n={st['samples']} E={st['expectancy_r']:+.2f}R PF={st['pf']:.2f}")
            if st["status"]=="DRIFT" and st["samples"]>=bootstrap:
                state="RESEARCH-ONLY"; allow=False; risk=0.0
            elif st["samples"]>=bootstrap and (
                    st["expectancy_r"]<=research_e or st["pf"]<=research_pf):
                state="RESEARCH-ONLY"; allow=False; risk=0.0
            elif (st["samples"]>=proof_samples
                    and st["expectancy_r"]>=min_e
                    and st["pf"]>=min_pf
                    and st.get("validation_expectancy_r",0)>0
                    and st.get("validation_pf",0)>=1.0):
                state="PROVEN"; risk=1.0
            elif st["samples"]>=bootstrap:
                state="PROBATION"
                weak_cap=float(self.cfg.get("governor_weak_regime_probation_risk_mult",0.18))
                risk=min(float(self.cfg.get("governor_probation_risk_mult",0.35)),
                         weak_cap if regime in ("REVERSAL","RANGE") else 1.0)

        # Long/short asymmetry is learned from actual PAPER outcomes instead of
        # assuming BUY and SELL have identical edge. A persistently bad side gets
        # lower risk or research-only treatment at the asset-class level.
        if side_stats and side_stats["samples"]>=int(self.cfg.get("governor_side_min_samples",20)):
            se=float(side_stats["expectancy_r"]); spf=float(side_stats["pf"])
            reasons.append(f"{asset}/{side} n={side_stats['samples']} E={se:+.2f}R PF={spf:.2f}")
            if (se<=float(self.cfg.get("governor_side_block_expectancy_r",-0.12))
                    and spf<=float(self.cfg.get("governor_side_block_pf",0.82))):
                state="RESEARCH-ONLY"; allow=False; risk=0.0
            elif se<0 or spf<.95:
                risk=min(risk,float(self.cfg.get("governor_side_negative_risk_mult",0.25)))

        # Fast and symbol evidence can veto a broad context that looks okay.
        if fast and fast["samples"]>=int(self.cfg.get("learning_fast_context_min_samples",4)):
            reasons.append(f"fast E={fast['expectancy_r']:+.2f}R PF={fast['pf']:.2f}")
            if (fast["expectancy_r"]<=float(self.cfg.get("governor_fast_veto_expectancy_r",-0.45))
                    and fast["pf"]<=float(self.cfg.get("governor_fast_veto_pf",0.60))):
                state="RESEARCH-ONLY"; allow=False; risk=0.0
        if sym and sym["recent_samples"]>=int(self.cfg.get("learning_symbol_min_samples",6)):
            reasons.append(f"symbol E={sym['expectancy_r']:+.2f}R PF={sym['pf']:.2f}")
            if (sym["expectancy_r"]<=float(self.cfg.get("governor_symbol_veto_expectancy_r",-0.25))
                    and sym["pf"]<=float(self.cfg.get("governor_symbol_veto_pf",0.70))):
                state="RESEARCH-ONLY"; allow=False; risk=0.0

        # A strong broad regime cannot override a specifically bad context, but a
        # PROVEN context can use full risk only if its broader regime is not poor.
        if state=="PROVEN" and broad and broad["samples"]>=30:
            if broad["expectancy_r"]<0 or broad["pf"]<0.95:
                state="PROBATION"; risk=min(risk,0.40)

        return {
            "state":state,"risk_mult":max(0.0,min(1.0,risk)),"allow":allow,
            "reason":" · ".join(reasons) if reasons else "collecting evidence",
        }

    def rsi_pattern_governor(self,symbol,regime,side,tags):
        """Evidence gate for RSI features observed at the current setup."""
        if not self.cfg.get("rsi_pattern_learning_enabled",True):
            return {"allow":True,"risk_mult":1.0,"reason":"RSI pattern learning disabled"}
        asset=instrument_meta(symbol)["asset_class"]
        stats=self.rsi_pattern_stats(asset,regime,side,tags)
        min_samples=int(self.cfg.get("rsi_pattern_min_samples",14))
        bad_e=float(self.cfg.get("rsi_pattern_block_expectancy_r",-0.18))
        bad_pf=float(self.cfg.get("rsi_pattern_block_pf",0.72))
        good_e=float(self.cfg.get("rsi_pattern_proven_expectancy_r",0.08))
        good_pf=float(self.cfg.get("rsi_pattern_proven_pf",1.12))
        risk=1.0; allow=True; notes=[]
        for tag,st in stats:
            if st["samples"]<min_samples:
                continue
            notes.append(f"{tag} n={st['samples']} E={st['expectancy_r']:+.2f}R PF={st['pf']:.2f}")
            if st["expectancy_r"]<=bad_e and st["pf"]<=bad_pf:
                allow=False; risk=0.0
            elif st["expectancy_r"]<0 or st["pf"]<.95:
                risk=min(risk,float(self.cfg.get("rsi_pattern_negative_risk_mult",0.30)))
            elif st["expectancy_r"]>=good_e and st["pf"]>=good_pf:
                risk=max(risk,1.0)
        return {"allow":allow,"risk_mult":risk,"reason":" · ".join(notes) if notes else "collecting RSI-pattern evidence"}

    def governor_risk_multiplier(self,symbol,regime,side,session):
        return float(self.expectancy_governor(symbol,regime,side,session)["risk_mult"])

    def global_expectancy_stats(self):
        """Rolling after-execution PAPER expectancy used only for risk scaling."""
        rows=list(self.db.learning_experiences())
        window=max(12,int(self.cfg.get("governor_global_window",40)))
        recent=list(reversed(rows))[-window:]
        rs=[clamp(float(x["r_multiple"]),-2.0,2.0) for x in recent]
        wins=[x for x in rs if x>0]; losses=[x for x in rs if x<0]
        gp=sum(wins); gl=abs(sum(losses))
        return {
            "samples":len(rs),
            "expectancy_r":sum(rs)/len(rs) if rs else 0.0,
            "pf":gp/gl if gl>1e-12 else (9.99 if gp>0 else 0.0),
        }

    def global_risk_multiplier(self):
        if not self.cfg.get("expectancy_governor_enabled",True):
            return 1.0
        st=self.global_expectancy_stats()
        n=st["samples"]
        if n<int(self.cfg.get("governor_global_min_samples",16)):
            return float(self.cfg.get("governor_global_bootstrap_risk_mult",0.50))
        e=float(st["expectancy_r"]); pf=float(st["pf"])
        if e<=float(self.cfg.get("governor_global_severe_expectancy_r",-0.20)) or pf<=float(self.cfg.get("governor_global_severe_pf",0.70)):
            return float(self.cfg.get("governor_global_severe_risk_mult",0.18))
        if e<0 or pf<0.95:
            return float(self.cfg.get("governor_global_negative_risk_mult",0.35))
        if e<float(self.cfg.get("governor_global_full_expectancy_r",0.05)) or pf<1.05:
            return float(self.cfg.get("governor_global_probation_risk_mult",0.60))
        return 1.0

    def adjust_decision(self,decision,snapshot,regime):
        """Apply only evidence-gated, bounded learning adjustments.

        WAIT/BLOCK is never promoted to a trade by the learner. The learner may
        downgrade a weak context, or modestly boost an already-executable signal
        after that exact context has passed the promotion gate.
        """
        if not self.cfg.get("self_learning_enabled",True):
            return decision
        if decision.action not in ("BUY","SELL"):
            return decision
        st=self.stats_for(decision.symbol,regime,decision.action,snapshot.session)
        sym=self.symbol_stats_for(decision.symbol,decision.action)
        fast=self.fast_context_stats(decision.symbol,decision.action,regime)
        if not st and not sym and not fast:
            return decision

        score=float(decision.score); conf=float(decision.confidence)
        if st:
            note=f"Learning {st['status']} n={st['samples']} E={st['expectancy_r']:+.2f}R PF={st['pf']:.2f}"
        else:
            note="Learning context collecting evidence"

        # Challenger evidence can protect the Champion from repeatedly bad contexts,
        # but positive boosts require PROMOTED evidence.
        if st and st["status"]=="DRIFT":
            penalty=clamp(3.0+abs(st.get("drift_delta_r",0))*8,3,10)
            score-=penalty
            conf-=penalty
            note+=f" · concept drift {st.get('drift_delta_r',0):+.2f}R"
        elif st and st["status"] in ("CHALLENGER","PROMOTED") and st["expectancy_r"]<0:
            penalty=clamp(abs(st["shrunk_expectancy_r"])*12,0,8)
            score-=penalty
            conf-=penalty*.8
        elif st and st["status"]=="PROMOTED" and st["expectancy_r"]>0:
            boost=clamp(st["shrunk_expectancy_r"]*8,0,5)
            score+=boost
            conf+=boost*.7

        # Instrument-specific guard. Repeated poor recent performance on the
        # same symbol+direction receives a stronger bounded penalty than the
        # broad asset/regime context. This helps the AI stop recycling weak
        # markets while still allowing future recovery after new evidence.
        symbol_block=False
        if sym and sym["recent_samples"]>=int(self.cfg.get("learning_symbol_min_samples",6)):
            sym_e=float(sym["expectancy_r"]); sym_pf=float(sym["pf"])
            if sym_e<0 or sym_pf<float(self.cfg.get("learning_symbol_penalty_pf",0.90)):
                penalty=clamp(
                    abs(min(0.0,sym_e))*float(self.cfg.get("learning_symbol_penalty_scale",12.0))
                    + max(0.0,float(self.cfg.get("learning_symbol_penalty_pf",0.90))-sym_pf)*5.0,
                    0.0,float(self.cfg.get("learning_symbol_penalty_max",12.0))
                )
                score-=penalty
                conf-=penalty*.85
                note+=f" · SymbolGuard n={sym['recent_samples']} E={sym_e:+.2f}R PF={sym_pf:.2f}"
            if (sym["recent_samples"]>=int(self.cfg.get("learning_symbol_block_samples",10))
                    and sym_e<=float(self.cfg.get("learning_symbol_block_expectancy_r",-0.30))
                    and sym_pf<=float(self.cfg.get("learning_symbol_block_pf",0.65))):
                symbol_block=True
                note+=" · symbol/direction temporarily suppressed"

        fast_block=False
        if fast and fast["samples"]>=int(self.cfg.get("learning_fast_context_min_samples",4)):
            fe=float(fast["expectancy_r"]); fpf=float(fast["pf"]); flr=float(fast["loss_rate"])
            if fe<0:
                fp=clamp(abs(fe)*float(self.cfg.get("learning_fast_context_penalty_scale",9.0)),0,9)
                score-=fp; conf-=fp*.8
                note+=f" · FastGuard {regime} n={fast['samples']} E={fe:+.2f}R PF={fpf:.2f}"
            if (fe<=float(self.cfg.get("learning_fast_context_block_expectancy_r",-0.55))
                    and fpf<=float(self.cfg.get("learning_fast_context_block_pf",0.55))
                    and flr>=float(self.cfg.get("learning_fast_context_block_loss_rate",0.70))):
                fast_block=True
                note+=" · fast context suppressed"

        gov=self.expectancy_governor(decision.symbol,regime,decision.action,snapshot.session)
        note+=f" · GOV {gov['state']} risk={gov['risk_mult']:.2f}x"
        if gov["reason"]:
            note+=f" [{gov['reason']}]"

        score=clamp(score,0,100); conf=clamp(conf,0,95)
        action=decision.action
        if not gov["allow"]:
            action="WAIT"
            note+=" · GOVERNOR RESEARCH-ONLY"
        elif symbol_block or fast_block:
            action="WAIT"
        elif score<float(self.cfg.get("min_signal_score",63)) or conf<float(self.cfg.get("min_confidence",56)):
            action="WAIT"
            note+=" · downgraded below execution threshold"

        self.last_note=note
        return replace(decision,action=action,score=round(score,1),confidence=round(conf,1),
                       reason=(decision.reason+" | "+note))

    def observe_blocked(self,decision,snapshot,regime,reason,scan_count):
        if not self.cfg.get("counterfactual_learning_enabled",True):
            return
        if decision.action not in ("BUY","SELL"):
            return
        key=f"{decision.symbol}|{decision.action}|{str(reason).split(chr(40))[0].strip()}"
        if key in self.pending_counterfactuals:
            return
        self.pending_counterfactuals[key]={
            "symbol":decision.symbol,"side":decision.action,"scan":int(scan_count),
            "entry":float(snapshot.mid),"stop_pips":float(decision.stop_pips),
            "score":float(decision.score),"confidence":float(decision.confidence),
            "regime":regime,"session":snapshot.session,"reason":str(reason),
        }

    def resolve_counterfactuals(self,snapshots,scan_count):
        horizon=int(self.cfg.get("counterfactual_horizon_scans",12))
        done=[]
        for key,item in self.pending_counterfactuals.items():
            if scan_count-item["scan"]<horizon:
                continue
            s=snapshots.get(item["symbol"])
            if not s:
                continue
            # Normalize price move by the instrument's actual stop distance.
            from .market import pip_size
            pip=pip_size(item["symbol"])
            move_pips=(s.mid-item["entry"])/pip if item["side"]=="BUY" else (item["entry"]-s.mid)/pip
            hypothetical_r=move_pips/max(item["stop_pips"],1e-9)
            self.db.counterfactual({
                "ts":datetime.now(timezone.utc).isoformat(),
                "symbol":item["symbol"],"side":item["side"],"regime":item["regime"],
                "session":item["session"],"score":item["score"],"confidence":item["confidence"],
                "block_reason":item["reason"],"horizon_scans":horizon,
                "hypothetical_r":float(hypothetical_r),
            })
            done.append(key)
        for key in done:
            self.pending_counterfactuals.pop(key,None)

    def summary(self):
        self._rebuild_cache()
        rows=list(self.db.learning_experiences())
        cf_capacity=int(self.cfg.get("counterfactual_memory_capacity",500))
        cfs=list(self.db.counterfactuals(cf_capacity))
        promoted=sum(1 for v in self._cache.values() if v["status"]=="PROMOTED")
        challengers=sum(1 for v in self._cache.values() if v["status"]=="CHALLENGER")
        drifted=sum(1 for v in self._cache.values() if v["status"]=="DRIFT")
        avg_r=sum(float(r["r_multiple"]) for r in rows)/len(rows) if rows else 0.0
        missed=sum(1 for r in cfs if float(r["hypothetical_r"])>0.5)
        global_stats=self.global_expectancy_stats()
        weak_sides=sum(
            1 for v in self._side_cache.values()
            if v["samples"]>=int(self.cfg.get("governor_side_min_samples",20))
            and v["expectancy_r"]<0
        )
        weak_symbols=sum(
            1 for v in self._symbol_cache.values()
            if v["recent_samples"]>=int(self.cfg.get("learning_symbol_min_samples",6))
            and v["expectancy_r"]<0
        )
        governor_research=sum(
            1 for v in self._cache.values()
            if v["samples"]>=int(self.cfg.get("governor_bootstrap_samples",8))
            and (v["expectancy_r"]<=float(self.cfg.get("governor_research_only_expectancy_r",-0.12))
                 or v["pf"]<=float(self.cfg.get("governor_research_only_pf",0.78)))
        )
        proven_contexts=sum(
            1 for v in self._cache.values()
            if v["samples"]>=int(self.cfg.get("governor_proven_samples",16))
            and v["expectancy_r"]>=float(self.cfg.get("governor_min_expectancy_r",0.03))
            and v["pf"]>=float(self.cfg.get("governor_min_pf",1.05))
            and v.get("validation_expectancy_r",0)>0
        )
        return {
            "experiences":len(rows),"contexts":len(self._cache),"promoted":promoted,
            "challengers":challengers,"drifted":drifted,"avg_r":avg_r,"counterfactuals":len(cfs),
            "counterfactual_capacity":cf_capacity,
            "weak_symbol_directions":weak_symbols,
            "governor_research_only":governor_research,
            "governor_proven":proven_contexts,
            "global_expectancy_r":global_stats["expectancy_r"],
            "global_pf":global_stats["pf"],
            "global_governor_risk_mult":self.global_risk_multiplier(),
            "weak_asset_sides":weak_sides,
            "missed_positive":missed,"pending_counterfactuals":len(self.pending_counterfactuals),
            "last_note":self.last_note,
        }
