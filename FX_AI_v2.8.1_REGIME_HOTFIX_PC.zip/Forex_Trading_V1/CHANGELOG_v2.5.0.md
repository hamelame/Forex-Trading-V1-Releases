# FX // AI v2.5.0 — Trade Quality / Adaptive Learning

Latest 395-trade run: -$123.85, 147 wins / 248 losses, average -0.57R.
Stop Loss exits were the dominant leak: 248 trades / -$189.56 versus
126 Take Profits / +$67.71.

- FastGuard learns symbol + direction + regime after 4 recent samples.
- Clearly weak recent contexts are penalized early and can be temporarily suppressed.
- Two consecutive stop-losses trigger an adaptive per-symbol cooldown.
- Further consecutive losses extend the cooldown.
- Global entry pacing reduces rapid recycled-entry bursts.
- Existing SymbolGuard, Deep Recovery, liveness watchdogs and realistic execution remain.
