# Test V2.2.2

1. Extract V2.2.2.
2. Run PUBLISH_RELEASE.bat.
3. Open V2.2.1 -> Settings -> CHECK FOR UPDATES.
4. Install V2.2.2.
5. Test REFRESH from Command Center, Markets, Open Positions, Decision Feed, Performance Lab, Shadow Lab and Data Quality.
6. Change Paper Trading Capital, Save & Apply and test both YES and NO.
7. Switch AUTO TOP 10 -> AUTO TOP 5 and confirm the shortlist updates immediately.
8. Open paper trades and confirm Command Center shows UNREALIZED P/L.
9. Confirm Market Watch shows active positions first with Open P/L.

This build remains PAPER + SYNTHETIC only.
