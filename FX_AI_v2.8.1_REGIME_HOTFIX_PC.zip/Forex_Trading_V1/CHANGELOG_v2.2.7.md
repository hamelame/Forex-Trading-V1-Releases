# FX // AI v2.2.7 — Intelligence UI & Diversity Update

- Modernized Markets scanner with labeled search/filter controls, live scanner summary and cleaner neutral rows.
- Upgraded AI Decision Feed cards with larger explanations and visual AI edge/confidence bars.
- Rebuilt Trade Log as an AI Trade Journal with six live KPIs, filters and improved readability.
- Improved Data Quality with an explanatory feed-status strip and clearer layout.
- Shadow Lab KPI cards remain live and now benefit from selector diversity.
- Added automatic underlying-diversity filtering so the AI will not fill multiple shortlist slots with the same metal/crypto underlying quoted in different currencies.
- Removed duplicate Enabled Market Classes controls from Settings; Shadow Lab is now the single source of truth.
- Manual refresh paths remain wired to hard refresh visible data and invalidate table caches.
- Version bumped to 2.2.7.
