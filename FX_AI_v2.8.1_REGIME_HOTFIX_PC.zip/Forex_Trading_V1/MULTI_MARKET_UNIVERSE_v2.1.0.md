# V2.1 Multi-Market Universe

Total: **140 synthetic research instruments**.

- FOREX: 72
- METALS: 8
- ENERGY: 8
- INDICES: 20
- CRYPTO: 32

The Markets workspace is the full universe. Command Center deliberately shows only the highest-ranked opportunities so it stays readable.

All V2.1 prices are synthetic research data. Symbols are product-level research identifiers and are not a promise that a future broker will use identical ticker names.
