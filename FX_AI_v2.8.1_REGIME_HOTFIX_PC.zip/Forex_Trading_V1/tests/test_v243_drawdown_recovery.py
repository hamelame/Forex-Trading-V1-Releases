import json
from forex_app.risk import RiskEngine

class D:
    action="BUY"; symbol="EURUSD"
class S:
    spread_pips=0.5

def cfg():
    c=json.loads(open("config.json").read())
    c["enabled_asset_classes"]=["FOREX"]
    c["max_category_positions"]=5
    c["daily_loss_limit_pct"]=20
    c["weekly_loss_limit_pct"]=20
    c["max_drawdown_pct"]=6
    c["drawdown_recovery_cooldown_scans"]=3
    c["drawdown_recovery_risk_multiplier"]=0.25
    return c

def test_high_water_breaker_recovers_instead_of_deadlocking():
    r=RiskEngine(cfg()); r.reset_session(1000)
    ok,_=r._high_water_gate(1140,1); assert ok
    ok,msg=r._high_water_gate(1065,2); assert not ok and "recovery in 3 scans" in msg
    ok,msg=r._high_water_gate(1065,3); assert not ok and "cooldown" in msg.lower()
    ok,msg=r._high_water_gate(1065,5); assert ok
    assert r.recovery_state(5)[0]=="RECOVERY"
    assert r.recovery_risk_multiplier()==0.25
    assert abs(r.high_water_balance-1065)<1e-9

def test_daily_loss_breaker_stays_hard():
    c=cfg(); c["daily_loss_limit_pct"]=2
    r=RiskEngine(c); r.reset_session(1000)
    ok,msg=r.gate(970,[],D(),S(),1000)
    assert not ok and "Daily loss circuit breaker" in msg


def test_profitable_recovery_trade_returns_to_normal():
    r=RiskEngine(cfg()); r.reset_session(1000)
    r.drawdown_recovery_active=True
    assert r.recovery_state(10)[0]=="RECOVERY"
    r.on_trade_closed(1.0,10)
    assert r.recovery_state(10)[0]=="NORMAL"
