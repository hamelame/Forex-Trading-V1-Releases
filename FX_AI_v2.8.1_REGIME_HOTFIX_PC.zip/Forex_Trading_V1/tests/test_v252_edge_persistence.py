import json
from pathlib import Path
from forex_app import __version__
from forex_app.database import Database
from forex_app.self_learning import SelfLearningEngine

def cfg():
    return json.loads(Path("config.json").read_text())

def test_version_252():
    c=cfg()
    assert __version__=="2.6.0" and c["version"]=="2.6.0"

def test_payoff_floor_is_asymmetric():
    c=cfg()
    assert c["minimum_planned_rr"]>=1.65
    assert c["trend_minimum_planned_rr"]>=1.80
    assert c["weak_regime_minimum_planned_rr"]>=1.90
    assert c["proven_minimum_planned_rr"]>=1.50

def test_range_and_reversal_bootstrap_are_small(tmp_path):
    c=cfg(); l=SelfLearningEngine(c,Database(str(tmp_path/"x.db")))
    rev=l.expectancy_governor("EURUSD","REVERSAL","BUY","London")
    rng=l.expectancy_governor("EURUSD","RANGE","BUY","London")
    tr=l.expectancy_governor("EURUSD","TREND","BUY","London")
    assert rev["risk_mult"]<=0.08
    assert rng["risk_mult"]<=0.10
    assert tr["risk_mult"]>=rev["risk_mult"]
    assert tr["risk_mult"]>=rng["risk_mult"]

def test_negative_global_risk_is_stricter():
    c=cfg()
    assert c["governor_global_negative_risk_mult"]<=0.28
    assert c["governor_min_pf"]>=1.10
    assert c["governor_min_expectancy_r"]>=0.05
