import json
from pathlib import Path

from forex_app import __version__
from forex_app.risk import RiskEngine
from forex_app.models import Decision, MarketSnapshot
from forex_app.database import Database
from forex_app.self_learning import SelfLearningEngine

def cfg():
    c=json.loads(Path("config.json").read_text(encoding="utf-8"))
    c.update({
        "starting_balance":1000.0,
        "paper_trading_capital":1000.0,
        "daily_loss_limit_pct":2.0,
        "weekly_loss_limit_pct":4.0,
        "max_drawdown_pct":50.0,
        "deep_session_loss_pct":10.0,
        "deep_recovery_cooldown_scans":5,
        "deep_recovery_risk_multiplier":0.10,
        "deep_recovery_exit_loss_pct":7.5,
        "catastrophic_session_loss_pct":20.0,
        "catastrophic_drawdown_pct":20.0,
        "max_total_risk_pct":10.0,
        "risk_per_trade_pct":0.4,
        "enabled_asset_classes":["FOREX","CRYPTO"],
        "max_category_positions":5,
    })
    return c

class Snap:
    symbol="EURUSD"
    spread_pips=0.5

def d():
    return Decision("EURUSD","BUY",80,80,"",10,15,"now")

def test_version_249():
    assert __version__=="2.6.0"
    assert cfg()["version"]=="2.6.0"

def test_overnight_10pct_loss_enters_deep_recovery_not_emergency():
    c=cfg()
    r=RiskEngine(c)
    r.reset_session(1000.0)

    # Mirrors the observed v2.4.8 stop near $899.71.
    balance=899.7079811683376
    assert r.update_loss_limit_state(balance,100)=="DEEP_COOLDOWN"
    assert r.recovery_state(100)==("COOLDOWN",5)

    for scan in range(101,105):
        assert r.update_loss_limit_state(balance,scan)=="DEEP_COOLDOWN"

    assert r.update_loss_limit_state(balance,105)=="DEEP_RECOVERY"
    assert r.recovery_state(105)[0]=="RECOVERY"
    assert abs(r.recovery_risk_multiplier()-0.10)<1e-9

    ok,why=r.gate(balance,[],d(),Snap(),105)
    assert ok, why
    assert "RECOVERY" in why.upper()

def test_deep_recovery_does_not_retrigger_same_10pct_breach():
    c=cfg()
    r=RiskEngine(c); r.reset_session(1000)
    balance=899.7
    r.update_loss_limit_state(balance,1)
    for scan in range(2,7):
        r.update_loss_limit_state(balance,scan)
    assert r.limit_mode=="DEEP_RECOVERY"

    for scan in range(7,30):
        assert r.update_loss_limit_state(balance,scan)=="DEEP_RECOVERY"
        assert r.limit_mode=="DEEP_RECOVERY"

def test_deep_recovery_exits_after_material_recovery():
    c=cfg()
    r=RiskEngine(c); r.reset_session(1000)
    r.update_loss_limit_state(899.7,1)
    for scan in range(2,7):
        r.update_loss_limit_state(899.7,scan)
    assert r.limit_mode=="DEEP_RECOVERY"

    # 7% session loss is better than the configured 7.5% exit threshold.
    assert r.update_loss_limit_state(930.0,7)=="NORMAL"
    assert r.recovery_state(7)[0]=="NORMAL"

def test_only_catastrophic_20pct_session_loss_hard_stops():
    c=cfg()
    r=RiskEngine(c); r.reset_session(1000)
    assert r.update_loss_limit_state(799.0,10)=="EMERGENCY"
    ok,why=r.gate(799.0,[],d(),Snap(),10)
    assert not ok
    assert "Catastrophic" in why

def _experience(i,symbol="PEPEUSD",side="BUY",r=-0.6):
    return {
        "trade_id":f"t{i}","ts":f"2026-08-22T00:{i:02d}:00+00:00",
        "symbol":symbol,"asset_class":"CRYPTO","regime":"TREND",
        "session":"Asia","side":side,"context_key":"CRYPTO|TREND|BUY|Asia",
        "score":78,"confidence":75,"spread":0.7,"rsi":50,"atr":3,
        "trend":60,"meanrev":0,"breakout":30,"consensus":100,
        "pnl":r,"r_multiple":r,"mfe_r":0.2,"mae_r":r,
        "bars_open":20,"exit_reason":"Stop Loss",
    }

def test_symbol_guard_suppresses_repeated_bad_symbol_direction(tmp_path):
    c=cfg()
    c.update({
        "learning_symbol_recent_window":12,
        "learning_symbol_min_samples":6,
        "learning_symbol_block_samples":10,
        "learning_symbol_block_expectancy_r":-0.30,
        "learning_symbol_block_pf":0.65,
    })
    db=Database(str(tmp_path/"learn.db"))
    for i in range(10):
        db.learning_experience(_experience(i))
    learn=SelfLearningEngine(c,db)

    snap=MarketSnapshot(
        "PEPEUSD",0.00001,0.000011,0.7,50,0.0000105,0.0000100,
        3.0,0.5,"Asia","now",99
    )
    dec=Decision(
        "PEPEUSD","BUY",80,78,
        "CRYPTO / TREND | Trend +60 · MeanRev +0 · Breakout +30 | consensus 100%",
        10,15,"now"
    )
    adjusted=learn.adjust_decision(dec,snap,"TREND")
    assert adjusted.action=="WAIT"
    assert "SymbolGuard" in adjusted.reason
    assert "temporarily suppressed" in adjusted.reason

def test_symbol_guard_clips_historic_execution_outlier(tmp_path):
    c=cfg()
    db=Database(str(tmp_path/"clip.db"))
    # One historic broken -37R print plus several normal wins/losses must not
    # make symbol stats infinitely bad.
    vals=[-37.0,0.8,0.8,0.8,-1.0,-1.0,0.8,0.8]
    for i,rval in enumerate(vals):
        db.learning_experience(_experience(i,symbol="EURHUF",r=rval))
    learn=SelfLearningEngine(c,db)
    st=learn.symbol_stats_for("EURHUF","BUY")
    assert st is not None
    assert st["expectancy_r"]>-1.0
