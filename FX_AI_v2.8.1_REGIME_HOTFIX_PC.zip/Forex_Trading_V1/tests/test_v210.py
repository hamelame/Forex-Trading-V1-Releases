import json, unittest
from pathlib import Path
from forex_app.instruments import universe_counts, instrument_meta

class V210Tests(unittest.TestCase):
    def test_universe_140(self):
        cfg=json.loads(Path("config.json").read_text())
        self.assertEqual(cfg["version"],"2.4.1")
        self.assertEqual(len(cfg["symbols"]),140)
        self.assertEqual(universe_counts(cfg["symbols"]),{"FOREX":72,"METALS":8,"ENERGY":8,"INDICES":20,"CRYPTO":32,"OTHER":0})
        for s in ["EURUSD","XAUUSD","WTIUSD","US100","BTCUSD"]: self.assertIn(s,cfg["symbols"])

    def test_single_champion_multimarket(self):
        src=Path("forex_app/engine.py").read_text()
        self.assertIn("MultiMarketResearchBrain",src)
        self.assertIn("self.challengers=[]",src)
        self.assertIn("build_currency_strength",src)

    def test_profiles_and_settings(self):
        cfg=json.loads(Path("config.json").read_text())
        self.assertEqual(cfg["trading_profile"],"AI TRADING")
        src=Path("forex_app/ui.py").read_text()
        for token in ["AI TRADING","MANUAL","ENABLED MARKET CLASSES","Minimum specialist consensus","Weekly research loss limit","Market-Class Risk Multipliers"]:
            self.assertIn(token,src)

    def test_market_categories(self):
        self.assertEqual(instrument_meta("XAUUSD")["asset_class"],"METALS")
        self.assertEqual(instrument_meta("US100")["asset_class"],"INDICES")
        self.assertEqual(instrument_meta("BTCUSD")["asset_class"],"CRYPTO")

    def test_start_stop_labels(self):
        src=Path("forex_app/ui.py").read_text()
        self.assertIn("STOPP!",src); self.assertIn("START AI",src); self.assertIn("AI TRADING ACTIVE",src)

if __name__=="__main__": unittest.main()
