import json
from pathlib import Path

from forex_app import __version__
from forex_app.database import Database
from forex_app.self_learning import SelfLearningEngine
from forex_app.models import MarketSnapshot, Decision

def cfg():
    return json.loads(Path("config.json").read_text(encoding="utf-8"))

def experience(i, symbol="EURUSD", asset="FOREX", regime="TREND", side="BUY",
               session="London", r=0.7):
    return {
        "trade_id":f"g{i}-{symbol}","ts":f"2026-08-23T{i%24:02d}:{i%60:02d}:00+00:00",
        "symbol":symbol,"asset_class":asset,"regime":regime,"session":session,
        "side":side,"context_key":f"{asset}|{regime}|{side}|{session}",
        "score":80,"confidence":78,"spread":0.8,"rsi":50,"atr":8,
        "trend":60,"meanrev":0,"breakout":30,"consensus":100,
        "pnl":r,"r_multiple":r,"mfe_r":max(r,0),"mae_r":min(r,0),
        "bars_open":12,"exit_reason":"Take Profit" if r>0 else "Stop Loss",
    }

def test_version_251():
    assert __version__=="2.6.0"
    assert cfg()["version"]=="2.6.0"

def test_unknown_forex_reversal_bootstraps_at_tiny_risk(tmp_path):
    c=cfg()
    l=SelfLearningEngine(c,Database(str(tmp_path/"empty.db")))
    g=l.expectancy_governor("EURUSD","REVERSAL","BUY","London")
    assert g["allow"]
    assert g["state"]=="BOOTSTRAP"
    assert g["risk_mult"]<=0.10

def test_proven_positive_context_can_earn_full_governor_risk(tmp_path):
    c=cfg()
    db=Database(str(tmp_path/"proven.db"))
    for i in range(22):
        db.learning_experience(experience(i,r=0.7))
    l=SelfLearningEngine(c,db)
    g=l.expectancy_governor("EURUSD","TREND","BUY","London")
    assert g["allow"], g
    assert g["state"]=="PROVEN", g
    assert g["risk_mult"]==1.0

def test_negative_broad_forex_reversal_moves_to_research_only(tmp_path):
    c=cfg()
    db=Database(str(tmp_path/"badrev.db"))
    symbols=["EURUSD","GBPUSD","USDJPY","EURJPY","AUDUSD"]
    for i in range(35):
        db.learning_experience(experience(
            i,symbol=symbols[i%len(symbols)],regime="REVERSAL",
            side="BUY",session="Asia",r=-0.8
        ))
    l=SelfLearningEngine(c,db)
    g=l.expectancy_governor("NZDUSD","REVERSAL","BUY","Asia")
    assert not g["allow"], g
    assert g["state"]=="RESEARCH-ONLY"
    assert g["risk_mult"]==0.0
    assert "FOREX/REVERSAL" in g["reason"]

def test_governor_turns_champion_buy_into_research_wait(tmp_path):
    c=cfg()
    db=Database(str(tmp_path/"wait.db"))
    for i in range(35):
        db.learning_experience(experience(
            i,symbol="EURTRY",regime="REVERSAL",side="BUY",session="Asia",r=-0.9
        ))
    l=SelfLearningEngine(c,db)
    snap=MarketSnapshot("EURTRY",48.0,48.01,0.8,50,48.1,48.0,8,0.5,"Asia","now",99)
    d=Decision("EURTRY","BUY",82,80,
               "FOREX / REVERSAL | Trend +10 · MeanRev +70 · Breakout +0 | consensus 100%",
               10,13,"now")
    a=l.adjust_decision(d,snap,"REVERSAL")
    assert a.action=="WAIT"
    assert "GOVERNOR RESEARCH-ONLY" in a.reason

def test_global_negative_expectancy_reduces_risk_not_research_loop(tmp_path):
    c=cfg()
    db=Database(str(tmp_path/"global.db"))
    for i in range(20):
        db.learning_experience(experience(i,r=-0.6))
    l=SelfLearningEngine(c,db)
    st=l.global_expectancy_stats()
    assert st["expectancy_r"]<0
    assert l.global_risk_multiplier()==c["governor_global_severe_risk_mult"]

def test_neutral_bootstrap_global_risk_is_reduced(tmp_path):
    c=cfg()
    l=SelfLearningEngine(c,Database(str(tmp_path/"bootstrap.db")))
    assert l.global_risk_multiplier()==c["governor_global_bootstrap_risk_mult"]
