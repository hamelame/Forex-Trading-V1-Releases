import json, os, random
from pathlib import Path

from forex_app.database import Database
from forex_app.market import SyntheticFeed
from forex_app.engine import TradingEngine
from forex_app.risk import RiskEngine
from forex_app.models import Decision, Position
from forex_app.self_learning import SelfLearningEngine
from forex_app.instruments import underlying_key

def cfg():
    return json.loads(Path("config.json").read_text(encoding="utf-8"))

def test_version_240():
    assert cfg()["version"]=="2.4.1"

def test_strict_underlying_identity():
    assert underlying_key("XAUUSD")==underlying_key("XAUEUR")==underlying_key("XAUGBP")
    assert underlying_key("XAGUSD")==underlying_key("XAGEUR")==underlying_key("XAGGBP")
    assert underlying_key("XAUUSD")!=underlying_key("XAGUSD")

def test_selector_never_selects_duplicate_gold_quote_variants():
    c=cfg()
    path=Path("data/_v240_diversity.db")
    if path.exists(): path.unlink()
    db=Database(str(path))
    random.seed(31)
    eng=TradingEngine(c,SyntheticFeed(c["symbols"]),db)
    for _ in range(5):
        eng.refresh_market_state(force_reselect=True)
    chosen=eng.selector.shortlist
    keys=[underlying_key(x) for x in chosen]
    assert len(keys)==len(set(keys))

def test_risk_blocks_same_underlying_open_via_other_quote():
    c=cfg()
    r=RiskEngine(c)
    r.reset_session(10000)
    pos=Position("x","XAUUSD","BUY",.1,2350,2340,2370,20,"now")
    class S:
        symbol="XAUEUR"; spread_pips=.7
    d=Decision("XAUEUR","BUY",80,80,"",10,15,"now")
    ok,why=r.gate(10000,[pos],d,S(),scan_count=1)
    assert not ok
    assert "Underlying exposure" in why

def test_loss_streak_cooldown_then_reduced_risk_recovery():
    c=cfg()
    c["max_consecutive_losses"]=3
    c["loss_recovery_cooldown_scans"]=5
    r=RiskEngine(c); r.reset_session(10000)
    r.on_trade_closed(-10,1); r.on_trade_closed(-10,2); r.on_trade_closed(-10,3)
    state,remaining=r.recovery_state(3)
    assert state=="COOLDOWN" and remaining==5
    state,remaining=r.recovery_state(8)
    assert state=="RECOVERY"
    assert r.recovery_risk_multiplier()<1
    r.on_trade_closed(5,9)
    assert r.recovery_state(9)[0]=="NORMAL"

def test_learning_requires_promotion_gate_for_positive_boost():
    c=cfg()
    c["learning_min_samples"]=4
    c["learning_promotion_samples"]=6
    c["learning_min_expectancy_r"]=.05
    c["learning_min_profit_factor"]=1.1
    path=Path("data/_v240_learning.db")
    if path.exists(): path.unlink()
    db=Database(str(path))
    learn=SelfLearningEngine(c,db)
    for i in range(6):
        db.learning_experience({
            "trade_id":str(i),"ts":str(i),"symbol":"EURUSD","asset_class":"FOREX",
            "regime":"TREND","session":"London","side":"BUY",
            "context_key":"FOREX|TREND|BUY|London","score":75,"confidence":70,
            "spread":.7,"rsi":55,"atr":10,"trend":50,"meanrev":0,"breakout":35,
            "consensus":100,"pnl":10,"r_multiple":.5,"mfe_r":.8,"mae_r":-.2,
            "bars_open":20,"exit_reason":"TP"
        })
    st=learn.stats_for("EURUSD","TREND","BUY","London")
    assert st["status"]=="PROMOTED"
    class S:
        symbol="EURUSD"; session="London"
    d=Decision("EURUSD","BUY",70,70,"FOREX / TREND | Trend +50 | consensus 100%",10,15,"now")
    adj=learn.adjust_decision(d,S(),"TREND")
    assert adj.score>=d.score
    assert "Learning PROMOTED" in adj.reason

def test_counterfactual_resolves_after_horizon():
    c=cfg(); c["counterfactual_horizon_scans"]=2
    path=Path("data/_v240_cf.db")
    if path.exists(): path.unlink()
    db=Database(str(path))
    learn=SelfLearningEngine(c,db)
    class S:
        symbol="EURUSD"; mid=1.1000; session="London"
    d=Decision("EURUSD","BUY",75,70,"",10,15,"now")
    learn.observe_blocked(d,S(),"TREND","Exposure gate",1)
    class S2:
        symbol="EURUSD"; mid=1.1010; session="London"
    learn.resolve_counterfactuals({"EURUSD":S2()},3)
    assert len(db.counterfactuals())==1

def test_engine_records_learning_experience_on_close():
    c=cfg(); random.seed(5)
    path=Path("data/_v240_engine_learning.db")
    if path.exists(): path.unlink()
    db=Database(str(path))
    eng=TradingEngine(c,SyntheticFeed(c["symbols"]),db)
    eng.enabled=True
    # Run enough scans to make at least one close in the synthetic test feed.
    for _ in range(100):
        eng.scan()
        if db.learning_experiences():
            break
    assert db.learning_experiences()

def test_reset_does_not_erase_research_memory():
    c=cfg()
    path=Path("data/_v240_memory.db")
    if path.exists(): path.unlink()
    db=Database(str(path))
    db.learning_experience({
        "trade_id":"old","ts":"old","symbol":"EURUSD","asset_class":"FOREX","regime":"TREND",
        "session":"London","side":"BUY","context_key":"FOREX|TREND|BUY|London",
        "score":70,"confidence":70,"spread":.7,"rsi":50,"atr":10,"trend":20,
        "meanrev":0,"breakout":20,"consensus":100,"pnl":1,"r_multiple":.1,
        "mfe_r":.2,"mae_r":-.1,"bars_open":10,"exit_reason":"x"
    })
    eng=TradingEngine(c,SyntheticFeed(c["symbols"]),db)
    eng.reset_paper_session(10000)
    assert len(db.learning_experiences())==1
