import json
from pathlib import Path
from forex_app import __version__

def test_version_241():
    cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
    assert cfg["version"]=="2.4.1"
    assert __version__=="2.4.1"

def test_command_center_only_two_realized_boxes():
    src=Path("forex_app/ui.py").read_text(encoding="utf-8")
    dashboard=src[src.index("def _dashboard"):src.index("def _markets")]
    assert '("REALIZED WIN","Closed winning trades only")' in dashboard
    assert '("REALIZED LOSS","Closed losing trades only")' in dashboard
    assert '("NET REALIZED P/L","Profit minus losses")' not in dashboard
    assert '("REALIZED PROFIT","Closed winning trades only")' not in dashboard

def test_unrealized_and_total_remain_distinct_session_metrics():
    src=Path("forex_app/ui.py").read_text(encoding="utf-8")
    dashboard=src[src.index("def _dashboard"):src.index("def _markets")]
    assert '("UNREALIZED P/L","Open positions right now")' in dashboard
    assert '("TOTAL SESSION P/L","Net realized + unrealized")' in dashboard

def test_stop_button_replaces_pause_button():
    src=Path("forex_app/ui.py").read_text(encoding="utf-8")
    assert '"●  STOPP!"' in src
    render=src[src.index("def _render_engine_button"):src.index("def _pages")]
    assert '"PAUSE AI"' not in render
    assert '"START AI"' in render

def test_hd_heartbeat_has_structured_cells():
    src=Path("forex_app/ui.py").read_text(encoding="utf-8")
    dashboard=src[src.index("def _dashboard"):src.index("def _markets")]
    for label in (
        "SCAN","ELIGIBLE","SELECTED","TRADE-READY","OPEN POSITIONS",
        "REALIZED WIN","REALIZED LOSS","NET REALIZED","UNREALIZED","TOTAL SESSION",
        "SELF LEARNING","AI CHALLENGERS","RISK ENGINE","COUNTERFACTUALS",
        "BLOCKED TRADES","LAST ENGINE EVENT"
    ):
        assert label in dashboard
    assert "self.hb_cells={}" in dashboard
    assert "self.hb_value_labels={}" in dashboard
