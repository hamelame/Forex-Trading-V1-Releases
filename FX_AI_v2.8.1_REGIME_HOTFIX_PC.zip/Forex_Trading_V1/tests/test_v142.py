import json, unittest
from pathlib import Path
from forex_app.release_channel import get_release_channel

class V142Tests(unittest.TestCase):
    def test_version(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["version"],"2.4.1")
        self.assertEqual(cfg["chart_mode"],"LOCKED")

    def test_manual_only_chart_contract(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertNotIn('"<<TreeviewSelect>>"',src)
        self.assertIn('"<ButtonRelease-1>"',src)
        self.assertIn("Selection Engine shortlist",src)
        self.assertNotIn("def toggle_chart_mode",src)

    def test_release_channel_support(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("ACTIVATE",src)
        self.assertIn("CHECK FOR UPDATES",src)
        self.assertIn("save_github_channel",src)

if __name__=="__main__":
    unittest.main()
