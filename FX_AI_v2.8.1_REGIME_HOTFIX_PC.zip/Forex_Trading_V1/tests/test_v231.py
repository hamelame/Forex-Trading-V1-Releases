import json
from pathlib import Path
from forex_app.database import Database
from forex_app.market import SyntheticFeed
from forex_app.engine import TradingEngine

def test_version_231():
    cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
    assert cfg["version"]=="2.4.1"

def test_new_session_is_clean():
    cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
    db=Database("data/_v231_reset.db")
    eng=TradingEngine(cfg,SyntheticFeed(cfg["symbols"]),db)
    eng.balance=12345; eng.equity=12000; eng.scan_count=77
    eng.risk.high_water_balance=15000
    eng.reset_paper_session(10000)
    assert eng.balance==10000
    assert eng.equity==10000
    assert eng.scan_count==0
    assert eng.risk.high_water_balance==10000
    assert eng.performance()["pnl"]==0

def test_session_scoped_decisions_and_trades_helpers_exist():
    src=Path("forex_app/database.py").read_text(encoding="utf-8")
    assert "def recent_decisions_since" in src
    ui=Path("forex_app/ui.py").read_text(encoding="utf-8")
    assert "THIS SESSION" in ui
    assert "ALL HISTORY" in ui
    assert "REALIZED WIN" in ui
    assert "REALIZED LOSS" in ui
    assert "NET REALIZED P/L" in ui
