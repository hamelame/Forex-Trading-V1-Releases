import json, unittest
from pathlib import Path
from forex_app.market import SyntheticFeed

class V143Tests(unittest.TestCase):
    def test_version(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["version"],"2.4.1")

    def test_snapshot_does_not_advance_whole_market(self):
        f=SyntheticFeed(["EURUSD","GBPUSD"])
        before=len(f.history["GBPUSD"])
        f.snapshot("EURUSD")
        after=len(f.history["GBPUSD"])
        self.assertEqual(before,after)
        f.advance()
        self.assertEqual(len(f.history["GBPUSD"]), min(before+1, f.history["GBPUSD"].maxlen))

    def test_chart_symbol_is_isolated(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("self.chart_symbol",src)
        block=src[src.index("    def _refresh_chart"):src.index("    def _markets",src.index("    def _refresh_chart"))]
        self.assertNotIn("top[0]",block.split("if self.chart_symbol is None:",1)[-1].split("sym=self.chart_symbol",1)[-1])
        self.assertIn("sym=self.chart_symbol",block)

    def test_user_click_is_only_runtime_chart_setter(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("def _set_chart_from_user_click",src)
        self.assertNotIn("<<TreeviewSelect>>",src)

if __name__=="__main__":
    unittest.main()
