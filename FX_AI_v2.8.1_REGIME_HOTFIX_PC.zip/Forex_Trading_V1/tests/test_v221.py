import json, unittest
from pathlib import Path
from forex_app.database import Database
from forex_app.market import SyntheticFeed
from forex_app.engine import TradingEngine

class V221Tests(unittest.TestCase):
    def test_version_capital_and_universe(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["version"],"2.4.1")
        self.assertEqual(len(cfg["symbols"]),140)
        self.assertEqual(cfg["paper_trading_capital"],20000.0)

    def test_fresh_session_zeroes_visible_state(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        db=Database("data/_v221_unit.db")
        eng=TradingEngine(cfg,SyntheticFeed(cfg["symbols"]),db)
        self.assertEqual(eng.balance,cfg["paper_trading_capital"])
        self.assertEqual(eng.equity,cfg["paper_trading_capital"])
        self.assertEqual(len(eng.positions),0)
        self.assertEqual(eng.performance()["pnl"],0)

    def test_restart_resets_session(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        db=Database("data/_v221_restart.db")
        eng=TradingEngine(cfg,SyntheticFeed(cfg["symbols"]),db)
        eng.balance=12345
        eng.equity=12000
        eng.set_enabled(False)
        eng.set_enabled(True,reset_on_start=True)
        self.assertEqual(eng.balance,cfg["paper_trading_capital"])
        self.assertEqual(eng.equity,cfg["paper_trading_capital"])
        self.assertEqual(len(eng.positions),0)

    def test_paper_capital_range_ui(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("Paper trading capital USD",src)
        self.assertIn("100000",src)
        self.assertIn("1000",src)

    def test_modern_controls_and_pinned_updater(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("class TogglePill",src)
        self.assertIn("class SegmentedPills",src)
        self.assertIn("Update Center",src)
        self.assertEqual(src.count("CHECK FOR UPDATES"),1)

    def test_multimarket_architecture_preserved(self):
        src=Path("forex_app/engine.py").read_text(encoding="utf-8")
        self.assertIn("MultiMarketResearchBrain",src)
        self.assertIn("OpportunitySelector",src)

if __name__=="__main__":
    unittest.main()
