import json, unittest
from pathlib import Path
from datetime import datetime, timezone
from forex_app.database import Database
from forex_app.market import SyntheticFeed
from forex_app.engine import TradingEngine
from forex_app.models import Position

class V225RefreshPauseTests(unittest.TestCase):
    def setUp(self):
        self.cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))

    def test_market_refresh_works_while_paused_without_entries(self):
        db=Database("data/_v225_refresh.db")
        eng=TradingEngine(self.cfg,SyntheticFeed(self.cfg["symbols"]),db)
        self.assertFalse(eng.enabled)
        eng.refresh_market_state(force_reselect=True)
        self.assertGreater(len(eng.snapshots),0)
        self.assertGreaterEqual(eng.selector.stats["scanned"],1)
        self.assertEqual(len(eng.positions),0)

    def test_close_all_helper(self):
        db=Database("data/_v225_close.db")
        eng=TradingEngine(self.cfg,SyntheticFeed(self.cfg["symbols"]),db)
        eng.refresh_market_state(force_reselect=True)
        sym="EURUSD"; s=eng.snapshots[sym]
        eng.positions=[Position("x",sym,"BUY",0.1,s.mid,s.mid-1,s.mid+2,20,datetime.now(timezone.utc).isoformat(),"test",0,1,70)]
        db.save_positions(eng.positions)
        n=eng.close_all_positions()
        self.assertEqual(n,1)
        self.assertEqual(len(eng.positions),0)

    def test_ui_has_pause_choices_and_shadow_refresh(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("CLOSE ALL POSITIONS",src)
        self.assertIn("KEEP POSITIONS",src)
        self.assertIn("def refresh_shadow_market",src)
        self.assertIn("ELIGIBLE MARKET CANDIDATES",src)
        self.assertIn("AI SELECTED",src)
        self.assertIn("refresh_market_state(force_reselect=False)",src)

    def test_combobox_is_dark_yellow(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("*TCombobox*Listbox.background",src)
        self.assertIn("*TCombobox*Listbox.foreground",src)

if __name__=="__main__":
    unittest.main()
