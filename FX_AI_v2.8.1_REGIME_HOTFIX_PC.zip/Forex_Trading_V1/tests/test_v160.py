import json, tempfile, unittest
from pathlib import Path
from forex_app.database import Database
from forex_app.models import Position

class V160Tests(unittest.TestCase):
    def test_version(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["version"],"2.4.1")
        self.assertGreaterEqual(cfg["ui_rerank_seconds"],10)

    def test_stable_ui_contract(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("def _ui_tick",src)
        self.assertIn("_stable_market_order",src)
        self.assertIn("decision_feed_refresh_seconds",src)
        self.assertIn('width=58,anchor="e"',src)

    def test_modern_market_tools(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("market_search_var",src)
        self.assertIn("market_category_var",src)
        self.assertIn("candles · live synthetic feed",src)

    def test_position_persistence(self):
        with tempfile.TemporaryDirectory() as td:
            db=Database(str(Path(td)/"t.db"))
            p=Position("x","EURUSD","BUY",.1,1.1,1.0,1.2,100,"now","FX Council",12.3,9,77)
            db.save_positions([p])
            rows=db.load_positions()
            self.assertEqual(len(rows),1)
            self.assertEqual(rows[0]["symbol"],"EURUSD")
            self.assertEqual(rows[0]["bars_open"],9)

    def test_release_publisher_exists(self):
        self.assertTrue(Path("PUBLISH_RELEASE.bat").exists())
        self.assertTrue(Path("tools/publish_release.ps1").exists())

if __name__=="__main__":
    unittest.main()
