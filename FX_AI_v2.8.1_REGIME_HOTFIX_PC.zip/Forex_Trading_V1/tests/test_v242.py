from pathlib import Path
import json
from forex_app import __version__
from forex_app.execution import ExecutionRealism
from forex_app.models import MarketSnapshot

def test_version_242():
    assert __version__ == "2.6.0"
    assert json.loads(Path("config.json").read_text())["version"] == "2.6.0"

def test_command_center_removes_duplicate_top_pl_cards():
    src=Path("forex_app/ui.py").read_text()
    block=src[src.index("def _dashboard"):src.index("heartbeat=tk.Frame",src.index("def _dashboard"))]
    assert '("REALIZED WIN","Closed winning trades only")' not in block
    assert '("REALIZED LOSS","Closed losing trades only")' not in block
    assert '("UNREALIZED P/L","Open positions right now")' not in block
    assert '("TOTAL SESSION P/L","Net realized + unrealized")' in block

def test_status_is_green():
    src=Path("forex_app/ui.py").read_text()
    assert 'rf,textvariable=self.status,bg=BG,fg=GREEN' in src

def test_realistic_fill_is_adverse_and_costed():
    cfg=json.loads(Path("config.json").read_text())
    ex=ExecutionRealism(cfg)
    s=MarketSnapshot("EURUSD",1.1000,1.1001,1.0,50,1,1,8,0,"London","x",98)
    f=ex.fill("BUY",s,1.0,12345)
    if f.filled:
        assert f.price >= s.ask
        assert f.entry_commission > 0
        assert f.latency_ms >= cfg["paper_latency_min_ms"]
