import json, unittest
from pathlib import Path
class V170Tests(unittest.TestCase):
    def test_version(self):
        cfg=json.loads(Path('config.json').read_text(encoding='utf-8'))
        self.assertEqual(cfg['version'],'2.4.1')
    def test_reference_ui(self):
        src=Path('forex_app/ui.py').read_text(encoding='utf-8')
        for token in ['REALIZED P/L','MARKET WATCH','MARKET INTELLIGENCE','RISK MODE','AUTO-UPDATE','HeatRing','MiniSpark']:
            self.assertIn(token,src)
    def test_fixed_publisher(self):
        src=Path('tools/publish_release.ps1').read_text(encoding='utf-8')
        self.assertIn('gh release list',src)
        self.assertIn('gh release create',src)
        self.assertNotIn('gh release view',src)
if __name__=='__main__':unittest.main()
