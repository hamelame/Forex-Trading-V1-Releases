import json, time
from pathlib import Path
from forex_app import __version__
from forex_app.live_market import LiveMarketFeed
from forex_app.neural_edge import NeuralEdgeBrain
from forex_app.database import Database
from forex_app.models import MarketSnapshot, Decision


def test_v270_version_and_mode():
    cfg=json.loads(Path('config.json').read_text())
    assert __version__=='2.7.1'
    assert cfg['version']=='2.7.1'
    assert cfg['market_data_mode']=='LIVE'
    assert cfg['mode']=='PAPER'
    assert cfg['paper_only_build'] is True
    assert cfg['neural_edge_shadow_only'] is True


def test_live_feed_uses_real_candle_payload_without_synthetic_step(monkeypatch):
    cfg={'live_data_refresh_seconds':5,'live_data_stale_seconds':180,'live_data_timeout_seconds':1}
    f=LiveMarketFeed(['EURUSD'],cfg)
    now=time.time()
    vals=[1.10+i*0.00001 for i in range(100)]
    times=[now-(99-i)*60 for i in range(100)]
    monkeypatch.setattr(f,'_fetch_yahoo',lambda symbol:(vals,times,'TEST LIVE 1M'))
    f._refresh_symbol('EURUSD',True)
    s=f.snapshot('EURUSD')
    assert s.feed_status=='LIVE'
    assert s.feed_provider=='TEST LIVE 1M'
    assert abs(s.mid-vals[-1])<1e-9
    assert len(s.price_history)==100


def test_live_feed_rejects_stale_data(monkeypatch):
    f=LiveMarketFeed(['EURUSD'],{'live_data_refresh_seconds':5,'live_data_stale_seconds':30,'live_data_timeout_seconds':1})
    old=time.time()-600
    vals=[1.1+i*.00001 for i in range(50)]; times=[old-(49-i)*60 for i in range(50)]
    monkeypatch.setattr(f,'_fetch_yahoo',lambda symbol:(vals,times,'TEST'))
    f._refresh_symbol('EURUSD',True)
    try:
        f.snapshot('EURUSD')
        assert False,'stale snapshot should fail closed'
    except RuntimeError as e:
        assert 'STALE DATA' in str(e)


def test_live_advance_never_blocks_ui_while_provider_is_slow(monkeypatch):
    f=LiveMarketFeed(['EURUSD','GBPUSD'],{'live_data_workers':4,'live_data_refresh_seconds':5})
    now=time.time()
    def slow_fetch(symbol):
        time.sleep(.20)
        return [1.1+i*.00001 for i in range(50)],[now-(49-i)*60 for i in range(50)],'TEST'
    monkeypatch.setattr(f,'_fetch_yahoo',slow_fetch)
    started=time.perf_counter(); f.advance(); elapsed=time.perf_counter()-started
    assert elapsed < .10
    deadline=time.time()+2
    while time.time()<deadline and not all(f.history[s] for s in f.symbols):
        time.sleep(.02)
    assert all(f.history[s] for s in f.symbols)
    f.close()


def test_neural_shadow_trains_with_validation_holdout_and_persists(tmp_path):
    path=tmp_path/'neural.json'
    n=NeuralEdgeBrain({'neural_edge_learning_rate':0.02},path)
    s=MarketSnapshot('EURUSD',1.1,1.1001,1.0,55,1.1002,1.0998,12,0.4,'London','now',98,(),(), 'LIVE','TEST',1)
    d=Decision('EURUSD','BUY',72,70,'x',10,18,'now')
    pred=n.predict(s,d,'TREND')
    assert 0<pred['win_probability']<1 and pred['mode']=='SHADOW'
    n.observe(pred['features'],1.2,'trade-a')
    assert n.samples==1 and path.exists()
    n2=NeuralEdgeBrain({},path)
    assert n2.samples==1


def test_database_neural_shadow_roundtrip(tmp_path):
    db=Database(str(tmp_path/'x.db'))
    db.neural_shadow_prediction({'trade_id':'t1','ts':'now','symbol':'EURUSD','side':'BUY','regime':'TREND',
        'provider':'TEST','feed_status':'LIVE','data_age_seconds':1,'win_probability':.61,'expected_r':.2,
        'model_confidence':22,'model_samples':10,'features_json':'[1,2]'})
    db.neural_shadow_outcome('t1',1.3,4.2,True)
    r=db.neural_shadow_rows(1)[0]
    assert r['trade_id']=='t1' and abs(r['outcome_r']-1.3)<1e-9 and r['validation_holdout']==1
