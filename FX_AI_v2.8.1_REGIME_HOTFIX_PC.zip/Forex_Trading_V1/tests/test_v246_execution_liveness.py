import json
from pathlib import Path

from forex_app.risk import RiskEngine
from forex_app.models import Decision

class Snap:
    symbol="EURUSD"
    spread_pips=0.5

def decision():
    return Decision("EURUSD","BUY",80,80,"",10,15,"now")

def cfg():
    c=json.loads(Path("config.json").read_text(encoding="utf-8"))
    c["starting_balance"]=1000.0
    c["daily_loss_limit_pct"]=2.0
    c["weekly_loss_limit_pct"]=4.0
    c["limit_recovery_cooldown_scans"]=4
    c["limit_recovery_risk_multiplier"]=0.20
    c["emergency_session_loss_pct"]=10.0
    c["max_drawdown_pct"]=50.0
    c["max_total_risk_pct"]=10.0
    c["risk_per_trade_pct"]=0.4
    c["enabled_asset_classes"]=["FOREX"]
    c["max_category_positions"]=5
    return c

def test_version_246():
    assert json.loads(Path("config.json").read_text(encoding="utf-8"))["version"]=="2.6.0"

def test_daily_loss_is_recoverable_not_permanent():
    r=RiskEngine(cfg()); r.reset_session(1000)
    # -3% used to be a permanent Daily Loss hard block.
    assert r.update_loss_limit_state(970,10)=="COOLDOWN"
    ok,msg=r.gate(970,[],decision(),Snap(),10)
    assert not ok and "cooldown" in msg.lower()

    for scan in (11,12,13):
        assert r.update_loss_limit_state(970,scan)=="COOLDOWN"
    assert r.update_loss_limit_state(970,14)=="RECOVERY"

    ok,msg=r.gate(970,[],decision(),Snap(),14)
    assert ok, msg
    assert r.recovery_risk_multiplier()==0.20

def test_weekly_loss_is_recoverable_not_permanent():
    r=RiskEngine(cfg()); r.reset_session(1000)
    # Make day anchor neutral so weekly limit is the trigger.
    r.day_start_balance=950
    assert r.update_loss_limit_state(955,20)=="COOLDOWN"
    for scan in (21,22,23,24):
        mode=r.update_loss_limit_state(955,scan)
    assert mode=="RECOVERY"
    ok,msg=r.gate(955,[],decision(),Snap(),24)
    assert ok, msg

def test_soft_limit_rebases_without_erasing_session_emergency_anchor():
    r=RiskEngine(cfg()); r.reset_session(1000)
    r.update_loss_limit_state(970,1)
    for scan in range(2,6):
        r.update_loss_limit_state(970,scan)
    assert r.limit_mode=="RECOVERY"
    assert r.day_start_balance==970
    assert r.week_start_balance==970
    assert r.session_start_balance==1000

def test_profitable_recovery_trade_does_not_restore_old_loss_anchor():
    r=RiskEngine(cfg()); r.reset_session(1000)
    r.update_loss_limit_state(970,1)
    for scan in range(2,6):
        r.update_loss_limit_state(970,scan)
    assert r.day_start_balance==970
    r.on_trade_closed(1.0,6)
    assert r.limit_mode=="NORMAL"
    assert r.day_start_balance==970
    assert r.week_start_balance==970

def test_emergency_session_loss_is_still_hard_stop():
    c=cfg(); c["catastrophic_session_loss_pct"]=20
    r=RiskEngine(c); r.reset_session(1000)
    assert r.update_loss_limit_state(795,10)=="EMERGENCY"
    ok,msg=r.gate(795,[],decision(),Snap(),10)
    assert not ok
    assert "Catastrophic" in msg

def test_expired_loss_streak_cooldown_self_heals():
    r=RiskEngine(cfg()); r.reset_session(1000)
    r.recovery_active=True
    r.loss_recovery_until_scan=10
    r.sanitize_recovery_state(11)
    assert r.loss_recovery_until_scan==0
    assert r.recovery_state(11)[0]=="RECOVERY"
