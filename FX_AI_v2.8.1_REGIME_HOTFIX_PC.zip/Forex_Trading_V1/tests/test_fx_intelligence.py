import unittest
from forex_app.intelligence import regime, market_rank, exposure_summary
from forex_app.models import MarketSnapshot, Decision
class FXIntelTests(unittest.TestCase):
    def test_rank_range(self):
        s=MarketSnapshot('EURUSD',1.1,1.1001,1,55,1.101,1.100,12,.4,'London','now',100)
        d=Decision('EURUSD','BUY',70,70,'x',10,16,'now')
        self.assertTrue(0<=market_rank(s,d)<=100)
    def test_no_exposure(self): self.assertIn('No active',exposure_summary([]))
