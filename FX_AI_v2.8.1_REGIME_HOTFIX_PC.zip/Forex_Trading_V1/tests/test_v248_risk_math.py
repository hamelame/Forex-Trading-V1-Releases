import json
from pathlib import Path

from forex_app import __version__
from forex_app.instruments import instrument_meta, forex_pip_value_usd
from forex_app.risk import RiskEngine
from forex_app.models import MarketSnapshot, Decision
from forex_app.database import Database
from forex_app.engine import TradingEngine

def cfg():
    c=json.loads(Path("config.json").read_text(encoding="utf-8"))
    c["starting_balance"]=1000.0
    c["paper_trading_capital"]=1000.0
    c["risk_per_trade_pct"]=0.4
    c["manual_risk_per_trade_pct"]=0.4
    c["category_risk_forex"]=1.0
    c["paper_min_lot"]=0.01
    c["paper_lot_step"]=0.01
    c["min_lot_risk_tolerance"]=1.10
    c["execution_realistic_paper"]=True
    return c

def test_version_248():
    assert __version__=="2.6.0"
    assert cfg()["version"]=="2.6.0"

def test_huf_uses_two_decimal_pip():
    assert instrument_meta("EURHUF")["tick_size"]==0.01
    assert instrument_meta("USDHUF")["tick_size"]==0.01

def test_fx_pip_values_are_quote_currency_aware():
    # USD-quoted major remains about $10/pip/lot.
    assert abs(forex_pip_value_usd("EURUSD",1.16)-10.0)<1e-9
    # HUF quoted pair is far below $10 per pip because HUF must be converted to USD.
    huf=forex_pip_value_usd("EURHUF",396.0)
    assert 2.0 < huf < 4.0
    # JPY is also conversion-aware rather than hard-coded $10.
    jpy=forex_pip_value_usd("USDJPY",147.0)
    assert 6.0 < jpy < 8.0

def test_minimum_lot_is_rejected_when_it_exceeds_budget():
    c=cfg()
    r=RiskEngine(c)
    # 200 pip stop on EURHUF at 0.01 lot is materially above a $4 target risk.
    lots,risk=r.size(1000,"EURHUF",396.0,200,1.0)
    assert lots==0.0
    assert 3.9 <= risk <= 4.1

def test_rounding_never_increases_planned_stop_risk():
    c=cfg()
    r=RiskEngine(c)
    lots,risk=r.size(20000,"EURUSD",1.1,20,1.0)
    assert lots==0.40
    assert abs(risk-80.0)<1e-9

def test_safe_exotic_position_has_actual_risk_as_r_denominator():
    c=cfg()
    r=RiskEngine(c)
    # With a tight enough stop, 0.01 lots can fit inside the risk budget.
    lots,risk=r.size(1000,"EURHUF",396.0,100,1.0)
    assert lots==0.01
    pv=r.pip_value_per_lot("EURHUF",396.0)
    assert abs(risk-(lots*100*pv))<1e-9

def test_stop_loss_cannot_use_far_away_scan_price(tmp_path):
    c=cfg()
    c.update({
        "symbols":["EURUSD"],
        "execution_realistic_paper":True,
        "daily_loss_limit_pct":50,
        "weekly_loss_limit_pct":50,
        "max_drawdown_pct":50,
        "emergency_session_loss_pct":50,
        "expectancy_governor_enabled":False,
        "directional_setup_gate_enabled":False,
        "execution_economics_gate_enabled":False,
    })
    snap=MarketSnapshot("EURUSD",1.0900,1.0902,0.8,50,1.10,1.099,8,0,"London","now",99)
    class Feed:
        def advance(self): pass
        def snapshot(self,symbol): return snap

    db=Database(str(tmp_path/"stop.db"))
    eng=TradingEngine(c,Feed(),db)
    eng.enabled=True

    # Create a position with a known 10-pip planned stop and force market far beyond it.
    d=Decision("EURUSD","BUY",80,80,"test",10,15,"now")
    # Use a safe entry snapshot around 1.1000.
    entry_snap=MarketSnapshot("EURUSD",1.0999,1.1001,0.8,50,1.10,1.099,8,0,"London","now",99)
    eng.regimes["EURUSD"]="TREND"
    eng._open(d,entry_snap)
    assert eng.positions
    p=eng.positions[0]
    planned_risk=p.risk_amount

    # Existing market is far through the stop; exit logic should use stop + bounded
    # slippage, not the arbitrary 100+ pip scan gap.
    eng.snapshots["EURUSD"]=snap
    eng._mark_and_close()
    rows=db.trades()
    assert rows
    realized_r=abs(float(rows[0]["r_multiple"]))
    assert realized_r < 1.5, realized_r
    assert planned_risk > 0
