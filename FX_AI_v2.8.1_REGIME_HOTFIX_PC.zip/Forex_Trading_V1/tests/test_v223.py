import json, unittest
from pathlib import Path

class V223TradeLogTests(unittest.TestCase):
    def test_version(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["version"],"2.4.1")

    def test_trade_log_has_hard_refresh(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("def refresh_trade_log(self):",src)
        self.assertIn("self._refresh_trade_log(force=True)",src)
        self.assertIn("Trade Log refreshed",src)
        self.assertIn('def _refresh_trade_log(self, force=False):',src)

    def test_synthetic_paper_not_blocked_by_rollover(self):
        brain=Path("forex_app/multi_market_brain.py").read_text(encoding="utf-8")
        selector=Path("forex_app/opportunity_selector.py").read_text(encoding="utf-8")
        self.assertIn("synthetic_paper",brain)
        self.assertIn('asset=="CRYPTO"',brain)
        self.assertIn("synthetic_paper",selector)

    def test_market_watch_active_only_then_shortlist(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("if active:",src)
        self.assertIn("symbols=active[:7]",src)
        self.assertIn('shortlist=e.selection_summary().get("shortlist",[])',src)

if __name__=="__main__":
    unittest.main()
