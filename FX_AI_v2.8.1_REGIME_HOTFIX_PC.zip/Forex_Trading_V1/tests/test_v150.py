import json, unittest
from pathlib import Path
from forex_app.forex_brain import ForexCouncil, build_currency_strength
from forex_app.market import SyntheticFeed

class V150Tests(unittest.TestCase):
    def test_version_and_universe(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["version"],"2.4.1")
        self.assertGreaterEqual(len(cfg["symbols"]),50)
        for s in ["USDCNH","USDZAR","USDMXN","EURPLN","GBPNOK"]:
            self.assertIn(s,cfg["symbols"])

    def test_forex_council_exists(self):
        src=Path("forex_app/engine.py").read_text(encoding="utf-8")
        self.assertIn("MultiMarketResearchBrain",src)
        self.assertIn("build_currency_strength",src)
        self.assertIn("decisions_batch",src)

    def test_command_center_reason_is_not_truncated_column(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("TOP AI OPPORTUNITIES",src)
        self.assertIn("horizontal=False",src)
        self.assertNotIn("(\"REASON\"",src[src.index("def _dashboard"):src.index("def _tree_market_selected")])

    def test_default_release_repo(self):
        src=Path("forex_app/release_channel.py").read_text(encoding="utf-8")
        self.assertIn("hamelame/Forex-Trading-V1-Releases",src)

if __name__=="__main__":
    unittest.main()
