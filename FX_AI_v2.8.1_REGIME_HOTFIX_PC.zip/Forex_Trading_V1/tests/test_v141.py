import json, unittest
from pathlib import Path
from forex_app.release_channel import get_release_channel

class CompatibilityTests(unittest.TestCase):
    def test_version(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["version"],"2.4.1")

    def test_publisher_channel_api(self):
        github,manifest=get_release_channel({})
        self.assertIsInstance(github,str)
        self.assertIsInstance(manifest,str)

if __name__=="__main__":
    unittest.main()
