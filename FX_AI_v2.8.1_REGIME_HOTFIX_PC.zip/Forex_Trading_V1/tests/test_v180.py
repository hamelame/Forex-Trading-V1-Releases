import json, unittest
from pathlib import Path

class V180Tests(unittest.TestCase):
    def test_version(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["version"],"2.4.1")

    def test_large_chart_compact_opportunities(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("height=390",src)
        self.assertIn("height=218",src)
        self.assertIn("grid_rowconfigure(0,weight=8)",src)

    def test_detailed_market_identity(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("def detailed_instrument",src)
        self.assertIn("m['category']",src)

    def test_settings_scroll(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("canvas=tk.Canvas",src)
        self.assertIn("UI rerank interval (s)",src)
        self.assertIn("One Champion AI profile + full PAPER manual control",src)

    def test_decision_feed_no_full_rebuild(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        block=src[src.index("    def _render_decisions"):src.index("    def _trade_log",src.index("    def _render_decisions"))]
        self.assertNotIn("self.decision_feed.clear()",block)
        self.assertIn("_decision_cards",block)
        self.assertIn("_update_decision_card",src)

    def test_publisher_repo(self):
        src=Path("tools/publish_release.ps1").read_text(encoding="utf-8")
        self.assertIn("hamelame/Forex-Trading-V1-Releases",src)
        self.assertIn("gh release list",src)
        self.assertIn("gh release create",src)

if __name__=="__main__":
    unittest.main()
