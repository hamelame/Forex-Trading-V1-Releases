import json
from pathlib import Path
from forex_app.opportunity_selector import OpportunitySelector

def test_v227_version_and_changelog():
    cfg=json.loads(Path('config.json').read_text())
    assert cfg['version']=='2.4.1'
    assert Path('CHANGELOG_v2.2.7.md').exists()

def test_diversity_underlying_metals():
    cfg=json.loads(Path('config.json').read_text())
    sel=OpportunitySelector(cfg)
    out=sel._diversify(['XAGEUR','XAGGBP','XAUUSD','XAUGBP'])
    assert len([x for x in out if x.startswith('XAG')])==1
    assert len([x for x in out if x.startswith('XAU')])==1

def test_single_market_class_control_source():
    src=Path('forex_app/ui.py').read_text()
    assert 'Market class selection is controlled in Shadow Lab' in src
