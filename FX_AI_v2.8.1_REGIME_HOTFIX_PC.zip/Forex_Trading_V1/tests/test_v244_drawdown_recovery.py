import json
from pathlib import Path

from forex_app.risk import RiskEngine
from forex_app.models import Decision

def load_cfg():
    c=json.loads(Path("config.json").read_text(encoding="utf-8"))
    c["starting_balance"]=1000.0
    c["max_drawdown_pct"]=6.0
    c["emergency_drawdown_pct"]=10.0
    c["drawdown_recovery_cooldown_scans"]=5
    c["drawdown_recovery_risk_multiplier"]=0.25
    c["daily_loss_limit_pct"]=50.0
    c["weekly_loss_limit_pct"]=50.0
    c["max_total_risk_pct"]=10.0
    c["risk_per_trade_pct"]=0.4
    return c

class Snap:
    symbol="EURUSD"
    spread_pips=0.5

def decision():
    return Decision("EURUSD","BUY",80,80,"",10,15,"now")

def test_version_244():
    assert json.loads(Path("config.json").read_text(encoding="utf-8"))["version"]=="2.6.0"

def test_high_water_cooldown_advances_without_gate_candidate():
    c=load_cfg()
    r=RiskEngine(c)
    r.reset_session(1000)
    r.high_water_balance=1200

    # 6.67% drawdown from the profit high-water triggers cooldown.
    assert r.update_drawdown_state(1120,100)=="COOLDOWN"
    assert r.drawdown_mode=="COOLDOWN"
    until=r.drawdown_cooldown_until_scan
    assert until==105

    # No gate() calls are required during these scans.
    for scan in range(101,105):
        assert r.update_drawdown_state(1120,scan)=="COOLDOWN"

    # The active-scan lifecycle must automatically advance to RECOVERY.
    assert r.update_drawdown_state(1120,105)=="RECOVERY"
    assert r.drawdown_mode=="RECOVERY"
    assert r.high_water_balance==1120
    assert r.recovery_risk_multiplier()==0.25

def test_gate_allows_trade_after_drawdown_cooldown():
    c=load_cfg()
    r=RiskEngine(c)
    r.reset_session(1000)
    r.high_water_balance=1200
    r.update_drawdown_state(1120,10)
    for scan in range(11,16):
        r.update_drawdown_state(1120,scan)

    ok,why=r.gate(1120,[],decision(),Snap(),scan_count=15)
    assert ok, why
    assert "RECOVERY" in why

def test_profitable_recovery_trade_returns_to_normal():
    c=load_cfg()
    r=RiskEngine(c)
    r.reset_session(1000)
    r.high_water_balance=1200
    r.update_drawdown_state(1120,10)
    for scan in range(11,16):
        r.update_drawdown_state(1120,scan)
    assert r.recovery_state(15)[0]=="RECOVERY"

    r.on_trade_closed(5.0,16)
    r.update_drawdown_state(1125,16)
    assert r.recovery_state(16)[0]=="NORMAL"
    assert r.drawdown_mode=="NORMAL"

def test_fresh_drawdown_can_rearm_after_recovery_instead_of_deadlock():
    c=load_cfg()
    r=RiskEngine(c)
    r.reset_session(1000)
    r.high_water_balance=1200
    r.update_drawdown_state(1120,10)
    for scan in range(11,16):
        r.update_drawdown_state(1120,scan)
    assert r.drawdown_mode=="RECOVERY"

    # Recovery high-water is 1120. A fresh >6% loss should start a NEW cooldown,
    # not leave the old cooldown permanently latched.
    assert r.update_drawdown_state(1050,17)=="COOLDOWN"
    assert r.drawdown_cooldown_until_scan==22

def test_emergency_drawdown_remains_hard_stop():
    c=load_cfg(); c["catastrophic_drawdown_pct"]=20
    r=RiskEngine(c)
    r.reset_session(1000)
    r.high_water_balance=1200
    assert r.update_drawdown_state(1120,10)=="COOLDOWN"

    # Only catastrophic 20%+ giveback remains a hard stop.
    assert r.update_drawdown_state(950,11)=="EMERGENCY"
    ok,why=r.gate(950,[],decision(),Snap(),scan_count=11)
    assert not ok
    assert "Emergency high-water drawdown" in why
