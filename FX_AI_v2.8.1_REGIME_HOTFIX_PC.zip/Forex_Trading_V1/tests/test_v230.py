import json
from pathlib import Path
from forex_app import __version__
from forex_app.opportunity_selector import OpportunitySelector

def test_v230_canonical_version():
    cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
    assert cfg["version"]=="2.4.1"
    assert __version__=="2.4.1"

def test_shared_kpi_value_color_bug_fixed():
    src=Path("forex_app/ui.py").read_text(encoding="utf-8")
    assert "self.value_color=TEXT" in src
    assert "fill=self.value_color" in src

def test_whats_new_first_launch_page():
    src=Path("forex_app/ui.py").read_text(encoding="utf-8")
    assert '("What\'s New","★")' in src
    assert "def _should_show_whats_new" in src
    assert "last_seen_whats_new" in src
    assert "CONTINUE TO COMMAND CENTER" in src

def test_decision_feed_2_components():
    src=Path("forex_app/ui.py").read_text(encoding="utf-8")
    assert "class ConfidenceGauge" in src
    assert "KEY FACTORS" in src
    assert "EDGE QUALITY" in src
    assert "LATEST AI CYCLE" in src

def test_performance_chart_rebuilt():
    src=Path("forex_app/ui.py").read_text(encoding="utf-8")
    assert "class PerformanceChart" in src
    assert "MAX DRAWDOWN" in src
    assert "SESSION START" in src

def test_refresh_visual_confirmation_and_trade_hard_refresh():
    src=Path("forex_app/ui.py").read_text(encoding="utf-8")
    assert "✓  REFRESHED" in src
    assert "def refresh_trade_log" in src
    assert "self.engine.db.conn.commit()" in src
    assert "trade_refresh_state" in src

def test_shadow_and_market_kpis_present():
    src=Path("forex_app/ui.py").read_text(encoding="utf-8")
    for label in ("SCANNED","ELIGIBLE","SELECTED","TRADE-READY"):
        assert label in src

def test_duplicate_underlying_diversity_is_strict_for_metals():
    cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
    sel=OpportunitySelector(cfg)
    out=sel._diversify(["XAGEUR","XAGGBP","XAGUSD","XAUUSD","XAUGBP","XPTUSD"])
    assert sum(x.startswith("XAG") for x in out)==1
    assert sum(x.startswith("XAU") for x in out)==1
    assert "XPTUSD" in out

def test_data_quality_has_health_filters():
    src=Path("forex_app/ui.py").read_text(encoding="utf-8")
    assert 'values=["ALL","HEALTHY","WATCH","CRITICAL"]' in src
    assert "DATA QUALITY:" in src

def test_command_center_live_heartbeat():
    src=Path("forex_app/ui.py").read_text(encoding="utf-8")
    assert "AI HEARTBEAT" in src
    assert "LAST ENGINE EVENT" in src
