import unittest
from pathlib import Path

class ChartLockSourceTests(unittest.TestCase):
    def test_rank_refresh_uses_isolated_chart_symbol(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        block=src[src.index("    def _refresh_chart"):src.index("    def _markets",src.index("    def _refresh_chart"))]
        self.assertIn("sym=self.chart_symbol",block)
        self.assertNotIn("self.chart_symbol=candidate",block)
        self.assertNotIn("self.chart_symbol=current",block)

if __name__=="__main__":
    unittest.main()
