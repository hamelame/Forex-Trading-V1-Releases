import json, unittest
from pathlib import Path

class V140Tests(unittest.TestCase):
    def test_version(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["version"],"2.4.1")
        self.assertIn(cfg.get("chart_mode"),("LOCKED","AUTO"))

    def test_trade_log_page_exists(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn('("Trade Log","≡")',src)
        self.assertIn("def refresh_trade_log",src)

if __name__=="__main__":
    unittest.main()
