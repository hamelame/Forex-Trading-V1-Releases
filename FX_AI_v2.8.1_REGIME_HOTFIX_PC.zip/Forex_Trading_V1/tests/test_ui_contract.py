import unittest
from pathlib import Path

class UIContractTests(unittest.TestCase):
    def test_reference_dashboard_contract(self):
        src=Path('forex_app/ui.py').read_text(encoding='utf-8')
        for token in ['rowheight=42','REALIZED P/L','MARKET WATCH','MARKET INTELLIGENCE','HeatRing','MiniSpark']:
            self.assertIn(token,src)
        self.assertIn('_refresh_active',src)

    def test_manual_chart_only(self):
        src=Path('forex_app/ui.py').read_text(encoding='utf-8')
        self.assertNotIn('<<TreeviewSelect>>',src)
        self.assertIn('<ButtonRelease-1>',src)
        self.assertNotIn('def toggle_chart_mode',src)
        self.assertIn('selected_chart_symbol',src)

    def test_scroll_preservation(self):
        src=Path('forex_app/ui.py').read_text(encoding='utf-8')
        self.assertIn('<MouseWheel>',src)
        self.assertIn('t.yview_moveto(y[0])',src)
