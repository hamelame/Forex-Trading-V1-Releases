import json, unittest
from pathlib import Path

class V222Tests(unittest.TestCase):
    def test_version(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["version"],"2.4.1")
        self.assertEqual(len(cfg["symbols"]),140)

    def test_refresh_is_real_scan_refresh(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("def refresh_now(self, scan=True)",src)
        self.assertIn("self.engine.scan()",src)
        self.assertIn("{self.active} refreshed at",src)

    def test_unrealized_on_command_center(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn('"UNREALIZED P/L","Open positions right now"',src)
        self.assertIn('self.set_kpi_pnl("UNREALIZED P/L"',src)

    def test_capital_change_flow(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("Paper Trading Capital Changed",src)
        self.assertIn("Start a NEW paper session now",src)
        self.assertIn("self.engine.apply_paper_capital(cap,start_new_session=start_now)",src)

    def test_selection_reselects_on_change(self):
        src=Path("forex_app/opportunity_selector.py").read_text(encoding="utf-8")
        self.assertIn("def force_reselect",src)
        eng=Path("forex_app/engine.py").read_text(encoding="utf-8")
        self.assertIn("force_reselect=False",eng)

    def test_market_watch_prioritizes_positions(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("active=[]",src)
        self.assertIn("pos_by_symbol",src)
        self.assertIn('statev.set(f"{p.side} · LIVE")',src)
        self.assertIn("Open P/L",src)

    def test_portfolio_heat_layout(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn('value_font=15 if self.title=="PORTFOLIO HEAT"',src)
        self.assertIn("cx=w-18",src)

if __name__=="__main__":
    unittest.main()
