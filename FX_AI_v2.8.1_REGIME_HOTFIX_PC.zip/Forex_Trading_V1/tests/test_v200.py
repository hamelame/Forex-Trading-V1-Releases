import json, unittest
from pathlib import Path
from forex_app.multi_market_brain import MultiMarketResearchBrain

class V200Tests(unittest.TestCase):
    def test_version_and_paper_lock(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["version"],"2.4.1")
        self.assertEqual(cfg["mode"],"PAPER")
        self.assertEqual(cfg["broker"],"synthetic")
        self.assertTrue(cfg["paper_only_build"])

    def test_research_brain_v2_wired(self):
        src=Path("forex_app/engine.py").read_text(encoding="utf-8")
        self.assertIn("MultiMarketResearchBrain",src)
        self.assertIn("build_currency_strength",src)
        self.assertIn("_risk_multiplier",src)
        self.assertIn("break_even_at_r",src)
        self.assertIn("trail_start_r",src)

    def test_hard_synthetic_startup(self):
        src=Path("main.py").read_text(encoding="utf-8")
        self.assertIn('cfg["mode"]="PAPER"',src)
        self.assertIn('cfg["broker"]="synthetic"',src)
        self.assertIn("feed=SyntheticFeed",src)

    def test_config_migration_exists(self):
        src=Path("main.py").read_text(encoding="utf-8")
        self.assertIn("min_risk_multiplier",src)
        self.assertIn("paper_only_build",src)
        self.assertIn("AI TRADING uses protected research limits",src)

    def test_no_console_launcher(self):
        src=Path("START_FOREX_APP.bat").read_text(encoding="utf-8").lower()
        self.assertIn("pythonw.exe",src)
        self.assertTrue(Path("START_FOREX_APP_DEBUG.bat").exists())

    def test_brain_has_abstention_and_agreement(self):
        src=Path("forex_app/forex_brain_v2.py").read_text(encoding="utf-8")
        self.assertIn("agreement",src)
        self.assertIn("insufficient consensus/edge",src)
        self.assertIn("HIGH VOL",src)

if __name__=="__main__":
    unittest.main()
