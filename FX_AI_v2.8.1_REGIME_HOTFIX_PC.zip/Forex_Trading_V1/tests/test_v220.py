import json, unittest
from pathlib import Path
from forex_app.opportunity_selector import OpportunitySelector

class V220Tests(unittest.TestCase):
    def test_version_and_universe(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["version"],"2.4.1")
        self.assertEqual(len(cfg["symbols"]),140)

    def test_selection_modes(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["selection_mode"],"AUTO TOP 10")
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("AUTO TOP 5",src)
        self.assertIn("AUTO TOP 10",src)
        self.assertIn("MANUAL",src)
        self.assertIn("AI Market Selection Lab",src)

    def test_selector_is_execution_gate(self):
        src=Path("forex_app/engine.py").read_text(encoding="utf-8")
        self.assertIn("self.selector.select",src)
        self.assertIn("allowed=set(shortlist)",src)
        self.assertIn("NO TRADE",src)

    def test_stable_selector_controls(self):
        src=Path("forex_app/opportunity_selector.py").read_text(encoding="utf-8")
        self.assertIn("selection_hysteresis_points",src)
        self.assertIn("selection_refresh_scans",src)
        self.assertIn("manual_selected_symbols",src)

    def test_larger_ui(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("rowheight=42",src)
        self.assertIn('width=238,height=48',src)
        self.assertIn('scaling",1.32',src)

if __name__=="__main__":
    unittest.main()
