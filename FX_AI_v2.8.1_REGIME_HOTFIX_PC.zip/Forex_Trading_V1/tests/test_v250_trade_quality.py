import json
from pathlib import Path
from forex_app import __version__
from forex_app.database import Database
from forex_app.self_learning import SelfLearningEngine
from forex_app.models import MarketSnapshot, Decision

def cfg():
    return json.loads(Path("config.json").read_text())

def exp(i,r=-0.8):
    return {"trade_id":f"x{i}","ts":f"2026-08-22T00:0{i}:00+00:00","symbol":"EURCZK",
    "asset_class":"FOREX","regime":"REVERSAL","session":"Asia","side":"SELL",
    "context_key":"FOREX|REVERSAL|SELL|Asia","score":80,"confidence":80,"spread":1,
    "rsi":50,"atr":8,"trend":0,"meanrev":60,"breakout":0,"consensus":100,
    "pnl":r,"r_multiple":r,"mfe_r":0.1,"mae_r":r,"bars_open":10,"exit_reason":"Stop Loss"}

def test_version():
    assert __version__=="2.6.0"

def test_fastguard_blocks_bad_context_after_four_samples(tmp_path):
    c=cfg(); db=Database(str(tmp_path/"f.db"))
    for i in range(4): db.learning_experience(exp(i))
    l=SelfLearningEngine(c,db)
    s=MarketSnapshot("EURCZK",24.5,24.51,.8,50,24.5,24.4,8,0,"Asia","now",99)
    d=Decision("EURCZK","SELL",80,80,"FOREX / REVERSAL | Trend +0 · MeanRev +60 · Breakout +0",10,15,"now")
    a=l.adjust_decision(d,s,"REVERSAL")
    assert a.action=="WAIT"
    assert "FastGuard" in a.reason
    assert "fast context suppressed" in a.reason

def test_fastguard_does_not_block_positive_context(tmp_path):
    c=cfg(); db=Database(str(tmp_path/"p.db"))
    for i in range(4): db.learning_experience(exp(i,0.8))
    l=SelfLearningEngine(c,db)
    s=MarketSnapshot("EURCZK",24.5,24.51,.8,50,24.5,24.4,8,0,"Asia","now",99)
    d=Decision("EURCZK","SELL",80,80,"FOREX / REVERSAL | Trend +0 · MeanRev +60 · Breakout +0",10,15,"now")
    a=l.adjust_decision(d,s,"REVERSAL")
    assert a.action=="SELL"
