import unittest
from types import SimpleNamespace
from forex_app.opportunity_selector import OpportunitySelector

class D:
    def __init__(self,action,score=80,confidence=80): self.action=action; self.score=score; self.confidence=confidence

def snap(sym):
    return SimpleNamespace(symbol=sym,quality=95,spread_pips=.5,session='Asia')

class TestTradeReadyDeadlock(unittest.TestCase):
    def test_reselects_when_sticky_shortlist_has_zero_trade_ready(self):
        cfg={'selection_mode':'AUTO TOP 5','selection_refresh_scans':99,'selection_hysteresis_points':3,
             'enabled_asset_classes':['FOREX','METALS','ENERGY','INDICES','CRYPTO'],
             'selection_min_data_quality':75,'selection_max_spread':2.5,'selection_min_ai_score':63,
             'selection_min_confidence':56,'selection_min_market_score':58,'pause_on_high_volatility':False,
             'selection_max_shared_currency':5,'selection_max_index_region':5,'selection_max_crypto_beta':5}
        sel=OpportunitySelector(cfg)
        syms=['EURUSD','GBPJPY','AUDCAD','NZDCHF','XAUUSD','BTCUSD']
        snaps={x:snap(x) for x in syms}; regimes={x:'MIXED' for x in syms}
        ranks={x:90-i for i,x in enumerate(syms)}
        first={x:D('BUY') for x in syms}
        sel.select(1,snaps,first,ranks,regimes)
        old=list(sel.shortlist)
        decisions={x:D('BLOCK') for x in syms}
        decisions['BTCUSD']=D('BUY',85,80)
        ranks['BTCUSD']=70 # deliberately weaker than sticky incumbents
        sel.select(2,snaps,decisions,ranks,regimes)
        self.assertGreater(sel.stats['trade_ready'],0)
        self.assertIn('BTCUSD',sel.shortlist)

if __name__=='__main__': unittest.main()
