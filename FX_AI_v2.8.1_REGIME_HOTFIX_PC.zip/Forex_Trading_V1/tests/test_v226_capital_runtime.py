import json, unittest
from pathlib import Path
from forex_app.database import Database
from forex_app.market import SyntheticFeed
from forex_app.engine import TradingEngine

class V226CapitalRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))

    def test_version(self):
        self.assertEqual(self.cfg["version"],"2.4.1")

    def test_downsizing_capital_resets_all_risk_anchors(self):
        db=Database("data/_v226_capital.db")
        eng=TradingEngine(self.cfg,SyntheticFeed(self.cfg["symbols"]),db)
        eng.enabled=True
        eng.balance=20000
        eng.equity=20000
        eng.risk.day_start_balance=20000
        eng.risk.week_start_balance=20000
        eng.risk.high_water_balance=20000

        changed=eng.apply_paper_capital(10000,start_new_session=True)

        self.assertTrue(changed)
        self.assertEqual(eng.balance,10000)
        self.assertEqual(eng.equity,10000)
        self.assertEqual(eng.risk.day_start_balance,10000)
        self.assertEqual(eng.risk.week_start_balance,10000)
        self.assertEqual(eng.risk.high_water_balance,10000)
        self.assertEqual(len(eng.positions),0)
        self.assertTrue(eng.enabled)

    def test_capital_change_does_not_create_false_drawdown_block(self):
        db=Database("data/_v226_trade.db")
        eng=TradingEngine(self.cfg,SyntheticFeed(self.cfg["symbols"]),db)
        eng.enabled=True
        eng.apply_paper_capital(10000,start_new_session=True)

        # A downsized account must still be able to progress through normal
        # selection/risk logic after the high-water reset.
        opened=False
        for _ in range(80):
            eng.scan()
            if eng.positions:
                opened=True
                break

        self.assertTrue(opened, f"AI failed to open after capital change; status={eng.last_status}")
        self.assertNotIn("drawdown circuit breaker",eng.last_status.lower())

    def test_paused_engine_stays_paused_after_new_capital_session(self):
        db=Database("data/_v226_paused.db")
        eng=TradingEngine(self.cfg,SyntheticFeed(self.cfg["symbols"]),db)
        self.assertFalse(eng.enabled)
        eng.apply_paper_capital(50000,start_new_session=True)
        self.assertFalse(eng.enabled)
        self.assertEqual(eng.balance,50000)
        self.assertEqual(eng.risk.high_water_balance,50000)

if __name__=="__main__":
    unittest.main()
