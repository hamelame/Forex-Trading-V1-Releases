import json, unittest
from pathlib import Path

class V225UIControlTests(unittest.TestCase):
    def test_version(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["version"],"2.4.1")

    def test_dark_yellow_combobox(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("*TCombobox*Listbox.background",src)
        self.assertIn("*TCombobox*Listbox.foreground",src)

    def test_pause_keep_close_cancel(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("CLOSE ALL POSITIONS",src)
        self.assertIn("KEEP POSITIONS",src)
        self.assertIn("askyesnocancel",src)

    def test_shadow_candidate_selected_and_refresh(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("ELIGIBLE MARKET CANDIDATES",src)
        self.assertIn("AI SELECTED",src)
        self.assertIn("REFRESH MARKET",src)
        self.assertIn("def refresh_shadow_market",src)

    def test_decision_explainer(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("AI DECISION EXPLAINER",src)
        self.assertIn("def _update_ai_decision_explainer",src)

    def test_pnl_sign_normalization(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("def normalize_zero",src)
        self.assertIn("def format_pnl",src)
        self.assertIn("return f\"+${value:,.2f}\"",src)
        self.assertIn("return f\"-${abs(value):,.2f}\"",src)

if __name__=="__main__":
    unittest.main()
