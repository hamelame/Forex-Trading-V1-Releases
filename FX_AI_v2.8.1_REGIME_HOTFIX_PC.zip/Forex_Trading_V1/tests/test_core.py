import json, unittest
from forex_app.market import SyntheticFeed
from forex_app.brain import Brain
from forex_app.risk import RiskEngine

class CoreTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with open("config.json") as f: cls.cfg=json.load(f)

    def test_snapshot(self):
        f=SyntheticFeed(["EURUSD"]); s=f.snapshot("EURUSD")
        self.assertGreater(s.ask,s.bid); self.assertGreater(s.spread_pips,0)

    def test_brain(self):
        f=SyntheticFeed(["EURUSD"]); s=f.snapshot("EURUSD")
        d=Brain("Champion",self.cfg["champion"],self.cfg["min_signal_score"]).decide(s)
        self.assertIn(d.action,("BUY","SELL","WAIT","BLOCK"))
        self.assertTrue(0<=d.score<=100)

    def test_risk_size(self):
        r=RiskEngine(self.cfg)
        lots,risk=r.size(20000,"EURUSD",1.1,20)
        self.assertGreaterEqual(lots,.01); self.assertAlmostEqual(risk,80.0)

if __name__=="__main__": unittest.main()
