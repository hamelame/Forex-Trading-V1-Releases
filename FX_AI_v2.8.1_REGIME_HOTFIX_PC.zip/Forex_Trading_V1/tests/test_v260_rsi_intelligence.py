import json
from pathlib import Path

from forex_app import __version__
from forex_app.models import MarketSnapshot
from forex_app.rsi_intelligence import analyze_snapshot
from forex_app.intelligence import regime
from forex_app.database import Database
from forex_app.self_learning import SelfLearningEngine


def cfg():
    return json.loads(Path("config.json").read_text(encoding="utf-8"))


def mk(prices,rsis,momentum=.05,fast=1.1002,slow=1.1000):
    return MarketSnapshot(
        "EURUSD",1.0999,1.1001,.7,float(rsis[-1]),fast,slow,8.0,momentum,
        "London","now",99.0,tuple(rsis),tuple(prices)
    )


def test_version_260():
    assert __version__=="2.6.0"
    assert cfg()["version"]=="2.6.0"


def test_overbought_rsi_is_not_automatic_short():
    prices=[100+i*.4 for i in range(40)]
    rsis=[48+i*.65 for i in range(40)]
    rsis=[min(76,x) for x in rsis]
    a=analyze_snapshot(mk(prices,rsis,momentum=.6,fast=1.102,slow=1.100))
    assert a.value>=70
    assert a.directional_score>0
    assert a.bias=="BULLISH"


def test_oversold_rsi_is_not_automatic_long():
    prices=[120-i*.4 for i in range(40)]
    rsis=[52-i*.65 for i in range(40)]
    rsis=[max(24,x) for x in rsis]
    a=analyze_snapshot(mk(prices,rsis,momentum=-.6,fast=1.098,slow=1.100))
    assert a.value<=30
    assert a.directional_score<0
    assert a.bias=="BEARISH"


def test_regular_bullish_divergence_detected():
    prices=(100,99,98,99,100,99,97,98,99,100)
    rsis=(42,35,25,36,46,35,31,39,44,48)
    a=analyze_snapshot(mk(prices,rsis))
    assert a.regular_divergence=="BULLISH"


def test_hidden_bullish_divergence_detected_for_continuation():
    prices=(100,99,98,99,101,100,99,100,102,103)
    rsis=(45,40,35,42,60,47,31,46,61,64)
    a=analyze_snapshot(mk(prices,rsis,momentum=.4,fast=1.102,slow=1.100))
    assert a.hidden_divergence=="BULLISH"


def test_bullish_failure_swing_detected():
    # oversold low -> rebound high -> higher low -> breakout above rebound high
    prices=(100,99,98,99,100,99,99.5,100,101,102,103,104)
    rsis=(42,34,24,33,46,38,31,41,48,52,58,62)
    a=analyze_snapshot(mk(prices,rsis))
    assert a.failure_swing=="BULLISH"


def test_rsi_extreme_no_longer_makes_reversal_regime_by_itself():
    prices=tuple(100+i*.3 for i in range(40))
    rsis=tuple(min(78,52+i*.65) for i in range(40))
    s=mk(prices,rsis,momentum=.55,fast=1.102,slow=1.100)
    assert regime(s)=="TREND"


def _exp(i,tag,r):
    return {
        "trade_id":f"rsi{i}","ts":f"2026-09-12T00:{i%60:02d}:00+00:00",
        "symbol":"EURUSD","asset_class":"FOREX","regime":"TREND","session":"London","side":"BUY",
        "context_key":"FOREX|TREND|BUY|London","score":80,"confidence":80,"spread":.7,
        "rsi":60,"atr":8,"trend":60,"meanrev":0,"breakout":30,"consensus":100,
        "rsi_state":"BULLISH","rsi_pattern":tag,"rsi_bias":"BULLISH","rsi_slope":1.0,"rsi_support":40,
        "pnl":r,"r_multiple":r,"mfe_r":max(r,0),"mae_r":min(r,0),"bars_open":10,
        "exit_reason":"Stop Loss" if r<0 else "Take Profit",
    }


def test_rsi_pattern_governor_quarantines_bad_pattern(tmp_path):
    c=cfg()
    c["rsi_pattern_min_samples"]=10
    db=Database(str(tmp_path/"rsi.db"))
    for i in range(12):
        db.learning_experience(_exp(i,"HIDDEN_BULLISH_DIVERGENCE",-0.7))
    learn=SelfLearningEngine(c,db)
    g=learn.rsi_pattern_governor("EURUSD","TREND","BUY",("HIDDEN_BULLISH_DIVERGENCE",))
    assert not g["allow"]
    assert g["risk_mult"]==0.0
