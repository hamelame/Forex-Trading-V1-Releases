import json, unittest
from pathlib import Path

class V190Tests(unittest.TestCase):
    def test_version(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["version"],"2.4.1")

    def test_premium_nav_and_cards(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("class NavItem",src)
        self.assertIn("class KpiCard",src)
        self.assertIn("set_active",src)
        self.assertIn("Segoe UI Variable",src)

    def test_hdpi(self):
        src=Path("main.py").read_text(encoding="utf-8")
        self.assertIn("SetProcessDpiAwareness",src)
        self.assertIn("enable_windows_hdpi()",src)

    def test_larger_chart(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn("height=390",src)
        self.assertIn("height=218",src)

if __name__=="__main__":
    unittest.main()
