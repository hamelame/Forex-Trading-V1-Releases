import json
from pathlib import Path

from forex_app import __version__
from forex_app.execution import ExecutionRealism
from forex_app.models import MarketSnapshot, Decision
from forex_app.database import Database
from forex_app.self_learning import SelfLearningEngine
from forex_app.engine import TradingEngine

def cfg():
    return json.loads(Path("config.json").read_text(encoding="utf-8"))

def snap(symbol="EURUSD",spread=.7,atr=8,quality=99,momentum=.6,rsi=50,fast=1.101,slow=1.100):
    return MarketSnapshot(symbol,1.0999,1.1001,spread,rsi,fast,slow,atr,momentum,"London","now",quality)

def experience(i,asset="FOREX",side="SELL",r=-.6,symbol="EURUSD"):
    return {
        "trade_id":f"x{i}","ts":f"2026-08-27T00:{i%60:02d}:00+00:00",
        "symbol":symbol,"asset_class":asset,"regime":"TREND","session":"London",
        "side":side,"context_key":f"{asset}|TREND|{side}|London",
        "score":80,"confidence":80,"spread":.7,"rsi":50,"atr":8,
        "trend":60 if side=="BUY" else -60,"meanrev":0,"breakout":30,"consensus":100,
        "pnl":r,"r_multiple":r,"mfe_r":max(r,0),"mae_r":min(r,0),
        "bars_open":10,"exit_reason":"Stop Loss" if r<0 else "Take Profit",
    }

def test_version_254():
    c=cfg()
    assert __version__=="2.6.0"
    assert c["version"]=="2.6.0"

def test_slippage_increases_with_size():
    c=cfg(); ex=ExecutionRealism(c); s=snap()
    small=ex.estimate("BUY",s,.05,1,.7,"MARKET")
    large=ex.estimate("BUY",s,3.0,1,.7,"MARKET")
    assert large.size_impact>small.size_impact
    assert large.expected_slippage_pips>small.expected_slippage_pips

def test_passive_limit_costs_less_but_has_more_no_fill_risk():
    c=cfg(); ex=ExecutionRealism(c); s=snap()
    passive=ex.estimate("BUY",s,.2,1,.4,"PASSIVE_LIMIT")
    market=ex.estimate("BUY",s,.2,1,.9,"MARKET")
    assert passive.expected_slippage_pips<market.expected_slippage_pips
    assert passive.no_fill_probability>market.no_fill_probability
    assert passive.expected_commission_usd<market.expected_commission_usd

def test_sell_execution_prior_can_be_slightly_more_expensive():
    c=cfg(); ex=ExecutionRealism(c); s=snap("BTCUSD")
    buy=ex.estimate("BUY",s,.2,2,.8,"MARKET")
    sell=ex.estimate("SELL",s,.2,2,.8,"MARKET")
    assert sell.expected_slippage_pips>=buy.expected_slippage_pips

def test_side_learning_can_quarantine_persistently_bad_shorts(tmp_path):
    c=cfg(); c["governor_side_min_samples"]=20
    db=Database(str(tmp_path/"side.db"))
    for i in range(22):
        db.learning_experience(experience(i,side="SELL",r=-.7))
    learn=SelfLearningEngine(c,db)
    g=learn.expectancy_governor("GBPUSD","TREND","SELL","London")
    assert g["state"]=="RESEARCH-ONLY",g
    assert not g["allow"]
    assert "FOREX/SELL" in g["reason"]

def test_trend_direction_gate_requires_ema_and_momentum_alignment(tmp_path):
    c=cfg(); c["expectancy_governor_enabled"]=False
    class Feed:
        def advance(self): pass
        def snapshot(self,symbol): return snap()
    eng=TradingEngine(c,Feed(),Database(str(tmp_path/"d.db")))
    eng.regimes["EURUSD"]="TREND"
    buy=Decision("EURUSD","BUY",80,80,"test",10,18,"now")
    ok,_=eng._directional_setup_gate(buy,snap(momentum=.5,fast=1.101,slow=1.100))
    assert ok
    ok,why=eng._directional_setup_gate(buy,snap(momentum=-.5,fast=1.099,slow=1.100))
    assert not ok
    assert "TREND" in why

def test_reversal_direction_gate_requires_rsi_structure_not_raw_extreme(tmp_path):
    c=cfg(); c["expectancy_governor_enabled"]=False
    class Feed:
        def advance(self): pass
        def snapshot(self,symbol): return snap()
    eng=TradingEngine(c,Feed(),Database(str(tmp_path/"r.db")))
    eng.regimes["EURUSD"]="REVERSAL"
    buy=Decision("EURUSD","BUY",80,80,"test",10,19,"now")

    # Raw oversold RSI alone is no longer enough.
    raw=snap(rsi=30,momentum=.05)
    ok,_=eng._directional_setup_gate(buy,raw)
    assert not ok

    # Lower price low + higher RSI low provides bullish regular divergence.
    prices=(100,99,98,99,100,99,97,98,99,100)
    rsis=(42,35,25,36,46,35,31,39,44,48)
    structured=MarketSnapshot("EURUSD",1.0999,1.1001,.7,48,1.1002,1.1000,8,.05,
                              "London","now",99,rsis,prices)
    ok,why=eng._directional_setup_gate(buy,structured)
    assert ok,why

def test_execution_economics_gate_can_block_expensive_trade(tmp_path):
    c=cfg()
    c.update({
        "expectancy_governor_enabled":False,
        "execution_realistic_paper":True,
        "max_execution_cost_r":0.01,
        "symbols":["EURUSD"],
        "starting_balance":20000,
        "paper_trading_capital":20000,
    })
    class Feed:
        def advance(self): pass
        def snapshot(self,symbol): return snap(spread=2.0,atr=20,quality=90)
    db=Database(str(tmp_path/"cost.db"))
    eng=TradingEngine(c,Feed(),db); eng.enabled=True; eng.regimes["EURUSD"]="TREND"
    d=Decision("EURUSD","BUY",85,85,"test",10,18,"now")
    eng._open(d,snap(spread=2.0,atr=20,quality=90,momentum=.8,fast=1.102,slow=1.100))
    assert not eng.positions
    assert "Execution economics gate" in eng.last_status
