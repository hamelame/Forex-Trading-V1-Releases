import json, unittest
from pathlib import Path
from forex_app.database import Database
from forex_app.market import SyntheticFeed
from forex_app.engine import TradingEngine

class V224Tests(unittest.TestCase):
    def test_version(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        self.assertEqual(cfg["version"],"2.4.1")

    def test_engine_starts_paused(self):
        cfg=json.loads(Path("config.json").read_text(encoding="utf-8"))
        db=Database("data/_v224_startup.db")
        eng=TradingEngine(cfg,SyntheticFeed(cfg["symbols"]),db)
        self.assertFalse(eng.enabled)
        self.assertIn("paused",eng.last_status.lower())

    def test_kpi_grid_is_responsive(self):
        src=Path("forex_app/ui.py").read_text(encoding="utf-8")
        self.assertIn('cards.grid_columnconfigure(col,weight=1,uniform="kpi")',src)
        self.assertIn('row=i//5',src)

if __name__=="__main__":
    unittest.main()
