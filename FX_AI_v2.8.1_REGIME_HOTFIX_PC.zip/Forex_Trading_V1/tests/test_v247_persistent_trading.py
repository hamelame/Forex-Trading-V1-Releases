import json
from pathlib import Path

from forex_app import __version__
from forex_app.multi_market_brain import MultiMarketResearchBrain
from forex_app.models import MarketSnapshot, Decision
from forex_app.database import Database
from forex_app.engine import TradingEngine

def cfg():
    return json.loads(Path("config.json").read_text(encoding="utf-8"))

def test_version_247_single_source():
    assert __version__=="2.6.0"
    assert cfg()["version"]=="2.6.0"

def test_bounded_opportunity_recovery_can_convert_near_miss_wait():
    c=cfg()
    brain=MultiMarketResearchBrain(cfg=c)
    prices=tuple(1.0950+i*0.00008 for i in range(40))
    rsis=tuple(45+i*0.38 for i in range(40))
    s=MarketSnapshot(
        "EURUSD",1.09996,1.10004,0.7044614399,rsis[-1],
        1.0997810308,1.0985805229,5.2699822,0.05,
        "London","now",98.2685212,rsis,prices
    )
    strength={"EUR":15,"USD":-15}
    primary=brain.decide(s,strength,0.0)
    recovery=brain.decide(s,strength,1.0)
    assert primary.action=="WAIT"
    assert recovery.action in ("BUY","SELL")
    assert "OPPORTUNITY RECOVERY" in recovery.reason

def test_hard_block_is_never_bypassed_by_opportunity_recovery():
    c=cfg()
    brain=MultiMarketResearchBrain(cfg=c)
    s=MarketSnapshot(
        "EURUSD",1.09996,1.10004,0.7,30,
        1.1005,1.0990,8.0,1.0,"London","now",40.0
    )
    recovery=brain.decide(s,{"EUR":50,"USD":-50},1.0)
    assert recovery.action=="BLOCK"
    assert ("low data quality" in recovery.reason or "abnormal market state" in recovery.reason)

def test_engine_second_pass_opens_after_decision_starvation(tmp_path):
    c=cfg()
    c.update({
        "symbols":["EURUSD"],
        "opportunity_recovery_after_scans":3,
        "execution_realistic_paper":False,
        "selection_mode":"AUTO TOP 5",
        "selection_min_ai_score":50,
        "selection_min_confidence":50,
        "selection_min_market_score":0,
        "min_data_quality":70,
        "max_spread_pips":2.5,
        "daily_loss_limit_pct":50,
        "weekly_loss_limit_pct":50,
        "max_drawdown_pct":50,
        "emergency_session_loss_pct":50,
        "enabled_asset_classes":["FOREX"],
        "max_category_positions":5,
    })

    snap=MarketSnapshot(
        "EURUSD",1.09996,1.10004,0.6,50,
        1.1005,1.0995,7.0,0.5,"London","now",99.0
    )
    class Feed:
        def advance(self): pass
        def snapshot(self,symbol): return snap

    db=Database(str(tmp_path/"v247.db"))
    eng=TradingEngine(c,Feed(),db)
    eng.enabled=True

    def fake_research(s,liveness_relax=0.0):
        if liveness_relax>0:
            return Decision(s.symbol,"BUY",80,80,"FOREX / TREND | OPPORTUNITY RECOVERY",10,15,"now"),"TREND"
        return Decision(s.symbol,"WAIT",80,80,"WAIT — insufficient consensus/edge.",10,15,"now"),"TREND"
    eng._research_decision=fake_research

    eng.scan()
    assert len(eng.positions)==0
    assert eng.decision_starvation_scans==1

    eng.scan()
    assert len(eng.positions)==0
    assert eng.decision_starvation_scans==2

    eng.scan()
    assert len(eng.positions)==1
    assert eng.last_open_scan==eng.scan_count
    assert eng.decision_starvation_scans==0

def test_counterfactual_capacity_is_exposed():
    c=cfg()
    assert c["counterfactual_memory_capacity"]==500
