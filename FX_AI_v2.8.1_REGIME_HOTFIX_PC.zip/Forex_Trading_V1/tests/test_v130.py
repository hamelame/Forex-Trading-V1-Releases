import unittest
from forex_app.instruments import instrument_meta, display_name
from forex_app.updater import Updater, _version_tuple

class V130Tests(unittest.TestCase):
    def test_instrument_labels(self):
        m=instrument_meta("USDNOK")
        self.assertEqual(m["category"],"Forex / Nordic")
        self.assertIn("Norwegian Krone",m["name"])
        self.assertIn("Euro",display_name("EURUSD"))

    def test_updater_setup_state(self):
        r=Updater("1.3.0").check()
        self.assertEqual(r["status"],"setup_required")

    def test_version_compare_helper(self):
        self.assertGreater(_version_tuple("1.3.1"),_version_tuple("1.3.0"))

if __name__=="__main__":
    unittest.main()
