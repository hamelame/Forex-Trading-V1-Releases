# Forex Trading V1.9.0 — Premium UI Refresh

## Major visual refresh
- New premium navigation sidebar with rounded/pill navigation items and a bright active-state marker.
- New rounded KPI cards for Balance, Equity, Realized P/L, Open Positions, Portfolio Heat and AI Engine.
- Stronger visual hierarchy, darker near-black background and cleaner cyan/green accents.
- Updated spacing, typography and table density throughout the terminal.
- Command Center chart is larger again while the opportunity list remains compact and scrollable.
- Header spacing and status controls were refined to feel less like a legacy desktop utility.

## HD / Windows 11 rendering
- Enables Windows per-monitor DPI awareness before Tk starts.
- Uses Segoe UI Variable when available.
- Slightly higher Tk scaling for sharper text and controls on modern displays.

## Existing improvements preserved
- Stable non-flickering AI Decision Feed.
- Detailed market identity labels.
- Settings vertical scrolling.
- Persistent paper trading state.
- FX Council, risk engine and GitHub in-app updater remain unchanged functionally.

## GitHub updates
- Release repository remains `hamelame/Forex-Trading-V1-Releases`.
- Publish with `PUBLISH_RELEASE.bat`.
- Existing v1.8.0 installations can discover v1.9.0 from Settings -> CHECK FOR UPDATES.
